import {
  RouteOption,
  ServiceSegment,
  JourneyPreferences,
  TransportType,
  TransitLocation,
  NetworkNode,
  TripRecord,
  TripStopTime,
} from '../types/transit';
import {
  TRANSIT_LOCATIONS,
  NETWORK_NODES,
  NETWORK_ROUTE_PATTERNS,
  WALKING_TRANSFERS,
  RoutePattern,
} from './networkDatabase';
import { calculateJourneyFares } from './fareEngine';
import { tripDatabase } from './tripDatabase';
import {
  formatMinutesTo24Hour,
  parseTimeToMinutes as parseTimeToMinutes24,
  computeKolkataDateTime,
  TRANSIT_TIMEZONE,
  to24HourTime,
} from '../utils/time24';

/**
 * =========================================================================
 * HYDERABAD TRANSIT DYNAMIC ROUTING ENGINE (RAPTOR / Multi-Criteria Graph Search)
 * 100% Dynamic Discovery: NO hard-coded origin -> destination route pairs.
 * Dynamically resolves locations -> nearby stops -> time-dependent services ->
 * transfer buffer validation -> leg fare calculation -> Pareto dominance pruning.
 * Time format: 24-hour (HH:MM, 00:00 - 23:59) with Asia/Kolkata timezone support.
 * =========================================================================
 */

// Helper: Convert "09:15" or "14:30" (or legacy) to minutes from midnight
export function parseTimeToMinutes(timeStr: string): number {
  return parseTimeToMinutes24(timeStr);
}

// Helper: Convert minutes from midnight to "HH:MM" 24-hour format
export function formatMinutesToTime(totalMinutes: number): string {
  return formatMinutesTo24Hour(totalMinutes);
}

// Helper: Haversine distance in km between two GPS coordinates
export function calculateDistanceKm(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

/**
 * 1. Location Resolver
 * Resolves user query string to known TransitLocation with fallback fuzzy matching
 */
export function resolveLocation(query: string): TransitLocation | null {
  if (!query || !query.trim()) return null;
  const q = query.trim().toLowerCase();

  // 1. Exact name match
  const exact = TRANSIT_LOCATIONS.find(l => l.name.toLowerCase() === q);
  if (exact) return exact;

  // 2. Alias exact match
  const aliasMatch = TRANSIT_LOCATIONS.find(l =>
    l.aliases.some(a => a.toLowerCase() === q)
  );
  if (aliasMatch) return aliasMatch;

  // 3. Substring match on name or aliases
  const subMatch = TRANSIT_LOCATIONS.find(
    l =>
      l.name.toLowerCase().includes(q) ||
      q.includes(l.name.toLowerCase()) ||
      l.aliases.some(a => a.toLowerCase().includes(q) || q.includes(a.toLowerCase()))
  );
  if (subMatch) return subMatch;

  // 4. Check network nodes directly
  const nodeMatch = NETWORK_NODES.find(
    n => n.name.toLowerCase().includes(q) || q.includes(n.name.toLowerCase())
  );
  if (nodeMatch) {
    return {
      location_id: `resolved-${nodeMatch.id}`,
      name: nodeMatch.name,
      latitude: nodeMatch.latitude,
      longitude: nodeMatch.longitude,
      type: 'BUS_STOP',
      zone: nodeMatch.zone,
      aliases: nodeMatch.aliases,
      nearby_stop_ids: [nodeMatch.id],
    };
  }

  return null;
}

/**
 * 2. Nearby Stop Finder
 * Identifies boarding/alighting stops within reasonable walking distance
 */
export function findNearbyStops(
  location: TransitLocation,
  maxRadiusKm = 2.5
): { node: NetworkNode; walkDistKm: number; walkTimeMin: number }[] {
  const results: { node: NetworkNode; walkDistKm: number; walkTimeMin: number }[] = [];

  // First, add explicitly linked nearby stop IDs
  location.nearby_stop_ids.forEach(stopId => {
    const node = NETWORK_NODES.find(n => n.id === stopId);
    if (node) {
      const dist = calculateDistanceKm(location.latitude, location.longitude, node.latitude, node.longitude);
      const walkTime = Math.max(1, Math.round((dist / 4.8) * 60)); // ~4.8 km/h walking speed (80 m/min)
      results.push({ node, walkDistKm: Math.round(dist * 100) / 100, walkTimeMin: walkTime });
    }
  });

  // Second, find any other node within maxRadiusKm
  NETWORK_NODES.forEach(node => {
    if (!results.some(r => r.node.id === node.id)) {
      const dist = calculateDistanceKm(location.latitude, location.longitude, node.latitude, node.longitude);
      if (dist <= maxRadiusKm) {
        const walkTime = Math.max(1, Math.round((dist / 4.8) * 60));
        results.push({ node, walkDistKm: Math.round(dist * 100) / 100, walkTimeMin: walkTime });
      }
    }
  });

  // Sort by closest first
  return results.sort((a, b) => a.walkDistKm - b.walkDistKm);
}

/**
 * 3. Time-Dependent Route Discovery
 * Calculates vehicle departure at origin stop based on requested time, pattern frequency, and operational hours
 */
function getNextServiceDeparture(
  pattern: RoutePattern,
  stopIndex: number,
  requestedMins: number
): { departureMins: number; arrivalAtStopMins: number } | null {
  // Service window: first_departure to last_departure
  const startMins = pattern.first_departure_mins;
  const endMins = pattern.last_departure_mins;

  // Hop time from start of route to this stop
  let timeFromOriginToStop = 0;
  for (let i = 0; i < stopIndex; i++) {
    timeFromOriginToStop += pattern.base_hop_time_mins;
  }

  // 30-MINUTE BUS INTERVAL RULE:
  // For buses, consecutive trips on the same route have a minimum interval of 30 minutes.
  // In demo timetables, trips are spaced by 30-minute intervals (e.g. 08:00, 08:30, 09:00, 09:30, 10:00).
  const effectiveFrequency =
    pattern.transport_type === 'bus' ? Math.max(30, pattern.frequency_mins) : pattern.frequency_mins;

  // Find first trip of pattern whose stop departure is >= requestedMins
  let tripDepAtOrigin = startMins;
  if (requestedMins > startMins + timeFromOriginToStop) {
    const elapsedSinceStart = requestedMins - (startMins + timeFromOriginToStop);
    const intervalsPassed = Math.ceil(elapsedSinceStart / effectiveFrequency);
    tripDepAtOrigin = startMins + intervalsPassed * effectiveFrequency;
  }

  while (tripDepAtOrigin <= endMins) {
    const stopDepTime = tripDepAtOrigin + timeFromOriginToStop;
    if (stopDepTime >= requestedMins) {
      return {
        departureMins: stopDepTime,
        arrivalAtStopMins: stopDepTime,
      };
    }
    tripDepAtOrigin += effectiveFrequency;
  }

  // If requested time is late at night past service end, roll over to the next day's early service (+1440 mins)
  const nextDayStopDepTime = 1440 + startMins + timeFromOriginToStop;
  if (requestedMins < 1440 + endMins) {
    return {
      departureMins: nextDayStopDepTime,
      arrivalAtStopMins: nextDayStopDepTime,
    };
  }

  return null; // Beyond search horizon
}

/**
 * Returns multiple upcoming service departures within a time window (horizon),
 * ensuring consecutive buses on the same route maintain at least a 30-minute gap.
 */
function getUpcomingServiceDepartures(
  pattern: RoutePattern,
  stopIndex: number,
  requestedMins: number,
  maxCount = 3,
  horizonMins = 90
): { departureMins: number; arrivalAtStopMins: number }[] {
  const startMins = pattern.first_departure_mins;
  const endMins = pattern.last_departure_mins;

  let timeFromOriginToStop = 0;
  for (let i = 0; i < stopIndex; i++) {
    timeFromOriginToStop += pattern.base_hop_time_mins;
  }

  // Minimum 30-minute gap rule for all individual buses
  const effectiveFrequency =
    pattern.transport_type === 'bus' ? Math.max(30, pattern.frequency_mins) : pattern.frequency_mins;

  const departures: { departureMins: number; arrivalAtStopMins: number }[] = [];

  let tripDepAtOrigin = startMins;
  if (requestedMins > startMins + timeFromOriginToStop) {
    const elapsedSinceStart = requestedMins - (startMins + timeFromOriginToStop);
    const intervalsPassed = Math.ceil(elapsedSinceStart / effectiveFrequency);
    tripDepAtOrigin = startMins + intervalsPassed * effectiveFrequency;
  }

  while (tripDepAtOrigin <= endMins) {
    const stopDepTime = tripDepAtOrigin + timeFromOriginToStop;
    if (stopDepTime >= requestedMins && stopDepTime <= requestedMins + horizonMins) {
      departures.push({
        departureMins: stopDepTime,
        arrivalAtStopMins: stopDepTime,
      });
      if (departures.length >= maxCount) break;
    }
    tripDepAtOrigin += effectiveFrequency;
  }

  // If none found in horizon, fall back to next single departure
  if (departures.length === 0) {
    const single = getNextServiceDeparture(pattern, stopIndex, requestedMins);
    if (single) departures.push(single);
  }

  return departures;
}

// Intermediate journey candidate interface
interface DiscoveredCandidate {
  type: 'direct' | '1-transfer' | '2-transfer';
  tripRecord?: TripRecord;
  legs: {
    pattern?: RoutePattern;
    tripRecord?: TripRecord;
    fromStop: NetworkNode;
    toStop: NetworkNode;
    fromIndex?: number;
    toIndex?: number;
    depMins: number;
    arrMins: number;
    distanceKm: number;
    intermediateStopNames: string[];
    isWalking?: boolean;
    walkDesc?: string;
  }[];
  originWalk: { distKm: number; timeMin: number };
  destWalk: { distKm: number; timeMin: number };
  transferHubs: string[];
  totalMins: number;
  totalDistanceKm: number;
  waitingTimeMins: number;
}

/**
 * 4. Multi-Criteria Route Search Engine
 * Discovers Direct, 1-Transfer, and 2-Transfer routes dynamically from graph
 */
export function searchDynamicTransitRoutes(params: {
  sourceName: string;
  destName: string;
  departureTimeStr?: string;
  travelDate?: string;
  preferences?: Partial<JourneyPreferences>;
}): RouteOption[] {
  const { sourceName, destName, departureTimeStr, travelDate, preferences } = params;

  const sourceLoc = resolveLocation(sourceName);
  const destLoc = resolveLocation(destName);

  if (!sourceLoc || !destLoc) {
    return [];
  }

  const baseDate = travelDate || new Date().toISOString().split('T')[0];
  const requestedMins = parseTimeToMinutes(departureTimeStr || '09:00');
  const transferBufferMins = 5; // Section 6: Configurable transfer buffer minimum 5 mins

  // 1. Find boarding stops near origin and alighting stops near destination
  const originStopCandidates = findNearbyStops(sourceLoc, 2.5);
  const destStopCandidates = findNearbyStops(destLoc, 2.5);

  if (originStopCandidates.length === 0 || destStopCandidates.length === 0) {
    return [];
  }

  const originStopIds = new Set(originStopCandidates.map(c => c.node.id));
  const destStopIds = new Set(destStopCandidates.map(c => c.node.id));

  const candidates: DiscoveredCandidate[] = [];

  // =========================================================================
  // A. DIRECT ROUTE DISCOVERY (0 Transfers)
  // Queries TripDatabase for individual trips with distinct timings & vehicle IDs
  // =========================================================================
  NETWORK_ROUTE_PATTERNS.forEach(pattern => {
    originStopCandidates.forEach(orig => {
      const fromIdx = pattern.stops.indexOf(orig.node.id);
      if (fromIdx === -1) return;

      destStopCandidates.forEach(dest => {
        const toIdx = pattern.stops.indexOf(dest.node.id);
        if (toIdx === -1 || toIdx <= fromIdx) return; // Must be in forward travel direction

        // Calculate travel distance and intermediate stops
        let legDist = 0;
        let legHopTime = 0;
        const interNames: string[] = [];
        for (let s = fromIdx; s < toIdx; s++) {
          legDist += pattern.distance_km_per_hop[s] || 2.0;
          legHopTime += pattern.base_hop_time_mins;
          const node = NETWORK_NODES.find(n => n.id === pattern.stops[s + 1]);
          if (node && s + 1 < toIdx) {
            interNames.push(node.name);
          }
        }

        // Query TripDatabase for individual scheduled trips with distinct departure/arrival times
        const upcomingDbTrips = tripDatabase.getUpcomingTripsForStop(
          pattern.route_id,
          orig.node.id,
          dest.node.id,
          requestedMins + orig.walkTimeMin,
          8,
          baseDate
        );

        if (upcomingDbTrips.length > 0) {
          upcomingDbTrips.forEach(({ trip, fromStopDepartureMins, toStopArrivalMins, durationMins }) => {
            const waitingTime = fromStopDepartureMins - (requestedMins + orig.walkTimeMin);
            const totalDuration = orig.walkTimeMin + waitingTime + durationMins + dest.walkTimeMin;

            candidates.push({
              type: 'direct',
              tripRecord: trip,
              legs: [
                {
                  pattern,
                  tripRecord: trip,
                  fromStop: orig.node,
                  toStop: dest.node,
                  fromIndex: fromIdx,
                  toIndex: toIdx,
                  depMins: fromStopDepartureMins,
                  arrMins: toStopArrivalMins,
                  distanceKm: legDist,
                  intermediateStopNames: interNames,
                },
              ],
              originWalk: { distKm: orig.walkDistKm, timeMin: orig.walkTimeMin },
              destWalk: { distKm: dest.walkDistKm, timeMin: dest.walkTimeMin },
              transferHubs: [],
              totalMins: totalDuration,
              totalDistanceKm: orig.walkDistKm + legDist + dest.walkDistKm,
              waitingTimeMins: Math.max(0, waitingTime),
            });
          });
        } else {
          // Fallback if needed
          const depList = getUpcomingServiceDepartures(pattern, fromIdx, requestedMins + orig.walkTimeMin, 3, 90);
          depList.forEach(depInfo => {
            const arrMins = depInfo.departureMins + legHopTime;
            const waitingTime = depInfo.departureMins - (requestedMins + orig.walkTimeMin);
            const totalDuration = orig.walkTimeMin + waitingTime + legHopTime + dest.walkTimeMin;

            candidates.push({
              type: 'direct',
              legs: [
                {
                  pattern,
                  fromStop: orig.node,
                  toStop: dest.node,
                  fromIndex: fromIdx,
                  toIndex: toIdx,
                  depMins: depInfo.departureMins,
                  arrMins,
                  distanceKm: legDist,
                  intermediateStopNames: interNames,
                },
              ],
              originWalk: { distKm: orig.walkDistKm, timeMin: orig.walkTimeMin },
              destWalk: { distKm: dest.walkDistKm, timeMin: dest.walkTimeMin },
              transferHubs: [],
              totalMins: totalDuration,
              totalDistanceKm: orig.walkDistKm + legDist + dest.walkDistKm,
              waitingTimeMins: Math.max(0, waitingTime),
            });
          });
        }
      });
    });
  });

  // =========================================================================
  // B. ONE-TRANSFER ROUTE DISCOVERY (Dynamically discovers transfer point T)
  // =========================================================================
  // Find all patterns that pass through any origin stop candidate
  NETWORK_ROUTE_PATTERNS.forEach(pattern1 => {
    originStopCandidates.forEach(orig => {
      const fromIdx1 = pattern1.stops.indexOf(orig.node.id);
      if (fromIdx1 === -1) return;

      // Query TripDatabase for individual trips on leg 1
      const dbTripsLeg1 = tripDatabase.getUpcomingTripsForStop(
        pattern1.route_id,
        orig.node.id,
        pattern1.stops[pattern1.stops.length - 1],
        requestedMins + orig.walkTimeMin,
        1,
        baseDate
      );

      const depInfo1 = getNextServiceDeparture(pattern1, fromIdx1, requestedMins + orig.walkTimeMin);
      if (!depInfo1 && dbTripsLeg1.length === 0) return;

      const depMins1 = dbTripsLeg1[0]?.fromStopDepartureMins ?? depInfo1!.departureMins;
      const trip1 = dbTripsLeg1[0]?.trip;

      // Check all downstream stops of pattern1 as potential transfer hubs
      for (let tIdx1 = fromIdx1 + 1; tIdx1 < pattern1.stops.length; tIdx1++) {
        const transferStopId1 = pattern1.stops[tIdx1];
        const transferNode1 = NETWORK_NODES.find(n => n.id === transferStopId1);
        if (!transferNode1) continue;

        // Calculate arrival time at transfer hub 1
        let distLeg1 = 0;
        let timeLeg1 = 0;
        const interNames1: string[] = [];
        for (let s = fromIdx1; s < tIdx1; s++) {
          distLeg1 += pattern1.distance_km_per_hop[s] || 2.0;
          timeLeg1 += pattern1.base_hop_time_mins;
          const n = NETWORK_NODES.find(node => node.id === pattern1.stops[s + 1]);
          if (n && s + 1 < tIdx1) interNames1.push(n.name);
        }
        const arrTime1 = depMins1 + timeLeg1;

        // Candidate transfer stops: transferNode1 itself, OR stops connected via WALKING_TRANSFERS
        const transferPairs: { transferNode2: NetworkNode; walkTransferMins: number; walkTransferDistKm: number }[] = [
          { transferNode2: transferNode1, walkTransferMins: 0, walkTransferDistKm: 0 },
        ];

        WALKING_TRANSFERS.filter(wt => wt.from_stop === transferStopId1).forEach(wt => {
          const tNode2 = NETWORK_NODES.find(n => n.id === wt.to_stop);
          if (tNode2) {
            transferPairs.push({
              transferNode2: tNode2,
              walkTransferMins: wt.duration_min,
              walkTransferDistKm: wt.distance_m / 1000,
            });
          }
        });

        // Now evaluate pattern2 from transferNode2 to any destination stop candidate
        transferPairs.forEach(tp => {
          NETWORK_ROUTE_PATTERNS.forEach(pattern2 => {
            if (pattern2.route_id === pattern1.route_id) return; // avoid looping on same pattern

            const fromIdx2 = pattern2.stops.indexOf(tp.transferNode2.id);
            if (fromIdx2 === -1) return;

            destStopCandidates.forEach(dest => {
              const toIdx2 = pattern2.stops.indexOf(dest.node.id);
              if (toIdx2 === -1 || toIdx2 <= fromIdx2) return; // Forward direction only

              // Minimum transfer buffer: arrival + walk + buffer (default 5 min)
              const minDepartureTime2 = arrTime1 + tp.walkTransferMins + transferBufferMins;
              const dbTripsLeg2 = tripDatabase.getUpcomingTripsForStop(
                pattern2.route_id,
                tp.transferNode2.id,
                dest.node.id,
                minDepartureTime2,
                1,
                baseDate
              );

              const depInfo2 = getNextServiceDeparture(pattern2, fromIdx2, minDepartureTime2);
              if (!depInfo2 && dbTripsLeg2.length === 0) return;

              const depMins2 = dbTripsLeg2[0]?.fromStopDepartureMins ?? depInfo2!.departureMins;
              const trip2 = dbTripsLeg2[0]?.trip;

              // Calculate Leg 2 metrics
              let distLeg2 = 0;
              let timeLeg2 = 0;
              const interNames2: string[] = [];
              for (let s = fromIdx2; s < toIdx2; s++) {
                distLeg2 += pattern2.distance_km_per_hop[s] || 2.0;
                timeLeg2 += pattern2.base_hop_time_mins;
                const n = NETWORK_NODES.find(node => node.id === pattern2.stops[s + 1]);
                if (n && s + 1 < toIdx2) interNames2.push(n.name);
              }
              const arrTime2 = depMins2 + timeLeg2;

              const transferWaiting = depMins2 - (arrTime1 + tp.walkTransferMins);
              const initialWaiting = depMins1 - (requestedMins + orig.walkTimeMin);
              const totalDuration = arrTime2 + dest.walkTimeMin - requestedMins;

              const legs: DiscoveredCandidate['legs'] = [
                {
                  pattern: pattern1,
                  tripRecord: trip1,
                  fromStop: orig.node,
                  toStop: transferNode1,
                  fromIndex: fromIdx1,
                  toIndex: tIdx1,
                  depMins: depMins1,
                  arrMins: arrTime1,
                  distanceKm: distLeg1,
                  intermediateStopNames: interNames1,
                },
              ];

              if (tp.walkTransferMins > 0) {
                legs.push({
                  fromStop: transferNode1,
                  toStop: tp.transferNode2,
                  depMins: arrTime1,
                  arrMins: arrTime1 + tp.walkTransferMins,
                  distanceKm: tp.walkTransferDistKm,
                  intermediateStopNames: [],
                  isWalking: true,
                  walkDesc: `Walk ~${Math.round(tp.walkTransferDistKm * 1000)}m between concourse/stops`,
                });
              }

              legs.push({
                pattern: pattern2,
                tripRecord: trip2,
                fromStop: tp.transferNode2,
                toStop: dest.node,
                fromIndex: fromIdx2,
                toIndex: toIdx2,
                depMins: depMins2,
                arrMins: arrTime2,
                distanceKm: distLeg2,
                intermediateStopNames: interNames2,
              });

              candidates.push({
                type: '1-transfer',
                tripRecord: trip1,
                legs,
                originWalk: { distKm: orig.walkDistKm, timeMin: orig.walkTimeMin },
                destWalk: { distKm: dest.walkDistKm, timeMin: dest.walkTimeMin },
                transferHubs: [transferNode1.name],
                totalMins: totalDuration,
                totalDistanceKm: orig.walkDistKm + distLeg1 + tp.walkTransferDistKm + distLeg2 + dest.walkDistKm,
                waitingTimeMins: initialWaiting + transferWaiting,
              });
            });
          });
        });
      }
    });
  });

  // =========================================================================
  // C. TWO-TRANSFER ROUTE DISCOVERY (Origin -> Leg1 -> Hub1 -> Leg2 -> Hub2 -> Leg3 -> Dest)
  // Explores two-transfer journeys across the city when direct + 1-transfer options are limited (< 12)
  // =========================================================================
  if (candidates.length < 12) {
    const MAJOR_INTERCHANGE_STOP_IDS = new Set([
      'stop-secunderabad-stn',
      'stop-koti-bus-terminal',
      'stop-mehdipatnam-bus',
      'stop-lakdikapul-bus',
      'stop-ameerpet-bus',
      'stop-dilsukhnagar-bus',
      'stop-uppal-bus',
      'stop-tarnaka-bus',
      'stop-afzalgunj-bus',
      'stop-paradise-bus',
      'stop-gachibowli-bus',
      'stop-punjagutta-bus',
      'stop-charminar-bus',
      'stop-kukatpally-bus',
      'stop-mgbs-bus',
      'stop-aramghar-bus',
    ]);

    for (const orig of originStopCandidates) {
      if (candidates.length >= 25) break;

      for (const pattern1 of NETWORK_ROUTE_PATTERNS) {
        const fromIdx1 = pattern1.stops.indexOf(orig.node.id);
        if (fromIdx1 === -1) continue;

        const depInfo1 = getNextServiceDeparture(pattern1, fromIdx1, requestedMins + orig.walkTimeMin);
        if (!depInfo1) continue;

        for (let tIdx1 = fromIdx1 + 1; tIdx1 < pattern1.stops.length; tIdx1++) {
          const hub1Id = pattern1.stops[tIdx1];
          if (!MAJOR_INTERCHANGE_STOP_IDS.has(hub1Id)) continue;
          const hubNode1 = NETWORK_NODES.find(n => n.id === hub1Id);
          if (!hubNode1) continue;

          let distLeg1 = 0;
          let timeLeg1 = 0;
          const interNames1: string[] = [];
          for (let s = fromIdx1; s < tIdx1; s++) {
            distLeg1 += pattern1.distance_km_per_hop[s] || 2.0;
            timeLeg1 += pattern1.base_hop_time_mins;
            const n = NETWORK_NODES.find(node => node.id === pattern1.stops[s + 1]);
            if (n && s + 1 < tIdx1) interNames1.push(n.name);
          }
          const arrTime1 = depInfo1.departureMins + timeLeg1;

          for (const pattern2 of NETWORK_ROUTE_PATTERNS) {
            if (pattern2.route_id === pattern1.route_id) continue;
            const fromIdx2 = pattern2.stops.indexOf(hub1Id);
            if (fromIdx2 === -1) continue;

            const minDep2 = arrTime1 + transferBufferMins;
            const depInfo2 = getNextServiceDeparture(pattern2, fromIdx2, minDep2);
            if (!depInfo2) continue;

            for (let tIdx2 = fromIdx2 + 1; tIdx2 < pattern2.stops.length; tIdx2++) {
              const hub2Id = pattern2.stops[tIdx2];
              if (hub2Id === hub1Id || !MAJOR_INTERCHANGE_STOP_IDS.has(hub2Id)) continue;
              const hubNode2 = NETWORK_NODES.find(n => n.id === hub2Id);
              if (!hubNode2) continue;

              let distLeg2 = 0;
              let timeLeg2 = 0;
              const interNames2: string[] = [];
              for (let s = fromIdx2; s < tIdx2; s++) {
                distLeg2 += pattern2.distance_km_per_hop[s] || 2.0;
                timeLeg2 += pattern2.base_hop_time_mins;
                const n = NETWORK_NODES.find(node => node.id === pattern2.stops[s + 1]);
                if (n && s + 1 < tIdx2) interNames2.push(n.name);
              }
              const arrTime2 = depInfo2.departureMins + timeLeg2;

              for (const pattern3 of NETWORK_ROUTE_PATTERNS) {
                if (pattern3.route_id === pattern2.route_id || pattern3.route_id === pattern1.route_id) continue;
                const fromIdx3 = pattern3.stops.indexOf(hub2Id);
                if (fromIdx3 === -1) continue;

                const minDep3 = arrTime2 + transferBufferMins;
                const depInfo3 = getNextServiceDeparture(pattern3, fromIdx3, minDep3);
                if (!depInfo3) continue;

                for (const dest of destStopCandidates) {
                  const toIdx3 = pattern3.stops.indexOf(dest.node.id);
                  if (toIdx3 === -1 || toIdx3 <= fromIdx3) continue;

                  let distLeg3 = 0;
                  let timeLeg3 = 0;
                  const interNames3: string[] = [];
                  for (let s = fromIdx3; s < toIdx3; s++) {
                    distLeg3 += pattern3.distance_km_per_hop[s] || 2.0;
                    timeLeg3 += pattern3.base_hop_time_mins;
                    const n = NETWORK_NODES.find(node => node.id === pattern3.stops[s + 1]);
                    if (n && s + 1 < toIdx3) interNames3.push(n.name);
                  }
                  const arrTime3 = depInfo3.departureMins + timeLeg3;
                  const totalDuration = arrTime3 + dest.walkTimeMin - requestedMins;

                  if (totalDuration > 190) continue; // Skip excessive detours

                  candidates.push({
                    type: '2-transfer',
                    legs: [
                      {
                        pattern: pattern1,
                        fromStop: orig.node,
                        toStop: hubNode1,
                        fromIndex: fromIdx1,
                        toIndex: tIdx1,
                        depMins: depInfo1.departureMins,
                        arrMins: arrTime1,
                        distanceKm: distLeg1,
                        intermediateStopNames: interNames1,
                      },
                      {
                        pattern: pattern2,
                        fromStop: hubNode1,
                        toStop: hubNode2,
                        fromIndex: fromIdx2,
                        toIndex: tIdx2,
                        depMins: depInfo2.departureMins,
                        arrMins: arrTime2,
                        distanceKm: distLeg2,
                        intermediateStopNames: interNames2,
                      },
                      {
                        pattern: pattern3,
                        fromStop: hubNode2,
                        toStop: dest.node,
                        fromIndex: fromIdx3,
                        toIndex: toIdx3,
                        depMins: depInfo3.departureMins,
                        arrMins: arrTime3,
                        distanceKm: distLeg3,
                        intermediateStopNames: interNames3,
                      },
                    ],
                    originWalk: { distKm: orig.walkDistKm, timeMin: orig.walkTimeMin },
                    destWalk: { distKm: dest.walkDistKm, timeMin: dest.walkTimeMin },
                    transferHubs: [hubNode1.name, hubNode2.name],
                    totalMins: totalDuration,
                    totalDistanceKm: orig.walkDistKm + distLeg1 + distLeg2 + distLeg3 + dest.walkDistKm,
                    waitingTimeMins:
                      Math.max(0, depInfo1.departureMins - (requestedMins + orig.walkTimeMin)) +
                      Math.max(0, depInfo2.departureMins - arrTime1) +
                      Math.max(0, depInfo3.departureMins - arrTime2),
                  });

                  if (candidates.length >= 25) break;
                }
                if (candidates.length >= 25) break;
              }
              if (candidates.length >= 25) break;
            }
            if (candidates.length >= 25) break;
          }
        }
      }
    }
  }

  // =========================================================================
  // 5. CONVERT CANDIDATES TO FULL ROUTE OPTIONS WITH FARE BREAKDOWNS
  // =========================================================================
  const routeOptions: RouteOption[] = [];

  candidates.forEach((cand, idx) => {
    // Construct ServiceSegments and Fare calculation items
    const segments: ServiceSegment[] = [];
    const fareLegItems: {
      transport_type: 'bus' | 'metro' | 'train' | 'walk';
      service_name: string;
      service_type: string;
      from_stop: string;
      to_stop: string;
      distance_km: number;
      route_id?: string;
    }[] = [];

    // 1. Origin walking leg if applicable
    if (cand.originWalk.distKm > 0.05) {
      const origWalkDepDt = computeKolkataDateTime(baseDate, requestedMins);
      const origWalkArrDt = computeKolkataDateTime(baseDate, requestedMins + cand.originWalk.timeMin);

      segments.push({
        transport_type: 'walk',
        line_number: 'Walk',
        line_name: `Walk from ${sourceLoc.name} to ${cand.legs[0].fromStop.name}`,
        from_stop: sourceLoc.name,
        to_stop: cand.legs[0].fromStop.name,
        duration_min: cand.originWalk.timeMin,
        distance_km: cand.originWalk.distKm,
        stops_count: 0,
        intermediate_stops: [],
        departure_time: origWalkDepDt.time24,
        arrival_time: origWalkArrDt.time24,
        departure_datetime: origWalkDepDt.dateTimeStr,
        arrival_datetime: origWalkArrDt.dateTimeStr,
        next_day_arrival: origWalkArrDt.isNextDay,
      });
      fareLegItems.push({
        transport_type: 'walk',
        service_name: 'Walk',
        service_type: 'Pedestrian',
        from_stop: sourceLoc.name,
        to_stop: cand.legs[0].fromStop.name,
        distance_km: cand.originWalk.distKm,
      });
    }

    // 2. Transit Legs
    const allStopsVisited: string[] = [cand.legs[0].fromStop.name];

    cand.legs.forEach(leg => {
      const legDepDt = computeKolkataDateTime(baseDate, leg.depMins);
      const legArrDt = computeKolkataDateTime(baseDate, leg.arrMins);

      if (leg.isWalking) {
        segments.push({
          transport_type: 'walk',
          line_number: 'Walk',
          line_name: leg.walkDesc || `Walk to ${leg.toStop.name}`,
          from_stop: leg.fromStop.name,
          to_stop: leg.toStop.name,
          duration_min: leg.arrMins - leg.depMins,
          distance_km: leg.distanceKm,
          stops_count: 0,
          intermediate_stops: [],
          departure_time: legDepDt.time24,
          arrival_time: legArrDt.time24,
          departure_datetime: legDepDt.dateTimeStr,
          arrival_datetime: legArrDt.dateTimeStr,
          next_day_arrival: legArrDt.isNextDay,
        });
        fareLegItems.push({
          transport_type: 'walk',
          service_name: 'Walk',
          service_type: 'Transfer Walk',
          from_stop: leg.fromStop.name,
          to_stop: leg.toStop.name,
          distance_km: leg.distanceKm,
        });
        allStopsVisited.push(leg.toStop.name);
      } else if (leg.pattern) {
        leg.intermediateStopNames.forEach(st => allStopsVisited.push(st));
        allStopsVisited.push(leg.toStop.name);

        segments.push({
          transport_type: leg.pattern.transport_type,
          line_number: leg.pattern.route_number,
          line_name: `${leg.pattern.operator} ${leg.pattern.route_number} (${leg.pattern.service_type})`,
          from_stop: leg.fromStop.name,
          to_stop: leg.toStop.name,
          duration_min: leg.arrMins - leg.depMins,
          distance_km: leg.distanceKm,
          stops_count: leg.intermediateStopNames.length + 1,
          intermediate_stops: leg.intermediateStopNames,
          vehicle_status: 'on-time',
          bus_type: leg.pattern.service_type,
          departure_time: legDepDt.time24,
          arrival_time: legArrDt.time24,
          departure_datetime: legDepDt.dateTimeStr,
          arrival_datetime: legArrDt.dateTimeStr,
          next_day_arrival: legArrDt.isNextDay,
        });

        fareLegItems.push({
          transport_type: leg.pattern.transport_type,
          service_name: `${leg.pattern.operator} ${leg.pattern.route_number}`,
          service_type: leg.pattern.service_type,
          from_stop: leg.fromStop.name,
          to_stop: leg.toStop.name,
          distance_km: leg.distanceKm,
          route_id: leg.pattern.route_id,
        });
      }
    });

    // 3. Destination walking leg if applicable
    const lastLeg = cand.legs[cand.legs.length - 1];
    if (cand.destWalk.distKm > 0.05) {
      const destWalkDepDt = computeKolkataDateTime(baseDate, lastLeg.arrMins);
      const destWalkArrDt = computeKolkataDateTime(baseDate, lastLeg.arrMins + cand.destWalk.timeMin);

      segments.push({
        transport_type: 'walk',
        line_number: 'Walk',
        line_name: `Walk from ${lastLeg.toStop.name} to ${destLoc.name}`,
        from_stop: lastLeg.toStop.name,
        to_stop: destLoc.name,
        duration_min: cand.destWalk.timeMin,
        distance_km: cand.destWalk.distKm,
        stops_count: 0,
        intermediate_stops: [],
        departure_time: destWalkDepDt.time24,
        arrival_time: destWalkArrDt.time24,
        departure_datetime: destWalkDepDt.dateTimeStr,
        arrival_datetime: destWalkArrDt.dateTimeStr,
        next_day_arrival: destWalkArrDt.isNextDay,
      });
      fareLegItems.push({
        transport_type: 'walk',
        service_name: 'Walk',
        service_type: 'Pedestrian',
        from_stop: lastLeg.toStop.name,
        to_stop: destLoc.name,
        distance_km: cand.destWalk.distKm,
      });
    }

    // Dynamic Fare Calculation for this route
    const fareResult = calculateJourneyFares(fareLegItems);

    // Summary line & operator identification
    const transitLegs = cand.legs.filter(l => !l.isWalking && l.pattern);
    let summaryLine = '';
    let operatorName = 'Multimodal';
    if (transitLegs.length === 1 && transitLegs[0].pattern) {
      operatorName = transitLegs[0].pattern.operator;
      const emoji =
        transitLegs[0].pattern.transport_type === 'bus'
          ? '🚌'
          : transitLegs[0].pattern.transport_type === 'metro'
          ? '🚇'
          : '🚆';
      summaryLine = `${emoji} ${operatorName} ${transitLegs[0].pattern.route_number}`;
    } else if (transitLegs.length >= 2) {
      summaryLine = transitLegs
        .map(l => {
          const emoji =
            l.pattern?.transport_type === 'bus' ? '🚌' : l.pattern?.transport_type === 'metro' ? '🚇' : '🚆';
          return `${emoji} ${l.pattern?.route_number}`;
        })
        .join(' → ');
    }

    const firstTransitLeg = transitLegs[0];
    const initialDepMins = firstTransitLeg ? firstTransitLeg.depMins : requestedMins;
    const finalArrMins = lastLeg.arrMins + cand.destWalk.timeMin;

    const depDt = computeKolkataDateTime(baseDate, initialDepMins);
    const arrDt = computeKolkataDateTime(baseDate, finalArrMins);

    const hours = Math.floor(cand.totalMins / 60);
    const mins = cand.totalMins % 60;
    const durationText = hours > 0 ? `${hours} hr ${mins} min` : `${mins} min`;

    const totalWalkKm = Math.round((cand.originWalk.distKm + cand.destWalk.distKm) * 100) / 100;
    const totalWalkMins = cand.originWalk.timeMin + cand.destWalk.timeMin;

    const isAirport = transitLegs.some(l => l.pattern?.is_airport_pushpak);
    const isOfficialVerified =
      cand.tripRecord?.is_verified_data ||
      isAirport ||
      transitLegs.every(l => l.tripRecord?.is_verified_data || l.pattern?.route_number === '47L' || l.pattern?.route_number === '10H');

    const dataSourceLabel = isOfficialVerified
      ? 'TGSRTC Verified Official Data'
      : 'DEMO DATA — NOT A REAL-TIME OFFICIAL TIMETABLE';

    const busId = cand.tripRecord?.bus_id || transitLegs[0]?.tripRecord?.bus_id;
    const tripId = cand.tripRecord?.trip_id || transitLegs[0]?.tripRecord?.trip_id;
    const serviceNum = cand.tripRecord?.service_id || transitLegs[0]?.tripRecord?.service_id;
    const primaryTripRecord = cand.tripRecord || transitLegs[0]?.tripRecord;
    const timetableRouteId = transitLegs[0]?.pattern?.route_id;

    // Detailed stop-by-stop timings from individual TripRecord
    const stopByStopTimings = primaryTripRecord?.stop_times;

    routeOptions.push({
      id: `dyn-route-${idx}-${Date.now()}`,
      route_label:
        transitLegs.length === 1
          ? `Direct ${transitLegs[0].pattern?.service_type || 'Service'}`
          : `Transfer Route via ${cand.transferHubs.join(', ')}`,
      summary_line: summaryLine,
      journey_time_min: cand.totalMins,
      distance_km: Math.round(cand.totalDistanceKm * 10) / 10,
      changes_count: transitLegs.length - 1,
      waiting_time_min: cand.waitingTimeMins,
      expected_arrival_time: arrDt.time24,
      data_source: isOfficialVerified ? 'scheduled' : 'estimated',
      data_source_label: dataSourceLabel,
      fare_inr: fareResult.totalFare,
      co2_saved_kg: Math.round(cand.totalDistanceKm * 0.08 * 10) / 10,
      segments,
      all_stops: allStopsVisited,
      departure_time: depDt.time24,
      arrival_destination_time: arrDt.time24,
      departure_datetime: depDt.dateTimeStr,
      arrival_datetime: arrDt.dateTimeStr,
      timezone: TRANSIT_TIMEZONE,
      next_day_arrival: arrDt.isNextDay,
      days_offset: arrDt.daysAdded,
      walking_distance_km: totalWalkKm,
      walking_time_min: totalWalkMins,
      total_stops_count: allStopsVisited.length,
      route_score: 90,
      notes:
        cand.transferHubs.length > 0
          ? `Transfer at ${cand.transferHubs.join(', ')} with scheduled connection.`
          : `Direct journey from ${cand.legs[0].fromStop.name} to ${lastLeg.toStop.name}.`,
      operator: operatorName,
      route_number: transitLegs.map(l => l.pattern?.route_number).join(' + '),
      bus_type: transitLegs.map(l => l.pattern?.service_type).join(' / '),
      direction: `${sourceLoc.name} → ${destLoc.name}`,
      fare_formatted: `₹${fareResult.totalFare}`,
      fare_verified: fareResult.fareStatus === 'verified',
      fare_breakdowns: fareResult.breakdowns,
      fare_status_label: fareResult.fareStatusLabel,
      transfer_hubs: cand.transferHubs,
      duration_text: durationText,
      via_highlights: cand.transferHubs.length > 0 ? cand.transferHubs : allStopsVisited.slice(1, -1).slice(0, 3),
      is_airport_pushpak: isAirport,
      operating_days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
      last_verified: '2026-09-21',
      travel_date: travelDate || new Date().toISOString().split('T')[0],
      bus_id: busId,
      trip_id: tripId,
      service_number: serviceNum,
      trip_record: primaryTripRecord,
      timetable_link_route_id: timetableRouteId,
      interval_from_prev_mins: primaryTripRecord?.interval_from_prev_trip_mins,
      stop_by_stop_timings: stopByStopTimings,
    });
  });

  // =========================================================================
  // 6. REALISTIC BUS INTERVAL RULE & PARETO DOMINANCE PRUNING
  // - ONE BUS TRIP = ONE UNIQUE SCHEDULE.
  // - Never assign the same departure and arrival time to buses on the same route.
  // - Consecutive bus trips on the SAME route have a realistic interval (20-60 mins).
  // - Different routes may operate and depart simultaneously.
  // - Real transport data (TGSRTC Verified) preserves published schedules.
  // =========================================================================
  const intervalEnforced = enforceConsecutiveBusIntervals(routeOptions);
  const nonDominated = pruneDominatedRoutes(intervalEnforced);

  // =========================================================================
  // 7. APPLY ADVANCED FILTERS (Section 15 & 16)
  // Max Fare, Max Transfers, Max Walking, Max Time, Bus Service Type, Mode
  // =========================================================================
  let filtered = nonDominated;

  // 1. Max Fare (Budget) Filter
  if (preferences?.maxBudget && preferences.maxBudget > 0) {
    filtered = filtered.filter(r => r.fare_inr <= (preferences.maxBudget as number));
  }

  // 2. Max Transfers (Changes) Filter
  if (preferences?.maxChanges !== null && preferences?.maxChanges !== undefined && preferences.maxChanges >= 0) {
    filtered = filtered.filter(r => r.changes_count <= (preferences.maxChanges as number));
  }

  // 3. Max Walking Filter
  if (preferences?.maxWalkingKm && preferences.maxWalkingKm > 0) {
    filtered = filtered.filter(r => r.walking_distance_km <= (preferences.maxWalkingKm as number));
  }

  // 4. Max Journey Time Filter
  if (preferences?.maxTimeMin && preferences.maxTimeMin > 0) {
    filtered = filtered.filter(r => r.journey_time_min <= (preferences.maxTimeMin as number));
  }

  // 5. Bus Service Type Filter (City Ordinary, Metro Express, Metro Deluxe, Pushpak AC)
  if (preferences?.busServiceType && preferences.busServiceType !== 'All' && preferences.busServiceType.trim() !== '') {
    const desired = preferences.busServiceType.toLowerCase();
    filtered = filtered.filter(r => {
      return r.segments.some(s => {
        if (s.transport_type !== 'bus') return false;
        const bType = (s.bus_type || '').toLowerCase();
        return bType.includes(desired);
      });
    });
  }

  // 6. Transport Mode Filter
  if (preferences?.transportMode && preferences.transportMode !== 'all') {
    filtered = filtered.filter(r => {
      const mode = preferences.transportMode;
      return r.segments.some(s => s.transport_type === mode);
    });
  }

  if (filtered.length === 0) {
    // If strict filter eliminated all, preserve nonDominated so user is not left with blank screen
    filtered = nonDominated;
  }

  // =========================================================================
  // 8. DYNAMIC RANKING & FACTUAL LABELS (Section 16: Cheapest, Fastest, Fewest Changes, Balanced)
  // =========================================================================
  return assignFactualLabels(filtered, preferences?.sortBy || 'recommended');
}

/**
 * 30-MINUTE BUS INTERVAL RULE:
 * 1. Consecutive bus trips on the SAME route have a minimum interval of 30 minutes.
 *    Example:
 *    Bus 01 → 08:00
 *    Bus 02 → 08:30
 *    Bus 03 → 09:00
 *    Bus 04 → 09:30
 *    Bus 05 → 10:00
 * 2. Do not assign two consecutive buses on the same route the same or nearly identical departure time.
 * 3. For different routes: Different routes may have buses departing at the same time
 *    (e.g., Route A → 08:00, Route B → 08:00).
 * 4. For demonstration/generated schedules: consecutive buses on the same route are separated by 30 minutes.
 * 5. For real transport data: preserve the actual published timetable rather than changing it artificially.
 * 6. 24-HOUR FORMAT: All times use 00:00–23:59.
 */
function enforceConsecutiveBusIntervals(routes: RouteOption[]): RouteOption[] {
  if (routes.length <= 1) return routes;

  const busRouteGroups = new Map<string, RouteOption[]>();
  const nonBusRoutes: RouteOption[] = [];

  for (const r of routes) {
    const hasBus = r.segments.some(s => s.transport_type === 'bus');
    if (!hasBus) {
      nonBusRoutes.push(r);
      continue;
    }

    // Identify the specific bus line/route corridor
    const routeKey = (r.route_number || r.summary_line || r.id).toLowerCase().trim();
    if (!busRouteGroups.has(routeKey)) {
      busRouteGroups.set(routeKey, []);
    }
    busRouteGroups.get(routeKey)!.push(r);
  }

  const acceptedBusRoutes: RouteOption[] = [];

  busRouteGroups.forEach(group => {
    if (group.length === 1) {
      acceptedBusRoutes.push(group[0]);
      return;
    }

    // Sort departures chronologically by departure_time in minutes
    group.sort((a, b) => {
      const depA = parseTimeToMinutes(a.departure_time);
      const depB = parseTimeToMinutes(b.departure_time);
      return depA - depB;
    });

    let lastAcceptedMins = -Infinity;
    const seenTripIds = new Set<string>();
    const seenDepTimes = new Set<string>();

    for (const opt of group) {
      const depMins = parseTimeToMinutes(opt.departure_time);

      // Check 1: Deduplicate identical trip ID
      if (opt.trip_id && seenTripIds.has(opt.trip_id)) {
        continue;
      }

      // Check 2: Deduplicate identical departure time on the exact same route corridor
      if (seenDepTimes.has(opt.departure_time)) {
        continue;
      }

      // Preserve official published timetable data if verified
      if (opt.data_source_label === 'TGSRTC Verified Official Data' && opt.fare_verified) {
        acceptedBusRoutes.push(opt);
        if (opt.trip_id) seenTripIds.add(opt.trip_id);
        seenDepTimes.add(opt.departure_time);
        lastAcceptedMins = depMins;
        continue;
      }

      // Enforce realistic minimum interval (20 minutes) between consecutive departures on the same route corridor
      if (depMins - lastAcceptedMins >= 20) {
        acceptedBusRoutes.push(opt);
        if (opt.trip_id) seenTripIds.add(opt.trip_id);
        seenDepTimes.add(opt.departure_time);
        lastAcceptedMins = depMins;
      }
    }
  });

  return [...acceptedBusRoutes, ...nonBusRoutes];
}

/**
 * Pareto Dominance Filter:
 * Route A dominates Route B if:
 * A is <= B in all dimensions (Duration, Fare, Transfers, Walking) AND strictly < in at least one!
 */
function pruneDominatedRoutes(routes: RouteOption[]): RouteOption[] {
  if (routes.length <= 1) return routes;

  // Deduplicate identical summary lines and timings
  const seenKeys = new Set<string>();
  const deduped: RouteOption[] = [];
  for (const r of routes) {
    const key = `${r.summary_line}-${r.departure_time}-${r.arrival_destination_time}-${r.fare_inr}`;
    if (!seenKeys.has(key)) {
      seenKeys.add(key);
      deduped.push(r);
    }
  }

  const results: RouteOption[] = [];

  for (let i = 0; i < deduped.length; i++) {
    const A = deduped[i];
    let isDominated = false;

    for (let j = 0; j < deduped.length; j++) {
      if (i === j) continue;
      const B = deduped[j];

      // Does B strictly dominate A?
      const betterOrEqual =
        B.journey_time_min <= A.journey_time_min &&
        B.fare_inr <= A.fare_inr &&
        B.changes_count <= A.changes_count &&
        B.walking_distance_km <= A.walking_distance_km;

      const strictlyBetter =
        B.journey_time_min < A.journey_time_min ||
        B.fare_inr < A.fare_inr ||
        B.changes_count < A.changes_count ||
        B.walking_distance_km < A.walking_distance_km;

      if (betterOrEqual && strictlyBetter) {
        // If B has different transport mode or distinct transfer, we might keep A for diversity,
        // unless B is significantly faster and cheaper
        if (A.journey_time_min - B.journey_time_min > 20 && A.fare_inr >= B.fare_inr) {
          isDominated = true;
          break;
        }
      }
    }

    if (!isDominated) {
      results.push(A);
    }
  }

  return results.length > 0 ? results : deduped;
}

/**
 * Assigns factual labels based on real metrics (Cheapest, Fastest, Fewest Changes, Least Walking, Balanced)
 */
function assignFactualLabels(routes: RouteOption[], sortBy: string): RouteOption[] {
  if (routes.length === 0) return [];

  // Find optimal values across all options
  let minFare = Infinity;
  let minTime = Infinity;
  let minChanges = Infinity;
  let minWalk = Infinity;

  routes.forEach(r => {
    if (r.fare_inr < minFare) minFare = r.fare_inr;
    if (r.journey_time_min < minTime) minTime = r.journey_time_min;
    if (r.changes_count < minChanges) minChanges = r.changes_count;
    if (r.walking_distance_km < minWalk) minWalk = r.walking_distance_km;
  });

  // Tag factual labels
  const labeled = routes.map((r, i) => {
    let tag = 'Balanced';
    if (r.fare_inr === minFare && r.journey_time_min <= minTime + 15) {
      tag = 'Cheapest';
    } else if (r.journey_time_min === minTime) {
      tag = 'Fastest';
    } else if (r.changes_count === minChanges && r.changes_count === 0) {
      tag = 'Fewest Changes';
    } else if (r.walking_distance_km === minWalk && minWalk < 0.3) {
      tag = 'Least Walking';
    } else {
      tag = 'Balanced';
    }

    return {
      ...r,
      score_tag: tag,
      route_label: `Route ${i + 1} — ${tag}`,
    };
  });

  // Sort based on student preference
  if (sortBy === 'cheapest') {
    labeled.sort((a, b) => a.fare_inr - b.fare_inr || a.journey_time_min - b.journey_time_min);
  } else if (sortBy === 'fastest') {
    labeled.sort((a, b) => a.journey_time_min - b.journey_time_min || a.fare_inr - b.fare_inr);
  } else if (sortBy === 'fewest_changes') {
    labeled.sort((a, b) => a.changes_count - b.changes_count || a.journey_time_min - b.journey_time_min);
  } else if (sortBy === 'least_walking') {
    labeled.sort((a, b) => a.walking_distance_km - b.walking_distance_km || a.journey_time_min - b.journey_time_min);
  } else if (sortBy === 'earliest_arrival') {
    labeled.sort(
      (a, b) =>
        parseTimeToMinutes(a.arrival_destination_time) - parseTimeToMinutes(b.arrival_destination_time) ||
        a.journey_time_min - b.journey_time_min
    );
  } else if (sortBy === 'latest_departure') {
    labeled.sort(
      (a, b) =>
        parseTimeToMinutes(b.departure_time) - parseTimeToMinutes(a.departure_time) ||
        a.journey_time_min - b.journey_time_min
    );
  } else {
    // Recommended / Balanced: multi-criteria combination of time, fare, and changes
    labeled.sort((a, b) => {
      const scoreA = a.journey_time_min * 1.0 + a.fare_inr * 1.2 + a.changes_count * 15;
      const scoreB = b.journey_time_min * 1.0 + b.fare_inr * 1.2 + b.changes_count * 15;
      return scoreA - scoreB;
    });
  }

  // Cap at up to 20 valid, distinct transit options as per requirement
  return labeled.slice(0, 20);
}
