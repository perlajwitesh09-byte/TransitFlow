import {
  HyderabadLocation,
  Stop,
  RouteOption,
  StopDeparture,
  TransportType,
  JourneyPreferences,
  DataSourceType,
  PriorityMode,
  SavedJourney
} from '../types/transit';
import {
  findDirectTGSRTCSchedules,
  findTransferTGSRTCSchedules,
  convertTGSRTCToRouteOption,
  convertTransferToRouteOption,
} from './tgsrtcData';
import { searchDynamicTransitRoutes } from './routingEngine';
import { tripDatabase } from './tripDatabase';

// ==========================================
// 1. HYDERABAD LOCATIONS & TRANSPORT HUBS DATABASE
// ==========================================
export const HYDERABAD_LOCATIONS: HyderabadLocation[] = [
  // --- Central Hyderabad ---
  { id: 'loc-c1', name: 'Abids', type: 'area', zone: 'Central', latitude: 17.3892, longitude: 78.4735, nearbyTransport: 'Koti Bus Stand / Gandhi Bhavan Metro' },
  { id: 'loc-c2', name: 'Koti', type: 'bus_hub', zone: 'Central', latitude: 17.3860, longitude: 78.4844, nearbyTransport: 'Major City Bus Terminal, Sultan Bazar Metro' },
  { id: 'loc-c3', name: 'Nampally', type: 'area', zone: 'Central', latitude: 17.3840, longitude: 78.4682, nearbyTransport: 'Hyderabad Deccan Railway, Nampally Metro' },
  { id: 'loc-c4', name: 'Basheerbagh', type: 'area', zone: 'Central', latitude: 17.3985, longitude: 78.4770, nearbyTransport: 'Basheerbagh Bus Stop, Assembly Metro' },
  { id: 'loc-c5', name: 'Lakdikapul', type: 'metro', zone: 'Central', latitude: 17.4042, longitude: 78.4632, nearbyTransport: 'Lakdikapul Metro (Red Line), Bus Interchange' },
  { id: 'loc-c6', name: 'Khairatabad', type: 'metro', zone: 'Central', latitude: 17.4124, longitude: 78.4607, nearbyTransport: 'Khairatabad Metro, MMTS Station' },
  { id: 'loc-c7', name: 'Himayatnagar', type: 'area', zone: 'Central', latitude: 17.4012, longitude: 78.4890, nearbyTransport: 'Himayatnagar Bus Route 10' },
  { id: 'loc-c8', name: 'Narayanguda', type: 'metro', zone: 'Central', latitude: 17.3971, longitude: 78.4912, nearbyTransport: 'Narayanguda Metro (Green Line)' },
  { id: 'loc-c9', name: 'RTC X Roads', type: 'metro', zone: 'Central', latitude: 17.4098, longitude: 78.4983, nearbyTransport: 'RTC X Roads Metro (Green Line), Bus Junction' },
  { id: 'loc-c10', name: 'Tank Bund', type: 'area', zone: 'Central', latitude: 17.4239, longitude: 78.4738, nearbyTransport: 'Hussain Sagar Lake Promenade, Bus Route 5' },
  { id: 'loc-c11', name: 'Secretariat', type: 'area', zone: 'Central', latitude: 17.4116, longitude: 78.4720, nearbyTransport: 'BR Ambedkar Secretariat, Khairatabad Metro' },
  { id: 'loc-c12', name: 'Saifabad', type: 'area', zone: 'Central', latitude: 17.4035, longitude: 78.4680, nearbyTransport: 'Lakdikapul Metro, AG Office' },

  // --- North Hyderabad ---
  { id: 'loc-n1', name: 'Secunderabad', type: 'railway', zone: 'North', latitude: 17.4399, longitude: 78.4983, nearbyTransport: 'Secunderabad Junction, Jubilee Bus Station, Metro East/West' },
  { id: 'loc-n2', name: 'Malkajgiri', type: 'railway', zone: 'North', latitude: 17.4520, longitude: 78.5320, nearbyTransport: 'Malkajgiri Railway Station, MMTS' },
  { id: 'loc-n3', name: 'Tarnaka', type: 'metro', zone: 'North', latitude: 17.4285, longitude: 78.5300, nearbyTransport: 'Tarnaka Metro (Blue Line), OU North Gate' },
  { id: 'loc-n4', name: 'Habsiguda', type: 'metro', zone: 'North', latitude: 17.4172, longitude: 78.5435, nearbyTransport: 'Habsiguda Metro (Blue Line), CCMB' },
  { id: 'loc-n5', name: 'Uppal', type: 'metro', zone: 'North', latitude: 17.4018, longitude: 78.5601, nearbyTransport: 'Uppal Metro Terminal, Uppal Ring Road Depot' },
  { id: 'loc-n6', name: 'Nacharam', type: 'area', zone: 'North', latitude: 17.4330, longitude: 78.5650, nearbyTransport: 'Nacharam Industrial Corridor, Bus Route 3' },
  { id: 'loc-n7', name: 'Sainikpuri', type: 'area', zone: 'North', latitude: 17.4895, longitude: 78.5470, nearbyTransport: 'Sainikpuri Bus Stop, Near ECIL' },
  { id: 'loc-n8', name: 'AS Rao Nagar', type: 'area', zone: 'North', latitude: 17.4850, longitude: 78.5460, nearbyTransport: 'AS Rao Nagar Bus Stand, Radhika Multiplex' },
  { id: 'loc-n9', name: 'ECIL', type: 'bus_hub', zone: 'North', latitude: 17.4720, longitude: 78.5690, nearbyTransport: 'ECIL Major Bus Terminal, City Connector 16A' },
  { id: 'loc-n10', name: 'Kapra', type: 'area', zone: 'North', latitude: 17.4980, longitude: 78.5670, nearbyTransport: 'Kapra Lake, ECIL Feeder Bus' },
  { id: 'loc-n11', name: 'Alwal', type: 'area', zone: 'North', latitude: 17.5020, longitude: 78.5080, nearbyTransport: 'Alwal Railway Station, MMTS' },
  { id: 'loc-n12', name: 'Bowenpally', type: 'area', zone: 'North', latitude: 17.4690, longitude: 78.4860, nearbyTransport: 'Bowenpally Check Post, Bus Route 22' },
  { id: 'loc-n13', name: 'Suchitra', type: 'area', zone: 'North', latitude: 17.5140, longitude: 78.4790, nearbyTransport: 'Suchitra Junction, Medchal Highway Corridor' },
  { id: 'loc-n14', name: 'Kompally', type: 'area', zone: 'North', latitude: 17.5380, longitude: 78.4840, nearbyTransport: 'Kompally Bus Stop, NH 44' },

  // --- West Hyderabad ---
  { id: 'loc-w1', name: 'Kukatpally', type: 'metro', zone: 'West', latitude: 17.4932, longitude: 78.4018, nearbyTransport: 'Kukatpally Metro (Red Line), Bus Stop 219' },
  { id: 'loc-w2', name: 'KPHB', type: 'metro', zone: 'West', latitude: 17.4920, longitude: 78.3960, nearbyTransport: 'KPHB Colony Metro (Red Line), JNTU Link' },
  { id: 'loc-w3', name: 'JNTU', type: 'college', zone: 'West', latitude: 17.4950, longitude: 78.3910, nearbyTransport: 'JNTU Metro (Red Line), University Main Gate' },
  { id: 'loc-w4', name: 'Miyapur', type: 'metro', zone: 'West', latitude: 17.4968, longitude: 78.3614, nearbyTransport: 'Miyapur Metro Terminal, Allwyn Colony Bus Depot' },
  { id: 'loc-w5', name: 'Chandanagar', type: 'area', zone: 'West', latitude: 17.4920, longitude: 78.3390, nearbyTransport: 'Chandanagar MMTS Station, Bus Route 218' },
  { id: 'loc-w6', name: 'Hafeezpet', type: 'railway', zone: 'West', latitude: 17.4810, longitude: 78.3540, nearbyTransport: 'Hafeezpet MMTS Railway Station, Kondapur Link' },
  { id: 'loc-w7', name: 'Kondapur', type: 'area', zone: 'West', latitude: 17.4640, longitude: 78.3580, nearbyTransport: 'Kondapur RTO, Hitec City Feeder' },
  { id: 'loc-w8', name: 'Kothaguda', type: 'area', zone: 'West', latitude: 17.4600, longitude: 78.3690, nearbyTransport: 'Kothaguda Botanical Garden, Flyover' },
  { id: 'loc-w9', name: 'Gachibowli', type: 'bus_hub', zone: 'West', latitude: 17.4401, longitude: 78.3489, nearbyTransport: 'Gachibowli Stadium, Outer Ring Road, WaveRock Buses' },
  { id: 'loc-w10', name: 'Financial District', type: 'area', zone: 'West', latitude: 17.4220, longitude: 78.3370, nearbyTransport: 'Wipro Circle, US Consulate, WaveRock Buses' },
  { id: 'loc-w11', name: 'Nanakramguda', type: 'area', zone: 'West', latitude: 17.4180, longitude: 78.3490, nearbyTransport: 'Nanakramguda Circle, ORR Junction' },
  { id: 'loc-w12', name: 'Narsingi', type: 'area', zone: 'West', latitude: 17.3880, longitude: 78.3610, nearbyTransport: 'Narsingi Junction, CBIT Feeder Route' },
  { id: 'loc-w13', name: 'Kokapet', type: 'area', zone: 'West', latitude: 17.3990, longitude: 78.3360, nearbyTransport: 'Kokapet SEZ, Gandipet Road' },
  { id: 'loc-w14', name: 'Manikonda', type: 'area', zone: 'West', latitude: 17.4040, longitude: 78.3890, nearbyTransport: 'Manikonda Marrichettu Junction' },
  { id: 'loc-w15', name: 'Raidurg', type: 'metro', zone: 'West', latitude: 17.4410, longitude: 78.3780, nearbyTransport: 'Raidurg Metro Terminal (Blue Line), Mindspace SEZ' },
  { id: 'loc-w16', name: 'Madhapur', type: 'metro', zone: 'West', latitude: 17.4485, longitude: 78.3908, nearbyTransport: 'Madhapur Metro (Blue Line), Durgam Cheruvu' },
  { id: 'loc-w17', name: 'HITEC City', type: 'metro', zone: 'West', latitude: 17.4474, longitude: 78.3762, nearbyTransport: 'HITEC City Metro, Cyber Towers, MMTS Link' },
  { id: 'loc-w18', name: 'Ameerpet', type: 'metro', zone: 'West', latitude: 17.4375, longitude: 78.4482, nearbyTransport: 'Ameerpet Major Metro Interchange (Red & Blue Lines)' },
  { id: 'loc-w19', name: 'Begumpet', type: 'railway', zone: 'West', latitude: 17.4448, longitude: 78.4682, nearbyTransport: 'Begumpet MMTS Station, Prakash Nagar Metro' },
  { id: 'loc-w20', name: 'Punjagutta', type: 'metro', zone: 'West', latitude: 17.4262, longitude: 78.4526, nearbyTransport: 'Punjagutta Metro (Red Line), Hyderabad Central' },
  { id: 'loc-w21', name: 'Patancheru', type: 'bus_hub', zone: 'West', latitude: 17.5280, longitude: 78.2650, nearbyTransport: 'Patancheru Major Bus Station, Industrial Depot' },
  { id: 'loc-w22', name: 'Balanagar', type: 'metro', zone: 'West', latitude: 17.4690, longitude: 78.4350, nearbyTransport: 'Balanagar Metro (Red Line), IDPL' },

  // --- South Hyderabad ---
  { id: 'loc-s1', name: 'Mehdipatnam', type: 'bus_hub', zone: 'South', latitude: 17.3916, longitude: 78.4402, nearbyTransport: 'Mehdipatnam Major Bus Depot (Airport Line & IT Corridor)' },
  { id: 'loc-s2', name: 'Tolichowki', type: 'area', zone: 'South', latitude: 17.4010, longitude: 78.4120, nearbyTransport: 'Tolichowki Flyover, Bus Route 216' },
  { id: 'loc-s3', name: 'Attapur', type: 'area', zone: 'South', latitude: 17.3680, longitude: 78.4350, nearbyTransport: 'Attapur Ring Road, Pillar 125' },
  { id: 'loc-s4', name: 'Rajendranagar', type: 'area', zone: 'South', latitude: 17.3190, longitude: 78.4060, nearbyTransport: 'PJTSAU Campus, Bus Route 94' },
  { id: 'loc-s5', name: 'Aramghar', type: 'bus_hub', zone: 'South', latitude: 17.3290, longitude: 78.4410, nearbyTransport: 'Aramghar Junction, Airport Highway Bus Point' },
  { id: 'loc-s6', name: 'Shamshabad', type: 'airport', zone: 'South', latitude: 17.2403, longitude: 78.4294, nearbyTransport: 'Rajiv Gandhi International Airport (RGIA Pushpak Aerobus)' },
  { id: 'loc-s7', name: 'LB Nagar', type: 'metro', zone: 'South', latitude: 17.3480, longitude: 78.5520, nearbyTransport: 'LB Nagar Metro Terminal (Red Line), National Highway Hub' },
  { id: 'loc-s8', name: 'Dilsukhnagar', type: 'metro', zone: 'South', latitude: 17.3688, longitude: 78.5247, nearbyTransport: 'Dilsukhnagar Metro (Red Line), Dilsukhnagar Bus Depot' },
  { id: 'loc-s9', name: 'Kothapet', type: 'metro', zone: 'South', latitude: 17.3640, longitude: 78.5360, nearbyTransport: 'Chaitanyapuri Metro, Fruit Market' },
  { id: 'loc-s10', name: 'Vanasthalipuram', type: 'area', zone: 'South', latitude: 17.3320, longitude: 78.5710, nearbyTransport: 'Vanasthalipuram Complex, Bus Route 100' },
  { id: 'loc-s11', name: 'Hayathnagar', type: 'bus_hub', zone: 'South', latitude: 17.3250, longitude: 78.6010, nearbyTransport: 'Hayathnagar Bus Depot 1 & 2' },
  { id: 'loc-s12', name: 'Nagole', type: 'metro', zone: 'South', latitude: 17.3825, longitude: 78.5630, nearbyTransport: 'Nagole Metro Terminal (Blue Line), Ring Road' },

  // --- Old City ---
  { id: 'loc-oc1', name: 'Charminar', type: 'area', zone: 'Old City', latitude: 17.3616, longitude: 78.4747, nearbyTransport: 'Charminar Bus Stand, Bus Route 2Z, 9M' },
  { id: 'loc-oc2', name: 'Falaknuma', type: 'railway', zone: 'Old City', latitude: 17.3310, longitude: 78.4680, nearbyTransport: 'Falaknuma MMTS Railway Station, Palace Link' },
  { id: 'loc-oc3', name: 'Chandrayangutta', type: 'area', zone: 'Old City', latitude: 17.3240, longitude: 78.4810, nearbyTransport: 'Chandrayangutta Flyover, DRDO Buses' },
  { id: 'loc-oc4', name: 'Bahadurpura', type: 'area', zone: 'Old City', latitude: 17.3510, longitude: 78.4520, nearbyTransport: 'Nehru Zoological Park, Bus Route 7Z' },
  { id: 'loc-oc5', name: 'Yakutpura', type: 'railway', zone: 'Old City', latitude: 17.3580, longitude: 78.4980, nearbyTransport: 'Yakutpura MMTS Station, Old City Inner Line' },
  { id: 'loc-oc6', name: 'Malakpet', type: 'metro', zone: 'Old City', latitude: 17.3750, longitude: 78.4990, nearbyTransport: 'Malakpet Metro (Red Line), Malakpet Railway' },
  { id: 'loc-oc7', name: 'Chanchalguda', type: 'area', zone: 'Old City', latitude: 17.3730, longitude: 78.4910, nearbyTransport: 'Chanchalguda Central Jail Junction, Bus 94' },
  { id: 'loc-oc8', name: 'Santoshnagar', type: 'area', zone: 'Old City', latitude: 17.3480, longitude: 78.5080, nearbyTransport: 'Santoshnagar Crossroads, IS Sadan' },
  { id: 'loc-oc9', name: 'Saidabad', type: 'area', zone: 'Old City', latitude: 17.3630, longitude: 78.5120, nearbyTransport: 'Saidabad Bus Stop, Dhobi Ghat' },
  { id: 'loc-oc10', name: 'Moghalpura', type: 'area', zone: 'Old City', latitude: 17.3560, longitude: 78.4790, nearbyTransport: 'Moghalpura Fire Station, Charminar Walkway' },
  { id: 'loc-oc11', name: 'Shah Ali Banda', type: 'area', zone: 'Old City', latitude: 17.3520, longitude: 78.4730, nearbyTransport: 'Shah Ali Banda Clock Tower, Bus 9M' },

  // --- East Hyderabad ---
  { id: 'loc-e1', name: 'Ramanthapur', type: 'area', zone: 'East', latitude: 17.3940, longitude: 78.5410, nearbyTransport: 'Ramanthapur TV Studio, Bus 115' },
  { id: 'loc-e2', name: 'Amberpet', type: 'area', zone: 'East', latitude: 17.3910, longitude: 78.5190, nearbyTransport: 'Amberpet 6 No. Junction, Bus Route 113' },
  { id: 'loc-e3', name: 'Kachiguda', type: 'railway', zone: 'East', latitude: 17.3900, longitude: 78.5020, nearbyTransport: 'Kacheguda Railway Station (Major Express & MMTS)' },
  { id: 'loc-e4', name: 'Nallakunta', type: 'area', zone: 'East', latitude: 17.4010, longitude: 78.5060, nearbyTransport: 'Nallakunta Vegetable Market, Fever Hospital' },
  { id: 'loc-e5', name: 'Vidyanagar', type: 'railway', zone: 'East', latitude: 17.4060, longitude: 78.5140, nearbyTransport: 'Vidyanagar MMTS Station, Shivam Road' },
  { id: 'loc-e6', name: 'Musheerabad', type: 'metro', zone: 'East', latitude: 17.4180, longitude: 78.5020, nearbyTransport: 'Musheerabad Metro (Green Line), Gandhi Hospital' },
  { id: 'loc-e7', name: 'Bagh Amberpet', type: 'area', zone: 'East', latitude: 17.3870, longitude: 78.5150, nearbyTransport: 'Bagh Amberpet Bus Stop' },
  { id: 'loc-e8', name: 'Pocharam', type: 'area', zone: 'East', latitude: 17.4480, longitude: 78.6650, nearbyTransport: 'Infosys SEZ Campus, Ghatkesar Highway' },

  // --- Important Transport Hubs ---
  { id: 'hub-1', name: 'Secunderabad Railway Station', type: 'railway', zone: 'North', latitude: 17.4399, longitude: 78.4983, nearbyTransport: 'South Central Railway HQ, Metro Line 2 & 3' },
  { id: 'hub-2', name: 'Hyderabad Deccan / Nampally Railway Station', type: 'railway', zone: 'Central', latitude: 17.3840, longitude: 78.4682, nearbyTransport: 'Platform 1-6, Nampally Metro' },
  { id: 'hub-3', name: 'Kacheguda Railway Station', type: 'railway', zone: 'East', latitude: 17.3900, longitude: 78.5020, nearbyTransport: 'Historical Rail Terminal, City Buses 102, 107' },
  { id: 'hub-4', name: 'MGBS', type: 'bus_hub', zone: 'Central', latitude: 17.3785, longitude: 78.4808, nearbyTransport: 'Mahatma Gandhi Bus Station (Interstate Hub), MGBS Metro Interchange' },
  { id: 'hub-5', name: 'JBS', type: 'bus_hub', zone: 'North', latitude: 17.4490, longitude: 78.5010, nearbyTransport: 'Jubilee Bus Station (North Telangana Hub), JBS Parade Ground Metro' },
  { id: 'hub-6', name: 'Ameerpet Metro', type: 'metro', zone: 'West', latitude: 17.4375, longitude: 78.4482, nearbyTransport: 'Lines: Red (Miyapur-LB Nagar) & Blue (Nagole-Raidurg)' },
  { id: 'hub-7', name: 'Raidurg Metro', type: 'metro', zone: 'West', latitude: 17.4410, longitude: 78.3780, nearbyTransport: 'Blue Line Terminal, Mindspace Junction' },
  { id: 'hub-8', name: 'Miyapur Metro', type: 'metro', zone: 'West', latitude: 17.4968, longitude: 78.3614, nearbyTransport: 'Red Line Terminal, Miyapur Depot' },
  { id: 'hub-9', name: 'Kukatpally Metro', type: 'metro', zone: 'West', latitude: 17.4932, longitude: 78.4018, nearbyTransport: 'Red Line, Asian GPR Mall' },
  { id: 'hub-10', name: 'LB Nagar Metro', type: 'metro', zone: 'South', latitude: 17.3480, longitude: 78.5520, nearbyTransport: 'Red Line Terminal, Sagar Ring Road' },
  { id: 'hub-11', name: 'Nagole Metro', type: 'metro', zone: 'South', latitude: 17.3825, longitude: 78.5630, nearbyTransport: 'Blue Line Terminal, Inner Ring Road' },
  { id: 'hub-12', name: 'Uppal Metro', type: 'metro', zone: 'North', latitude: 17.4018, longitude: 78.5601, nearbyTransport: 'Blue Line, Rajiv Gandhi Stadium' },
  { id: 'hub-13', name: 'Dilsukhnagar Metro', type: 'metro', zone: 'South', latitude: 17.3688, longitude: 78.5247, nearbyTransport: 'Red Line, Sai Baba Temple' },
  { id: 'hub-14', name: 'Lingampally', type: 'railway', zone: 'West', latitude: 17.4925, longitude: 78.3182, nearbyTransport: 'Lingampally Major Rail Terminal (MMTS West Hub)' },
  { id: 'hub-15', name: 'Rajiv Gandhi International Airport', type: 'airport', zone: 'South', latitude: 17.2403, longitude: 78.4294, nearbyTransport: 'Pushpak Airport Liner (AC Buses to Secunderabad & Hitec City)' },

  // --- College & Student Locations ---
  { id: 'col-1', name: 'JNTUH', type: 'college', zone: 'West', latitude: 17.4950, longitude: 78.3910, nearbyTransport: 'JNTU College Metro (Red Line), 200m walk' },
  { id: 'col-2', name: 'JNTUH Sultanpur', type: 'college', zone: 'West', latitude: 17.6520, longitude: 77.9820, nearbyTransport: 'Sultanpur Sangareddy Road, Bus from Patancheru' },
  { id: 'col-3', name: 'University of Hyderabad', type: 'college', zone: 'West', latitude: 17.4560, longitude: 78.3280, nearbyTransport: 'HCU Main Gate Bus Stop (216, 218D, 222)' },
  { id: 'col-4', name: 'Osmania University', type: 'college', zone: 'East', latitude: 17.4120, longitude: 78.5270, nearbyTransport: 'Tarnaka Metro (1.2 km), OU Campus Bus Station' },
  { id: 'col-5', name: 'IIT Hyderabad', type: 'college', zone: 'West', latitude: 17.5950, longitude: 78.1250, nearbyTransport: 'Kandi NH 65, Special Campus Shuttles from Lingampally' },
  { id: 'col-6', name: 'IIIT Hyderabad', type: 'college', zone: 'West', latitude: 17.4450, longitude: 78.3490, nearbyTransport: 'Gachibowli Stadium Stop (500m), Raidurg Metro (3 km)' },
  { id: 'col-7', name: 'CBIT', type: 'college', zone: 'West', latitude: 17.3910, longitude: 78.3190, nearbyTransport: 'Gandipet Transit Stand (Bus 120, 288, 220)' },
  { id: 'col-8', name: 'VNR VJIET', type: 'college', zone: 'West', latitude: 17.5380, longitude: 78.3850, nearbyTransport: 'Bachupally Crossroads, Feeder Bus from Miyapur Metro' },
  { id: 'col-9', name: 'Malla Reddy University', type: 'college', zone: 'North', latitude: 17.5580, longitude: 78.4550, nearbyTransport: 'Maisammaguda Bus Depot (Route 229, 24M)' },
  { id: 'col-10', name: 'Anurag University', type: 'college', zone: 'East', latitude: 17.4200, longitude: 78.6550, nearbyTransport: 'Venkatapur Ghatkesar Road (Bus 280, 281)' },
  { id: 'col-11', name: 'SNIST', type: 'college', zone: 'East', latitude: 17.4450, longitude: 78.6850, nearbyTransport: 'Yamnampet Ghatkesar (Bus 280 from ECIL/Secunderabad)' },
  { id: 'col-12', name: 'GRIET', type: 'college', zone: 'West', latitude: 17.5250, longitude: 78.3680, nearbyTransport: 'Bachupally Road, Bus 198 from Miyapur' },
  { id: 'col-13', name: 'IARE', type: 'college', zone: 'North', latitude: 17.5980, longitude: 78.4230, nearbyTransport: 'Dundigal Air Force Station Road (Bus 230D)' },
  { id: 'col-14', name: 'CMR College', type: 'college', zone: 'North', latitude: 17.5990, longitude: 78.4890, nearbyTransport: 'Kandlakoya Medchal Highway (Bus 229, 24B)' },
  { id: 'col-15', name: 'BVRIT', type: 'college', zone: 'West', latitude: 17.7280, longitude: 78.2580, nearbyTransport: 'Narsapur Road (College Buses & RTC 231 from JNTU)' },
  { id: 'col-16', name: 'MLR Institute of Technology', type: 'college', zone: 'North', latitude: 17.5940, longitude: 78.4350, nearbyTransport: 'Dundigal Road, Feeder from JNTU/Suchitra' },
];

// Compatibility bridge for previous components
export const INITIAL_STOPS: Stop[] = HYDERABAD_LOCATIONS.map(loc => ({
  stop_id: loc.id,
  stop_name: loc.name,
  latitude: loc.latitude,
  longitude: loc.longitude,
  city: 'Hyderabad',
  area: loc.zone,
  zone: loc.zone,
  connected_modes: loc.type === 'metro'
    ? ['bus', 'metro']
    : loc.type === 'railway'
    ? ['bus', 'train', 'metro']
    : ['bus'],
}));

// ==========================================
// 2. NETWORK ROUTES CATALOG
// ==========================================
export const NETWORK_ROUTES_CATALOG = [
  {
    route_id: 'R216D',
    route_number: '216D',
    transport_type: 'bus' as const,
    name: 'Secunderabad Express Bus',
    source: 'Ameerpet',
    destination: 'Secunderabad',
    frequency_mins: 30,
    stops: ['Ameerpet', 'Begumpet', 'Paradise', 'Secunderabad'],
    operating_hours: '05:30 - 23:30',
    distance_km: 14.5,
    base_fare: 25,
  },
  {
    route_id: 'R218',
    route_number: '218',
    transport_type: 'bus' as const,
    name: 'Mehdipatnam Corridor Bus',
    source: 'Ameerpet',
    destination: 'Mehdipatnam',
    frequency_mins: 30,
    stops: ['Ameerpet', 'Punjagutta', 'Banjara Hills', 'Masab Tank', 'Mehdipatnam'],
    operating_hours: '05:00 - 23:45',
    distance_km: 11.2,
    base_fare: 20,
  },
  {
    route_id: 'R219',
    route_number: '219',
    transport_type: 'bus' as const,
    name: 'Kukatpally Semi-Direct Bus',
    source: 'Ameerpet',
    destination: 'Kukatpally',
    frequency_mins: 30,
    stops: ['Ameerpet', 'SR Nagar', 'Erragadda', 'Bharat Nagar', 'Moosapet', 'Kukatpally'],
    operating_hours: '05:45 - 23:15',
    distance_km: 15.2,
    base_fare: 25,
  },
  {
    route_id: 'RMETRO_BLUE',
    route_number: 'Blue Line',
    transport_type: 'metro' as const,
    name: 'Hyderabad Metro Blue Corridor',
    source: 'Nagole',
    destination: 'Raidurg / Hitec City',
    frequency_mins: 4,
    stops: ['Ameerpet', 'Begumpet', 'Prakash Nagar', 'Rasoolpura', 'Paradise', 'Parade Ground', 'Secunderabad East'],
    operating_hours: '06:00 - 23:00',
    distance_km: 13.0,
    base_fare: 35,
  },
  {
    route_id: 'RMETRO_RED',
    route_number: 'Red Line',
    transport_type: 'metro' as const,
    name: 'Hyderabad Metro Red Corridor',
    source: 'Miyapur',
    destination: 'LB Nagar',
    frequency_mins: 4,
    stops: ['Miyapur', 'JNTU', 'KPHB', 'Kukatpally', 'Ameerpet', 'Lakdikapul', 'Nampally', 'MGBS', 'Dilsukhnagar', 'LB Nagar'],
    operating_hours: '06:00 - 23:00',
    distance_km: 29.0,
    base_fare: 60,
  },
  {
    route_id: 'RMMTS_SUBURBAN',
    route_number: 'MMTS-01',
    transport_type: 'train' as const,
    name: 'Suburban Rail MMTS Express',
    source: 'Lingampally',
    destination: 'Secunderabad',
    frequency_mins: 25,
    stops: ['Lingampally', 'Hitec City', 'Begumpet', 'James Street', 'Secunderabad'],
    operating_hours: '05:15 - 22:45',
    distance_km: 17.8,
    base_fare: 15,
  },
  {
    route_id: 'R_AS_RAO',
    route_number: '16A / 24B',
    transport_type: 'bus' as const,
    name: 'ECIL - AS Rao Nagar - Secunderabad Trunk Bus',
    source: 'ECIL',
    destination: 'Secunderabad',
    frequency_mins: 30,
    stops: ['ECIL', 'AS Rao Nagar', 'Sainikpuri', 'Neredmet', 'Malkajgiri', 'Secunderabad'],
    operating_hours: '05:00 - 23:30',
    distance_km: 13.5,
    base_fare: 22,
  },
];

// ==========================================
// 3. POPULAR STUDENT & COMMUTER JOURNEYS
// ==========================================
export const POPULAR_HYDERABAD_JOURNEYS = [
  { from: 'AS Rao Nagar', to: 'Secunderabad', badge: 'Daily Commute' },
  { from: 'ECIL', to: 'Secunderabad', badge: 'High Frequency' },
  { from: 'Miyapur', to: 'HITEC City', badge: 'Tech Corridor' },
  { from: 'Kukatpally', to: 'Gachibowli', badge: 'Student & IT' },
  { from: 'JNTUH', to: 'Ameerpet', badge: 'College Route' },
  { from: 'LB Nagar', to: 'Secunderabad', badge: 'Cross-City Line' },
  { from: 'Dilsukhnagar', to: 'Charminar', badge: 'Heritage Line' },
  { from: 'Mehdipatnam', to: 'Gachibowli', badge: 'Direct Feeder' },
  { from: 'Patancheru', to: 'Miyapur', badge: 'Industrial Link' },
  { from: 'Secunderabad', to: 'Charminar', badge: 'Historic Arterial' },
  { from: 'Kacheguda', to: 'HITEC City', badge: 'Express MMTS' },
  { from: 'Rajiv Gandhi International Airport', to: 'HITEC City', badge: 'Pushpak AC' },
  { from: 'AS Rao Nagar', to: 'Gachibowli', badge: 'Featured Challenge' },
  { from: 'Osmania University', to: 'Gachibowli', badge: 'Inter-University' },
];

// Helper functions for 24-hour time handling
export function formatTimeFromOffset(baseHour = 10, baseMin = 17, addMinutes = 0): string {
  const totalMinutes = ((baseHour * 60 + baseMin + addMinutes) % 1440 + 1440) % 1440;
  const hours24 = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  const pad = (n: number) => n.toString().padStart(2, '0');
  return `${pad(hours24)}:${pad(mins)}`;
}

export function parseTimeToMinutes(timeStr: string): number {
  if (!timeStr) return 10 * 60 + 17; // 10:17
  const cleaned = timeStr.trim().toUpperCase();
  const match = cleaned.match(/(\d{1,2}):(\d{2})/);
  if (!match) return 10 * 60 + 17;
  let hour = parseInt(match[1], 10);
  const min = parseInt(match[2], 10);
  if (cleaned.includes('PM') && hour < 12) hour += 12;
  if (cleaned.includes('AM') && hour === 12) hour = 0;
  return ((hour * 60 + min) % 1440 + 1440) % 1440;
}

// Student Route Score Calculation Engine
export function calculateStudentRouteScore(
  fare: number,
  journeyTimeMin: number,
  changesCount: number,
  walkingDistanceKm: number,
  priorityMode: PriorityMode = 'balanced'
): { score: number; scoreTag: string } {
  // Normalize parameters to 0-100 scales (higher is better)
  const costScore = Math.max(0, Math.min(100, 100 - (fare / 80) * 100));
  const timeScore = Math.max(0, Math.min(100, 100 - (journeyTimeMin / 120) * 100));
  const transferScore = Math.max(0, Math.min(100, 100 - changesCount * 30));
  const walkingScore = Math.max(0, Math.min(100, 100 - (walkingDistanceKm / 2.0) * 100));

  let finalScore = 0;
  let scoreTag = 'Balanced Option';

  if (priorityMode === 'budget') {
    // 45% cost, 20% time, 20% transfers, 15% walking
    finalScore = costScore * 0.45 + timeScore * 0.20 + transferScore * 0.20 + walkingScore * 0.15;
    if (fare <= 25) scoreTag = 'Best Budget Pick';
    else if (fare <= 40) scoreTag = 'Pocket Friendly';
    else scoreTag = 'Moderate Fare';
  } else if (priorityMode === 'time') {
    // 15% cost, 50% time, 20% transfers, 15% walking
    finalScore = costScore * 0.15 + timeScore * 0.50 + transferScore * 0.20 + walkingScore * 0.15;
    if (journeyTimeMin <= 35) scoreTag = 'Fastest Transit';
    else if (journeyTimeMin <= 50) scoreTag = 'Quick Route';
    else scoreTag = 'Standard Speed';
  } else {
    // Balanced: 30% cost, 30% time, 20% transfers, 20% walking
    finalScore = costScore * 0.30 + timeScore * 0.30 + transferScore * 0.20 + walkingScore * 0.20;
    if (changesCount === 0 && fare <= 30) scoreTag = 'Best Value Direct';
    else if (finalScore >= 85) scoreTag = 'Top Student Choice';
    else scoreTag = 'Reliable Journey';
  }

  return {
    score: Math.round(Math.max(10, Math.min(99, finalScore))),
    scoreTag,
  };
}

// ==========================================
// 4. MULTI-MODAL HYDERABAD ROUTE GENERATOR
// ==========================================
export function getRouteOptions(
  source: string,
  destination: string,
  transportFilter: TransportType = 'all',
  preferences: JourneyPreferences = {
    shortestTime: false,
    fewerChanges: false,
    lowestFare: false,
    lessWaiting: false,
    transportMode: 'all',
    sortBy: 'recommended',
    priorityMode: 'balanced',
    maxBudget: null,
    maxChanges: null,
    maxWalkingKm: null,
    preferredDepartureTime: '10:17',
  },
  isLiveActive: boolean = true
): RouteOption[] {
  const cleanSource = source.trim() || 'Ameerpet';
  const cleanDest = destination.trim() || 'Secunderabad';
  const sLow = cleanSource.toLowerCase();
  const dLow = cleanDest.toLowerCase();

  // 1. PRIMARY DYNAMIC GRAPH ROUTING ENGINE (Multi-criteria time-dependent graph search)
  // Evaluates all network patterns, transfers, walking legs, time buffers, and fare slabs
  const dynamicRoutes = searchDynamicTransitRoutes({
    sourceName: cleanSource,
    destName: cleanDest,
    departureTimeStr: preferences.preferredDepartureTime,
    travelDate: preferences.travelDate,
    preferences: {
      ...preferences,
      transportMode: transportFilter !== 'all' ? transportFilter : preferences.transportMode,
    },
  });

  if (dynamicRoutes.length > 0) {
    return dynamicRoutes;
  }

  // Route collection fallback
  let routes: RouteOption[] = [];

  // 1. FIRST PRIORITY: Query verified TGSRTC bus schedules & Airport Pushpak services
  const directTGSRTC = findDirectTGSRTCSchedules(cleanSource, cleanDest);
  if (directTGSRTC.length > 0) {
    directTGSRTC.forEach((match, idx) => {
      routes.push(convertTGSRTCToRouteOption(match, idx, cleanSource, cleanDest));
    });
  }

  // If few or no direct buses found, query verified 1-transfer connections
  if (routes.length < 2) {
    const transferTGSRTC = findTransferTGSRTCSchedules(cleanSource, cleanDest);
    transferTGSRTC.forEach((transfer, idx) => {
      routes.push(convertTransferToRouteOption(transfer, routes.length + idx, cleanSource, cleanDest));
    });
  }

  // 2. Fallback / Multi-modal additions if no verified TGSRTC match exists
  if (routes.length === 0) {
  // Check for specific highlighted search: AS Rao Nagar -> Gachibowli
  if (
    (sLow.includes('as rao') || sLow.includes('ecil') || sLow.includes('sainikpuri')) &&
    (dLow.includes('gachibowli') || dLow.includes('financial district') || dLow.includes('iiit') || dLow.includes('cbit'))
  ) {
    routes = [
      {
        id: 'hyd-as-gach-1',
        route_label: 'Route 1 — Bus → Metro → Bus (Fast Multi-Modal)',
        summary_line: '🚌 Bus 16A → 🚇 Metro Blue Line → 🚌 Feeder 216',
        journey_time_min: 95, // 1 hr 35 min as requested in prompt!
        distance_km: 29.4,
        changes_count: 2,
        waiting_time_min: 6,
        expected_arrival_time: '10:23',
        data_source: isLiveActive ? 'live' : 'scheduled',
        fare_inr: 55, // matches prompt ₹55!
        co2_saved_kg: 4.8,
        departure_time: '10:23',
        arrival_destination_time: '11:58',
        walking_distance_km: 0.45,
        total_stops_count: 22,
        route_score: 92,
        score_tag: 'Recommended Student Route',
        notes: 'High-speed transit via Secunderabad East & Raidurg Metro with comfortable AC feeder.',
        all_stops: [
          'AS Rao Nagar Stand',
          'Neredmet X Roads',
          'Secunderabad East Metro',
          'Begumpet Metro',
          'Ameerpet Interchange',
          'Madhapur Metro',
          'Raidurg Metro Terminal',
          'Bio Diversity Junction',
          'Gachibowli Telecom Nagar',
          cleanDest
        ],
        segments: [
          {
            transport_type: 'bus',
            line_number: '16A',
            line_name: 'TSRTC City Bus',
            from_stop: cleanSource,
            to_stop: 'Secunderabad East Metro',
            duration_min: 30,
            stops_count: 8,
            intermediate_stops: ['Sainikpuri', 'Neredmet', 'Malkajgiri'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.485, longitude: 78.546, speed_kmh: 28, next_stop: 'Neredmet', updated_seconds_ago: 22 },
          },
          {
            transport_type: 'metro',
            line_number: 'Blue Line',
            line_name: 'Hyderabad Metro Rail Corridor III',
            from_stop: 'Secunderabad East Metro',
            to_stop: 'Raidurg Metro Terminal',
            duration_min: 42,
            stops_count: 11,
            intermediate_stops: ['Begumpet', 'Ameerpet', 'Madhapur', 'Hitec City'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.442, longitude: 78.471, speed_kmh: 60, next_stop: 'Begumpet', updated_seconds_ago: 10 },
          },
          {
            transport_type: 'bus',
            line_number: '216 / Cyber Line',
            line_name: 'Gachibowli IT Feeder Bus',
            from_stop: 'Raidurg Metro Terminal',
            to_stop: cleanDest,
            duration_min: 23,
            stops_count: 3,
            intermediate_stops: ['Bio Diversity', 'Gachibowli ORR Junction'],
            vehicle_status: 'on-time',
          }
        ]
      },
      {
        id: 'hyd-as-gach-2',
        route_label: 'Route 2 — Direct City Bus (Fewer Changes)',
        summary_line: '🚌 Bus 10H/216 Corridor Express',
        journey_time_min: 115,
        distance_km: 32.1,
        changes_count: 1,
        waiting_time_min: 10,
        expected_arrival_time: '10:27',
        data_source: isLiveActive ? 'live' : 'scheduled',
        fare_inr: 40,
        co2_saved_kg: 3.9,
        departure_time: '10:27',
        arrival_destination_time: '12:22',
        walking_distance_km: 0.3,
        total_stops_count: 28,
        route_score: 86,
        score_tag: 'Best Budget Pick',
        notes: 'Lower fare route with single transfer at Secunderabad Gurudwara.',
        all_stops: ['AS Rao Nagar', 'Malkajgiri', 'Secunderabad Station', 'Punjagutta', 'Tolichowki', 'Mehdipatnam', 'Gachibowli ORR', cleanDest],
        segments: [
          {
            transport_type: 'bus',
            line_number: '24B',
            line_name: 'AS Rao Nagar Express',
            from_stop: cleanSource,
            to_stop: 'Secunderabad Station',
            duration_min: 35,
            stops_count: 9,
            intermediate_stops: ['Sainikpuri', 'Malkajgiri'],
          },
          {
            transport_type: 'bus',
            line_number: '216',
            line_name: 'Gachibowli Link',
            from_stop: 'Secunderabad Station',
            to_stop: cleanDest,
            duration_min: 80,
            stops_count: 19,
            intermediate_stops: ['Punjagutta', 'Mehdipatnam', 'Tolichowki'],
          }
        ]
      },
      {
        id: 'hyd-as-gach-3',
        route_label: 'Route 3 — Bus + MMTS Train + Metro (Rail Hybrid)',
        summary_line: '🚌 Bus 16A → 🚆 MMTS Rail → 🚇 Metro Blue Line',
        journey_time_min: 88,
        distance_km: 30.5,
        changes_count: 2,
        waiting_time_min: 12,
        expected_arrival_time: '10:29',
        data_source: isLiveActive ? 'estimated' : 'scheduled',
        fare_inr: 45,
        co2_saved_kg: 5.2,
        departure_time: '10:29',
        arrival_destination_time: '11:57',
        walking_distance_km: 0.6,
        total_stops_count: 14,
        route_score: 89,
        score_tag: 'Fastest Transit',
        notes: 'Avoids road traffic jams during rush hours via South Central MMTS railway.',
        all_stops: ['AS Rao Nagar', 'Secunderabad Rail Terminal', 'Begumpet MMTS', 'HITEC City Station', 'Gachibowli', cleanDest],
        segments: [
          {
            transport_type: 'bus',
            line_number: '16A',
            line_name: 'Feeder',
            from_stop: cleanSource,
            to_stop: 'Secunderabad Rail Terminal',
            duration_min: 28,
            stops_count: 6,
            intermediate_stops: ['Malkajgiri'],
          },
          {
            transport_type: 'train',
            line_number: 'MMTS-47155',
            line_name: 'Suburban Local Rail',
            from_stop: 'Secunderabad Rail Terminal',
            to_stop: 'HITEC City Station',
            duration_min: 32,
            stops_count: 5,
            intermediate_stops: ['Begumpet', 'Nature Cure', 'Fateh Nagar'],
          },
          {
            transport_type: 'bus',
            line_number: 'Feeder F2',
            line_name: 'HITEC City to Gachibowli Feeder',
            from_stop: 'HITEC City Station',
            to_stop: cleanDest,
            duration_min: 28,
            stops_count: 3,
            intermediate_stops: ['Kothaguda', 'Botanical Garden'],
          }
        ]
      }
    ];
  }
  // 2. Check for Ameerpet <-> Secunderabad (matches user's original exact example)
  else if (
    (sLow.includes('ameerpet') && dLow.includes('secunderabad')) ||
    (sLow.includes('secunderabad') && dLow.includes('ameerpet'))
  ) {
    routes = [
      {
        id: 'route-1',
        route_label: 'Route 1 — Direct Bus',
        summary_line: '🚌 Bus 216D',
        journey_time_min: 32,
        distance_km: 14.5,
        changes_count: 0,
        waiting_time_min: 8,
        expected_arrival_time: '10:25',
        data_source: 'scheduled',
        fare_inr: 25,
        co2_saved_kg: 1.8,
        departure_time: '10:25',
        arrival_destination_time: '10:57',
        walking_distance_km: 0.2,
        total_stops_count: 4,
        route_score: 93,
        score_tag: 'Best Budget Pick',
        all_stops: [cleanSource, 'Begumpet', 'Paradise', cleanDest],
        notes: 'Direct transit on main arterial corridor. Frequency every 12 mins.',
        segments: [
          {
            transport_type: 'bus',
            line_number: '216D',
            line_name: 'Secunderabad Direct City Bus',
            from_stop: cleanSource,
            to_stop: cleanDest,
            duration_min: 32,
            stops_count: 4,
            intermediate_stops: ['Begumpet', 'Paradise'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.438, longitude: 78.449, speed_kmh: 24, next_stop: cleanSource, updated_seconds_ago: 38 },
          },
        ],
      },
      {
        id: 'route-2',
        route_label: 'Route 2 — Bus + Metro',
        summary_line: '🚌 Bus 218 → 🚇 Metro Blue Line',
        journey_time_min: 27,
        distance_km: 12.8,
        changes_count: 1,
        waiting_time_min: 5,
        expected_arrival_time: '10:22',
        data_source: isLiveActive ? 'live' : 'scheduled',
        fare_inr: 45,
        co2_saved_kg: 2.3,
        departure_time: '10:22',
        arrival_destination_time: '10:49',
        walking_distance_km: 0.35,
        total_stops_count: 6,
        route_score: 95,
        score_tag: 'Fastest Transit',
        all_stops: [cleanSource, 'Punjagutta Concourse', 'Begumpet', 'Prakash Nagar', 'Paradise', cleanDest],
        notes: 'Fastest combined transit. Quick 3-minute concourse transfer at Punjagutta.',
        segments: [
          {
            transport_type: 'bus',
            line_number: '218',
            line_name: 'Feeder Bus to Concourse',
            from_stop: cleanSource,
            to_stop: 'Punjagutta Concourse',
            duration_min: 9,
            stops_count: 2,
            intermediate_stops: [],
            vehicle_status: 'on-time',
          },
          {
            transport_type: 'metro',
            line_number: 'Blue Line',
            line_name: 'Corridor III Blue Express',
            from_stop: 'Punjagutta Concourse',
            to_stop: cleanDest,
            duration_min: 18,
            stops_count: 4,
            intermediate_stops: ['Begumpet', 'Prakash Nagar', 'Paradise'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.442, longitude: 78.471, speed_kmh: 58, next_stop: 'Begumpet', updated_seconds_ago: 14 },
          },
        ],
      },
      {
        id: 'route-3',
        route_label: 'Route 3 — Fewer Changes',
        summary_line: '🚌 Bus 219',
        journey_time_min: 38,
        distance_km: 15.2,
        changes_count: 0,
        waiting_time_min: 12,
        expected_arrival_time: '10:29',
        data_source: isLiveActive ? 'live' : 'scheduled',
        fare_inr: 20,
        co2_saved_kg: 1.6,
        departure_time: '10:29',
        arrival_destination_time: '11:07',
        walking_distance_km: 0.15,
        total_stops_count: 6,
        route_score: 91,
        score_tag: 'Least Walking',
        all_stops: [cleanSource, 'SR Nagar', 'Sanjeeva Reddy Nagar', 'Balkampet', 'Fateh Nagar', cleanDest],
        notes: 'Guaranteed zero changes with minimal walking required.',
        segments: [
          {
            transport_type: 'bus',
            line_number: '219',
            line_name: 'City Link Service',
            from_stop: cleanSource,
            to_stop: cleanDest,
            duration_min: 38,
            stops_count: 5,
            intermediate_stops: ['SR Nagar', 'Sanjeeva Reddy Nagar', 'Balkampet', 'Fateh Nagar'],
            vehicle_status: 'on-time',
          },
        ],
      },
      {
        id: 'route-4',
        route_label: 'Route 4 — Direct Metro Blue Line',
        summary_line: '🚇 Metro Blue Line Express',
        journey_time_min: 21,
        distance_km: 11.5,
        changes_count: 0,
        waiting_time_min: 4,
        expected_arrival_time: '10:21',
        data_source: isLiveActive ? 'live' : 'scheduled',
        fare_inr: 35,
        co2_saved_kg: 2.6,
        departure_time: '10:21',
        arrival_destination_time: '10:42',
        walking_distance_km: 0.25,
        total_stops_count: 6,
        route_score: 98,
        score_tag: 'Top Student Choice',
        all_stops: [cleanSource, 'Begumpet', 'Prakash Nagar', 'Rasoolpura', 'Paradise', cleanDest],
        notes: 'Air-conditioned rapid rail with high frequency (every 4 mins).',
        segments: [
          {
            transport_type: 'metro',
            line_number: 'Blue Line',
            line_name: 'Corridor III Express',
            from_stop: cleanSource,
            to_stop: cleanDest,
            duration_min: 21,
            stops_count: 5,
            intermediate_stops: ['Begumpet', 'Prakash Nagar', 'Rasoolpura', 'Paradise'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.440, longitude: 78.455, speed_kmh: 62, next_stop: 'Begumpet', updated_seconds_ago: 8 },
          },
        ],
      },
      {
        id: 'route-5',
        route_label: 'Route 5 — Suburban MMTS Rail',
        summary_line: '🚆 MMTS Train 47155',
        journey_time_min: 24,
        distance_km: 13.9,
        changes_count: 0,
        waiting_time_min: 15,
        expected_arrival_time: '10:32',
        data_source: 'scheduled',
        fare_inr: 10,
        co2_saved_kg: 2.9,
        departure_time: '10:32',
        arrival_destination_time: '10:56',
        walking_distance_km: 0.5,
        total_stops_count: 5,
        route_score: 90,
        score_tag: 'Ultra Cheap (₹10)',
        all_stops: [cleanSource, 'Nature Cure Hospital', 'Begumpet Railway', 'Sanjeevaiah Park', 'James Street', cleanDest],
        notes: 'Lowest fare commuter option. Dedicated rail track with scenic lake views.',
        segments: [
          {
            transport_type: 'train',
            line_number: 'MMTS-47155',
            line_name: 'Hyderabad Suburban Rail',
            from_stop: cleanSource,
            to_stop: cleanDest,
            duration_min: 24,
            stops_count: 5,
            intermediate_stops: ['Nature Cure Hospital', 'Begumpet Railway', 'Sanjeevaiah Park', 'James Street'],
            vehicle_status: 'on-time',
          },
        ],
      }
    ];
  }
  // 3. General intelligent generation for any Hyderabad corridor:
  else {
    // Determine realistic base distance and timing
    const distanceKm = Math.floor(Math.random() * 12) + 8; // 8 - 20 km
    const directBusTime = Math.round(distanceKm * 2.3);
    const metroCombineTime = Math.round(distanceKm * 1.6);
    const railTime = Math.round(distanceKm * 1.8);

    routes = [
      {
        id: `gen-route-1-${Date.now()}`,
        route_label: 'Route 1 — Direct City Bus',
        summary_line: `🚌 Bus 216 / City Route Link`,
        journey_time_min: directBusTime,
        distance_km: distanceKm,
        changes_count: 0,
        waiting_time_min: 8,
        expected_arrival_time: '10:25',
        data_source: 'scheduled',
        fare_inr: Math.min(35, Math.max(15, Math.round(distanceKm * 1.8))),
        co2_saved_kg: 2.1,
        departure_time: '10:25',
        arrival_destination_time: formatTimeFromOffset(10, 25, directBusTime),
        walking_distance_km: 0.25,
        total_stops_count: Math.round(distanceKm / 1.5),
        route_score: 91,
        score_tag: 'Direct No Transfers',
        all_stops: [cleanSource, 'Intermediate Hub', 'Commercial Corridor', cleanDest],
        notes: 'Straightforward street transit connecting both areas directly.',
        segments: [
          {
            transport_type: 'bus',
            line_number: '216',
            line_name: 'TSRTC City Line',
            from_stop: cleanSource,
            to_stop: cleanDest,
            duration_min: directBusTime,
            stops_count: 6,
            intermediate_stops: ['Central Hub', 'Ring Road Junction'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.43, longitude: 78.45, speed_kmh: 26, next_stop: cleanSource, updated_seconds_ago: 35 }
          }
        ]
      },
      {
        id: `gen-route-2-${Date.now()}`,
        route_label: 'Route 2 — Metro + Feeder (Fastest)',
        summary_line: `🚇 Metro Rail → 🚌 Local Feeder Bus`,
        journey_time_min: metroCombineTime,
        distance_km: distanceKm - 1.5,
        changes_count: 1,
        waiting_time_min: 5,
        expected_arrival_time: '10:22',
        data_source: isLiveActive ? 'live' : 'scheduled',
        fare_inr: Math.min(60, Math.max(30, Math.round(distanceKm * 2.4))),
        co2_saved_kg: 3.2,
        departure_time: '10:22',
        arrival_destination_time: formatTimeFromOffset(10, 22, metroCombineTime),
        walking_distance_km: 0.4,
        total_stops_count: 8,
        route_score: 95,
        score_tag: 'Fastest Transit',
        all_stops: [cleanSource, 'Metro Interchange', 'Express Concourse', cleanDest],
        notes: 'Takes advantage of high-speed grade-separated metro tracks.',
        segments: [
          {
            transport_type: 'metro',
            line_number: 'Metro Corridor',
            line_name: 'Hyderabad Metro Express',
            from_stop: cleanSource,
            to_stop: 'Metro Interchange',
            duration_min: Math.round(metroCombineTime * 0.7),
            stops_count: 5,
            intermediate_stops: ['Station 1', 'Station 2'],
            vehicle_status: 'on-time',
            live_gps: { latitude: 17.44, longitude: 78.46, speed_kmh: 58, next_stop: 'Station 1', updated_seconds_ago: 12 }
          },
          {
            transport_type: 'bus',
            line_number: 'Feeder',
            line_name: 'Station Last-Mile Bus',
            from_stop: 'Metro Interchange',
            to_stop: cleanDest,
            duration_min: Math.round(metroCombineTime * 0.3),
            stops_count: 3,
            intermediate_stops: [],
            vehicle_status: 'on-time'
          }
        ]
      },
      {
        id: `gen-route-3-${Date.now()}`,
        route_label: 'Route 3 — Suburban MMTS Rail (Budget Student)',
        summary_line: `🚆 MMTS Train → 🚶 Walk`,
        journey_time_min: railTime,
        distance_km: distanceKm + 2.0,
        changes_count: 0,
        waiting_time_min: 14,
        expected_arrival_time: '10:31',
        data_source: 'scheduled',
        fare_inr: 10,
        co2_saved_kg: 3.8,
        departure_time: '10:31',
        arrival_destination_time: formatTimeFromOffset(10, 31, railTime),
        walking_distance_km: 0.6,
        total_stops_count: 5,
        route_score: 93,
        score_tag: 'Cheapest Route (₹10)',
        all_stops: [cleanSource, 'Rail Halt 1', 'Rail Halt 2', cleanDest],
        notes: 'Very economical for college students with monthly rail pass options.',
        segments: [
          {
            transport_type: 'train',
            line_number: 'MMTS-Local',
            line_name: 'South Central Railway MMTS',
            from_stop: cleanSource,
            to_stop: cleanDest,
            duration_min: railTime,
            stops_count: 5,
            intermediate_stops: ['Platform Stop A', 'Platform Stop B'],
            vehicle_status: 'on-time'
          }
        ]
      }
    ];
  }
  }

  // Recalculate dynamic student scores for all routes
  routes = routes.map(route => {
    const { score, scoreTag } = calculateStudentRouteScore(
      route.fare_inr,
      route.journey_time_min,
      route.changes_count,
      route.walking_distance_km,
      preferences.priorityMode
    );
    return {
      ...route,
      route_score: score,
      score_tag: route.score_tag || scoreTag,
    };
  });

  // Apply transport filter
  const activeTransport = transportFilter !== 'all' ? transportFilter : preferences.transportMode;
  if (activeTransport !== 'all') {
    routes = routes.filter(route =>
      route.segments.some(seg => seg.transport_type === activeTransport)
    );
  }

  // Apply student constraint filters
  if (preferences.maxBudget !== null && preferences.maxBudget > 0) {
    routes = routes.filter(r => r.fare_inr <= (preferences.maxBudget as number));
  }

  if (preferences.maxChanges !== null) {
    routes = routes.filter(r => r.changes_count <= (preferences.maxChanges as number));
  }

  if (preferences.maxWalkingKm !== null && preferences.maxWalkingKm > 0) {
    routes = routes.filter(r => r.walking_distance_km <= (preferences.maxWalkingKm as number));
  }

  if (preferences.fewerChanges) {
    routes = routes.filter(r => r.changes_count === 0);
  }

  if (preferences.lessWaiting) {
    routes = routes.filter(r => r.waiting_time_min <= 8);
  }

  // Sorting based on student preferences (Section 9):
  if (preferences.sortBy === 'cheapest' || preferences.lowestFare) {
    routes.sort((a, b) => a.fare_inr - b.fare_inr || a.journey_time_min - b.journey_time_min);
  } else if (preferences.sortBy === 'fastest' || preferences.shortestTime) {
    routes.sort((a, b) => a.journey_time_min - b.journey_time_min || a.fare_inr - b.fare_inr);
  } else if (preferences.sortBy === 'fewest_changes') {
    routes.sort((a, b) => a.changes_count - b.changes_count || a.journey_time_min - b.journey_time_min);
  } else if (preferences.sortBy === 'least_walking') {
    routes.sort((a, b) => a.walking_distance_km - b.walking_distance_km);
  } else {
    // Default Balanced
    routes.sort((a, b) => b.route_score - a.route_score);
  }

  // Realistic Route Label Assignment (Section 9: Cheapest, Fastest, Fewest Changes, Balanced)
  if (routes.length > 0) {
    const minFare = Math.min(...routes.map(r => r.fare_inr));
    const minTime = Math.min(...routes.map(r => r.journey_time_min));

    routes = routes.map((r, idx) => {
      let tag = 'Balanced';
      if (r.fare_inr === minFare && routes.length > 1) {
        tag = 'Cheapest';
      } else if (r.journey_time_min === minTime) {
        tag = 'Fastest';
      } else if (r.changes_count === 0) {
        tag = 'Fewest Changes';
      } else {
        tag = 'Balanced';
      }
      return {
        ...r,
        score_tag: tag,
      };
    });
  }

  return routes;
}

// Generate departures for Hyderabad stops
export function getDeparturesForStop(
  stopName: string,
  currentTimeStr: string = '10:17',
  forceLiveFeed: boolean = true
): StopDeparture[] {
  const currentMins = parseTimeToMinutes(currentTimeStr);

  // 1. First priority: Check TripDatabase for individual trips and unique departure schedules
  const dbTrips = tripDatabase.getUpcomingDeparturesForStop(stopName, currentMins, 8);
  if (dbTrips.length > 0) {
    return dbTrips.map(match => {
      const isLive = forceLiveFeed && match.waitingMins <= 25;
      const scheduledArrival = match.stopTiming.departure_time;
      const isVerified = match.trip.is_verified_data;
      return {
        service_id: match.trip.service_id || match.trip.trip_id,
        service_number: match.trip.route_number,
        transport_type: (match.routePattern?.transport_type || 'bus') as 'bus' | 'train' | 'metro',
        destination: match.destinationStopName,
        scheduled_arrival: scheduledArrival,
        live_arrival: isLive ? scheduledArrival : undefined,
        waiting_minutes: match.waitingMins,
        data_source: isLive ? 'live' : (isVerified ? 'scheduled' : 'estimated'),
        status: match.waitingMins <= 5 ? 'approaching' : 'on-time',
        delay_minutes: 0,
        platform: match.routePattern?.transport_type === 'metro' ? 'Platform 1' : 'Bay 1',
        occupancy: match.waitingMins < 10 ? 'High' : 'Moderate',
        last_updated_secs: 15,
        bus_id: match.trip.bus_id,
        trip_id: match.trip.trip_id,
        interval_from_prev_mins: match.trip.interval_from_prev_trip_mins,
      };
    });
  }

  const lowerStop = stopName.toLowerCase().trim();

  const rawDepartures: {
    service_id: string;
    service_number: string;
    transport_type: 'bus' | 'train' | 'metro';
    destination: string;
    scheduledOffset: number;
    liveOffsetAdjust?: number;
    platform?: string;
    occupancy?: 'Low' | 'Moderate' | 'High';
    isLiveEligible: boolean;
  }[] = [];

  if (lowerStop.includes('as rao') || lowerStop.includes('ecil')) {
    rawDepartures.push(
      {
        service_id: 'dep-ecil-1',
        service_number: '16A',
        transport_type: 'bus',
        destination: 'Secunderabad Junction',
        scheduledOffset: 4,
        liveOffsetAdjust: 0,
        platform: 'Bay 1',
        occupancy: 'High',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-ecil-2',
        service_number: '24B',
        transport_type: 'bus',
        destination: 'Mehdipatnam (via Bowenpally)',
        scheduledOffset: 9,
        liveOffsetAdjust: 1,
        platform: 'Bay 3',
        occupancy: 'Moderate',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-ecil-3',
        service_number: '280',
        transport_type: 'bus',
        destination: 'Ghatkesar / SNIST Campus',
        scheduledOffset: 15,
        liveOffsetAdjust: 0,
        platform: 'Stand 5',
        occupancy: 'Moderate',
        isLiveEligible: false,
      }
    );
  } else if (lowerStop.includes('gachibowli')) {
    rawDepartures.push(
      {
        service_id: 'dep-gach-1',
        service_number: '216',
        transport_type: 'bus',
        destination: 'Secunderabad (via Mehdipatnam)',
        scheduledOffset: 5,
        platform: 'Stadium Stop',
        occupancy: 'High',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-gach-2',
        service_number: 'Cyber Shuttle 1',
        transport_type: 'bus',
        destination: 'Raidurg Metro Concourse',
        scheduledOffset: 3,
        platform: 'Bay 2',
        occupancy: 'Moderate',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-gach-3',
        service_number: '222',
        transport_type: 'bus',
        destination: 'Koti Women\'s College',
        scheduledOffset: 14,
        platform: 'Bay 4',
        occupancy: 'Moderate',
        isLiveEligible: false,
      }
    );
  } else if (lowerStop.includes('secunderabad')) {
    rawDepartures.push(
      {
        service_id: 'dep-s1',
        service_number: '216D',
        transport_type: 'bus',
        destination: 'Ameerpet',
        scheduledOffset: 6,
        platform: 'Platform B',
        occupancy: 'Moderate',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-s2',
        service_number: 'MMTS-01',
        transport_type: 'train',
        destination: 'Lingampally / Hitec City',
        scheduledOffset: 11,
        platform: 'Track 6',
        occupancy: 'High',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-s3',
        service_number: 'Green Line',
        transport_type: 'metro',
        destination: 'MGBS Terminal',
        scheduledOffset: 4,
        platform: 'Platform 1',
        occupancy: 'Low',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-s4',
        service_number: '49M',
        transport_type: 'bus',
        destination: 'Mehdipatnam',
        scheduledOffset: 16,
        platform: 'Stand 5',
        occupancy: 'Moderate',
        isLiveEligible: false,
      }
    );
  } else {
    // Default Ameerpet / Central stop data (as in prompt specifications)
    rawDepartures.push(
      {
        service_id: 'dep-1',
        service_number: '216D',
        transport_type: 'bus',
        destination: 'Secunderabad',
        scheduledOffset: 8, // 10:25, exactly 8 mins wait
        platform: 'Bay 3',
        occupancy: 'Moderate',
        isLiveEligible: false, // shows Scheduled as per prompt instructions
      },
      {
        service_id: 'dep-2',
        service_number: '218',
        transport_type: 'bus',
        destination: 'Mehdipatnam',
        scheduledOffset: 20, // 10:37, 20 mins wait
        platform: 'Bay 1',
        occupancy: 'High',
        isLiveEligible: true, // shows Live
      },
      {
        service_id: 'dep-3',
        service_number: '219',
        transport_type: 'bus',
        destination: 'Kukatpally',
        scheduledOffset: 27, // 10:44, 27 mins wait
        platform: 'Bay 4',
        occupancy: 'Low',
        isLiveEligible: true, // shows Live
      },
      {
        service_id: 'dep-4',
        service_number: 'Blue Line',
        transport_type: 'metro',
        destination: 'Nagole / Secunderabad East',
        scheduledOffset: 5,
        platform: 'Platform 2 (Concourse)',
        occupancy: 'Moderate',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-5',
        service_number: 'Red Line',
        transport_type: 'metro',
        destination: 'LB Nagar',
        scheduledOffset: 9,
        platform: 'Platform 1',
        occupancy: 'Moderate',
        isLiveEligible: true,
      },
      {
        service_id: 'dep-6',
        service_number: '10H',
        transport_type: 'bus',
        destination: 'Secunderabad (via Sanathnagar)',
        scheduledOffset: 14,
        platform: 'Bay 2',
        occupancy: 'Low',
        isLiveEligible: false,
      }
    );
  }

  return rawDepartures.map(d => {
    const schedMins = (currentMins + d.scheduledOffset) % 1440;
    const hours24 = Math.floor(schedMins / 60);
    const mins = schedMins % 60;
    const scheduledArrivalStr = `${hours24.toString().padStart(2, '0')}:${mins.toString().padStart(2, '0')}`;

    let isLive = forceLiveFeed && d.isLiveEligible;
    let actualWaitingMinutes = d.scheduledOffset;
    let liveArrivalStr: string | undefined = undefined;
    let dataSource: DataSourceType = isLive ? 'live' : 'scheduled';

    if (isLive) {
      const liveMins = (schedMins + (d.liveOffsetAdjust || 0)) % 1440;
      const lHours24 = Math.floor(liveMins / 60);
      const lMins = liveMins % 60;
      liveArrivalStr = `${lHours24.toString().padStart(2, '0')}:${lMins.toString().padStart(2, '0')}`;
      actualWaitingMinutes = Math.max(0, liveMins - currentMins);
    } else {
      actualWaitingMinutes = Math.max(0, schedMins - currentMins);
    }

    return {
      service_id: d.service_id,
      service_number: d.service_number,
      transport_type: d.transport_type,
      destination: d.destination,
      scheduled_arrival: scheduledArrivalStr,
      live_arrival: liveArrivalStr,
      waiting_minutes: actualWaitingMinutes,
      data_source: dataSource,
      status: (d.liveOffsetAdjust && d.liveOffsetAdjust > 3) ? 'delayed' : 'on-time',
      delay_minutes: d.liveOffsetAdjust && d.liveOffsetAdjust > 0 ? d.liveOffsetAdjust : 0,
      platform: d.platform,
      occupancy: d.occupancy,
      last_updated_secs: Math.floor(Math.random() * 45) + 12,
    };
  });
}

// Sample student saved journeys for fast demo
export const SAMPLE_SAVED_JOURNEYS: SavedJourney[] = [
  {
    id: 'sample-saved-1',
    source: 'AS Rao Nagar',
    destination: 'Secunderabad',
    custom_label: 'Morning Bus Commute (Direct)',
    created_at: '2026-09-20 08:20',
    route: {
      id: 'saved-r1',
      route_label: 'Route 1 — Direct Fast Corridor',
      summary_line: '🚌 Bus 16A/24B (TSRTC Express)',
      journey_time_min: 28,
      distance_km: 11.2,
      changes_count: 0,
      waiting_time_min: 5,
      expected_arrival_time: '10:22',
      data_source: 'live',
      fare_inr: 25,
      co2_saved_kg: 1.8,
      departure_time: '10:22',
      arrival_destination_time: '10:50',
      departure_datetime: '2026-09-21 10:22',
      arrival_datetime: '2026-09-21 10:50',
      timezone: 'Asia/Kolkata',
      next_day_arrival: false,
      days_offset: 0,
      walking_distance_km: 0.2,
      total_stops_count: 14,
      route_score: 96,
      score_tag: 'Best Student Value',
      all_stops: ['AS Rao Nagar', 'Neredmet X Roads', 'Malkajgiri', 'Secunderabad Station'],
      notes: 'Direct college corridor with high service frequency.',
      segments: [
        {
          transport_type: 'bus',
          line_number: '16A',
          line_name: 'TSRTC City Express',
          from_stop: 'AS Rao Nagar',
          to_stop: 'Secunderabad Station',
          duration_min: 28,
          stops_count: 14,
          intermediate_stops: ['Neredmet X Roads', 'Malkajgiri'],
          vehicle_status: 'on-time',
          departure_time: '10:22',
          arrival_time: '10:50',
          departure_datetime: '2026-09-21 10:22',
          arrival_datetime: '2026-09-21 10:50',
        }
      ]
    }
  },
  {
    id: 'sample-saved-2',
    source: 'JNTUH Kukatpally',
    destination: 'HITEC City',
    custom_label: 'Tech Internship & Labs Route',
    created_at: '2026-09-21 09:15',
    route: {
      id: 'saved-r2',
      route_label: 'Route 2 — Metro Link',
      summary_line: '🚇 Metro Red Line → 🚇 Blue Line',
      journey_time_min: 34,
      distance_km: 13.5,
      changes_count: 1,
      waiting_time_min: 3,
      expected_arrival_time: '10:20',
      data_source: 'live',
      fare_inr: 45,
      co2_saved_kg: 2.9,
      departure_time: '10:20',
      arrival_destination_time: '10:54',
      departure_datetime: '2026-09-21 10:20',
      arrival_datetime: '2026-09-21 10:54',
      timezone: 'Asia/Kolkata',
      next_day_arrival: false,
      days_offset: 0,
      walking_distance_km: 0.35,
      total_stops_count: 10,
      route_score: 93,
      score_tag: 'Fastest Transit',
      all_stops: ['JNTU College Metro', 'KPHB Colony', 'Ameerpet Metro Interchange', 'Madhapur', 'HITEC City'],
      notes: 'Air-conditioned rapid commute via Ameerpet interchange.',
      segments: [
        {
          transport_type: 'metro',
          line_number: 'Red Line',
          line_name: 'Miyapur to LB Nagar',
          from_stop: 'JNTU College Metro',
          to_stop: 'Ameerpet Metro Interchange',
          duration_min: 16,
          stops_count: 5,
          intermediate_stops: ['KPHB Colony', 'Kukatpally', 'Bharat Nagar'],
          vehicle_status: 'on-time',
          departure_time: '10:20',
          arrival_time: '10:36',
        },
        {
          transport_type: 'metro',
          line_number: 'Blue Line',
          line_name: 'Nagole to Raidurg',
          from_stop: 'Ameerpet Metro Interchange',
          to_stop: 'HITEC City',
          duration_min: 18,
          stops_count: 5,
          intermediate_stops: ['Madhapur', 'Durgam Cheruvu'],
          vehicle_status: 'on-time',
          departure_time: '10:36',
          arrival_time: '10:54',
        }
      ]
    }
  }
];

export const SAMPLE_RECENT_JOURNEYS: import('../types/transit').RecentJourneyPlan[] = [
  {
    id: 'recent-1',
    source: 'AS Rao Nagar',
    destination: 'Gachibowli',
    fare_inr: 45,
    transport_type: 'all',
    route_summary: 'Bus 16A + Metro Blue Line',
    duration_min: 62,
    timestamp: 'Today, 10:14',
    frequency_per_month: 4
  },
  {
    id: 'recent-2',
    source: 'JNTUH Kukatpally',
    destination: 'Ameerpet',
    fare_inr: 35,
    transport_type: 'metro',
    route_summary: 'Metro Red Line (Direct)',
    duration_min: 16,
    timestamp: 'Today, 09:40',
    frequency_per_month: 6
  },
  {
    id: 'recent-3',
    source: 'Secunderabad',
    destination: 'HCU Gachibowli',
    fare_inr: 30,
    transport_type: 'bus',
    route_summary: 'TGSRTC Bus 216',
    duration_min: 52,
    timestamp: 'Yesterday',
    frequency_per_month: 2
  }
];

