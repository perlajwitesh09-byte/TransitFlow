import { NETWORK_ROUTE_PATTERNS, NETWORK_NODES, RoutePattern } from './networkDatabase';
import { TGSRTC_BUS_SCHEDULES } from './tgsrtcData';
import { TripRecord, TripStopTime, RouteTimetable, DatabaseValidationReport } from '../types/transit';
import { formatMinutesTo24Hour, parseTimeToMinutes, computeKolkataDateTime } from '../utils/time24';

/**
 * CONFIGURABLE REALISTIC INTERVAL PARAMETERS
 * Standard Hyderabad bus intervals vary naturally between 20 and 60 minutes.
 */
export const MIN_INTERVAL_MINS = 20;
export const MAX_INTERVAL_MINS = 60;

/**
 * Map node ID to human-readable stop name.
 */
const nodeNameMap = new Map<string, string>();
NETWORK_NODES.forEach(n => {
  nodeNameMap.set(n.id, n.name);
});

export function getStopNameById(stopId: string): string {
  return nodeNameMap.get(stopId) || stopId.replace('stop-', '').replace(/-/g, ' ');
}

/**
 * Deterministic pseudo-random number generator for stable, realistic timetable generation.
 */
function pseudoRandom(seed: number): number {
  const x = Math.sin(seed++) * 10000;
  return x - Math.floor(x);
}

/**
 * Generate a realistic vehicle registration ID (TGSRTC depot convention).
 */
function generateBusId(routeNumber: string, tripIndex: number, operator: string): string {
  if (operator === 'Hyderabad Metro') {
    return `HMR-TRAIN-${100 + (tripIndex % 30)}`;
  }
  if (operator === 'SCR MMTS') {
    return `MMTS-RAKE-${47000 + (tripIndex * 12)}`;
  }
  const depotCodes = ['HC', 'MD', 'KU', 'SC', 'MN', 'KG', 'UP', 'RJ'];
  const depot = depotCodes[tripIndex % depotCodes.length];
  const busNumber = 4000 + ((tripIndex * 137 + 59) % 5000);
  return `TS-09-Z-${busNumber} (${depot})`;
}

/**
 * Build stop-by-stop times for an individual trip starting at a specific departure minute.
 */
export function buildTripStopTimes(
  tripId: string,
  pattern: RoutePattern,
  startDepMins: number
): { stopTimes: TripStopTime[]; finalArrMins: number; totalDistanceKm: number } {
  const stopTimes: TripStopTime[] = [];
  let currentDepMins = startDepMins;
  let cumDistanceKm = 0;

  for (let i = 0; i < pattern.stops.length; i++) {
    const stopId = pattern.stops[i];
    const stopName = getStopNameById(stopId);

    if (i === 0) {
      // Origin stop
      stopTimes.push({
        trip_id: tripId,
        stop_id: stopId,
        stop_name: stopName,
        stop_sequence: 1,
        arrival_time: formatMinutesTo24Hour(currentDepMins),
        departure_time: formatMinutesTo24Hour(currentDepMins),
        arrival_mins: currentDepMins,
        departure_mins: currentDepMins,
        distance_from_origin_km: 0,
      });
    } else {
      const hopDist = pattern.distance_km_per_hop[i - 1] ?? 2.0;
      cumDistanceKm += hopDist;

      // Realistic travel time: hop distance * speed factor + small variable traffic variance
      const baseHopTime = pattern.base_hop_time_mins || 6;
      // Slight speed adjustment for hop distance
      const hopDuration = Math.max(3, Math.round((hopDist / 2.5) * baseHopTime));
      const arrMins = currentDepMins + hopDuration;

      // Dwell time: 1 minute at intermediate stops, 0 at terminal
      const isTerminal = i === pattern.stops.length - 1;
      const dwellMins = isTerminal ? 0 : 1;
      const depMins = arrMins + dwellMins;

      stopTimes.push({
        trip_id: tripId,
        stop_id: stopId,
        stop_name: stopName,
        stop_sequence: i + 1,
        arrival_time: formatMinutesTo24Hour(arrMins),
        departure_time: formatMinutesTo24Hour(depMins),
        arrival_mins: arrMins,
        departure_mins: depMins,
        distance_from_origin_km: Math.round(cumDistanceKm * 10) / 10,
      });

      currentDepMins = depMins;
    }
  }

  const finalArrMins = stopTimes[stopTimes.length - 1].arrival_mins;
  return { stopTimes, finalArrMins, totalDistanceKm: cumDistanceKm };
}

/**
 * In-memory repository of all individual trips across Hyderabad transit.
 */
class TripDatabase {
  private trips: TripRecord[] = [];
  private tripsByRouteId: Map<string, TripRecord[]> = new Map();
  private isInitialized = false;

  constructor() {
    this.initializeDatabase();
  }

  private initializeDatabase() {
    if (this.isInitialized) return;
    this.trips = [];
    this.tripsByRouteId.clear();

    // 1. Process Verified TGSRTC Schedules first (Requirement 3: REAL DATA HAS PRIORITY)
    this.loadVerifiedTGSRTCSchedules();

    // 2. Generate Realistic Individual Trips for all Route Patterns (Requirement 1, 2, 4, 5, 13, 14)
    this.generateNetworkTrips();

    // 3. Sort all trips chronologically by departure_mins (Requirement 8)
    this.trips.sort((a, b) => a.departure_mins - b.departure_mins);

    // 4. Group by Route ID
    for (const trip of this.trips) {
      if (!this.tripsByRouteId.has(trip.route_id)) {
        this.tripsByRouteId.set(trip.route_id, []);
      }
      this.tripsByRouteId.get(trip.route_id)!.push(trip);
    }

    // 5. Compute intervals from previous trip for each route
    for (const [_, routeTrips] of this.tripsByRouteId.entries()) {
      routeTrips.sort((a, b) => a.departure_mins - b.departure_mins);
      for (let i = 0; i < routeTrips.length; i++) {
        if (i > 0) {
          routeTrips[i].interval_from_prev_trip_mins = routeTrips[i].departure_mins - routeTrips[i - 1].departure_mins;
        }
      }
    }

    this.isInitialized = true;
  }

  /**
   * Load verified official TGSRTC timetable schedules directly.
   * NEVER alters published timings.
   */
  private loadVerifiedTGSRTCSchedules() {
    let verifiedCount = 0;
    for (const sched of TGSRTC_BUS_SCHEDULES) {
      const depMins = parseTimeToMinutes(sched.departureTime);
      const arrMins = parseTimeToMinutes(sched.arrivalTime);
      if (depMins === null || arrMins === null) continue;

      // Match with pattern if available
      const matchingPattern = NETWORK_ROUTE_PATTERNS.find(
        p => p.route_number.toLowerCase() === sched.routeNumber.toLowerCase() &&
             (sched.direction.toLowerCase().includes('manikonda') ? p.direction_label.includes('Manikonda') : true)
      );

      const routeId = matchingPattern?.route_id || `tgsrtc-${sched.routeNumber}-official`;
      const tripId = `OFFICIAL_${sched.serviceNumber || `${sched.routeNumber}_${sched.departureTime.replace(':', '')}`}`;

      let stopTimes: TripStopTime[] = [];
      let totalDist = 0;

      if (sched.stops && sched.stops.length > 0) {
        // Detailed verified stops
        let cumDist = 0;
        sched.stops.forEach((st, idx) => {
          const stopName = typeof st === 'string' ? st : st.stop;
          const sArr = typeof st === 'string' ? sched.departureTime : st.arrival;
          const sDep = typeof st === 'string' ? sched.departureTime : st.departure;
          const aMins = parseTimeToMinutes(sArr) ?? depMins;
          const dMins = parseTimeToMinutes(sDep) ?? aMins;
          cumDist += idx > 0 ? 1.8 : 0;

          stopTimes.push({
            trip_id: tripId,
            stop_id: `stop-verified-${idx}`,
            stop_name: stopName,
            stop_sequence: idx + 1,
            arrival_time: sArr,
            departure_time: sDep,
            arrival_mins: aMins,
            departure_mins: dMins,
            distance_from_origin_km: Math.round(cumDist * 10) / 10,
          });
        });
        totalDist = cumDist;
      } else if (matchingPattern) {
        const built = buildTripStopTimes(tripId, matchingPattern, depMins);
        stopTimes = built.stopTimes;
        totalDist = built.totalDistanceKm;
      }

      let durationMins = arrMins - depMins;
      if (durationMins < 0) durationMins += 1440; // Midnight rollover

      const verifiedTrip: TripRecord = {
        trip_id: tripId,
        route_id: routeId,
        route_number: sched.routeNumber,
        service_id: sched.serviceNumber || `TG-${sched.routeNumber}-${sched.departureTime.replace(':', '')}`,
        bus_id: `TS-09-Z-VERIFIED-${sched.serviceNumber.slice(-2)}`,
        direction: sched.direction,
        service_type: sched.busType || 'Metro Deluxe',
        departure_time: sched.departureTime,
        arrival_time: sched.arrivalTime,
        departure_mins: depMins,
        arrival_mins: arrMins < depMins ? arrMins + 1440 : arrMins,
        duration_mins: durationMins,
        operating_days: sched.operatingDays || ['Daily'],
        is_verified_data: true,
        data_source_label: 'TGSRTC Verified Official Data',
        stop_times: stopTimes,
        via_highlights: sched.viaHighlights,
        notes: `Official Published Schedule (Verified ${sched.lastVerified || '2026-09-21'})`,
      };

      this.trips.push(verifiedTrip);
      verifiedCount++;
    }
  }

  /**
   * Generates realistic, distinct trip schedules for all route patterns.
   * Requirement 1: Every trip has a unique departure and arrival.
   * Requirement 2: Variable realistic intervals (20-60 min) instead of rigid 30-min spacing.
   * Requirement 13 & 14: Different routes have different starting times and schedules.
   */
  private generateNetworkTrips() {
    for (const pattern of NETWORK_ROUTE_PATTERNS) {
      const isBus = pattern.transport_type === 'bus';
      const isMetro = pattern.transport_type === 'metro';
      const isTrain = pattern.transport_type === 'train';

      // Base offset based on route hash to ensure different routes start at different times
      let routeSeed = 0;
      for (let c = 0; c < pattern.route_id.length; c++) {
        routeSeed += pattern.route_id.charCodeAt(c) * (c + 1);
      }

      // Initial departure offset (e.g. 06:08, 06:15, 06:22, etc.)
      const routeStartOffset = (routeSeed % 19); // 0 to 18 min offset
      const firstDeparture = pattern.first_departure_mins + routeStartOffset;
      const lastDeparture = pattern.last_departure_mins;

      let currentDepMins = firstDeparture;
      let tripIndex = 1;

      // Existing departure times on this route (to prevent duplicates with verified trips)
      const existingDepartures = new Set<number>(
        this.trips.filter(t => t.route_id === pattern.route_id).map(t => t.departure_mins)
      );

      while (currentDepMins <= lastDeparture) {
        // Avoid duplicate departure time with any verified trip
        if (existingDepartures.has(currentDepMins)) {
          currentDepMins += 25;
          continue;
        }

        const tripSeqStr = String(tripIndex).padStart(3, '0');
        const tripId = `TRIP_${pattern.route_number.replace(/\s+/g, '_')}_${tripSeqStr}`;
        const busId = generateBusId(pattern.route_number, tripIndex, pattern.operator);
        const serviceId = `TG-${pattern.route_number}-${formatMinutesTo24Hour(currentDepMins).replace(':', '')}`;

        // Build unique stop-by-stop schedule for this trip
        const { stopTimes, finalArrMins } = buildTripStopTimes(tripId, pattern, currentDepMins);

        let durationMins = finalArrMins - currentDepMins;
        if (durationMins <= 0) durationMins += 1440;

        const trip: TripRecord = {
          trip_id: tripId,
          route_id: pattern.route_id,
          route_number: pattern.route_number,
          service_id: serviceId,
          bus_id: busId,
          direction: pattern.direction_label,
          service_type: pattern.service_type,
          departure_time: formatMinutesTo24Hour(currentDepMins),
          arrival_time: formatMinutesTo24Hour(finalArrMins % 1440),
          departure_mins: currentDepMins,
          arrival_mins: finalArrMins,
          duration_mins: durationMins,
          operating_days: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'],
          is_verified_data: false,
          data_source_label: 'DEMO DATA — NOT A REAL-TIME OFFICIAL TIMETABLE',
          stop_times: stopTimes,
          notes: `Individual trip #${tripIndex} • Scheduled Interval`,
        };

        this.trips.push(trip);
        existingDepartures.add(currentDepMins);
        tripIndex++;

        // Compute NEXT departure with realistic variable intervals (Requirement 2 & 14)
        if (isMetro) {
          // Rapid metro: 7 to 12 minutes variable headway
          const metroInterval = 7 + Math.floor(pseudoRandom(routeSeed + tripIndex * 3) * 6);
          currentDepMins += metroInterval;
        } else if (isTrain) {
          // Suburban MMTS: 25 to 45 minutes
          const trainInterval = 25 + Math.floor(pseudoRandom(routeSeed + tripIndex * 7) * 20);
          currentDepMins += trainInterval;
        } else if (pattern.is_airport_pushpak) {
          // Airport Pushpak: 30 to 45 minutes
          const pushpakInterval = 30 + Math.floor(pseudoRandom(routeSeed + tripIndex * 5) * 15);
          currentDepMins += pushpakInterval;
        } else {
          // STANDARD BUS: Realistic variable intervals strictly between MIN_INTERVAL and MAX_INTERVAL (20 - 60 mins)
          // Naturally varied: e.g. 24m, 35m, 42m, 28m, 33m, 48m, 38m, 25m...
          const variationFactors = [24, 33, 40, 28, 48, 32, 26, 38, 52, 35, 44, 30, 27, 42];
          const chosenInterval = variationFactors[(routeSeed + tripIndex) % variationFactors.length];
          const boundedInterval = Math.max(MIN_INTERVAL_MINS, Math.min(MAX_INTERVAL_MINS, chosenInterval));
          currentDepMins += boundedInterval;
        }
      }
    }
  }

  /**
   * Return all trips in the database.
   */
  public getAllTrips(): TripRecord[] {
    return this.trips;
  }

  /**
   * Return all trips for a specific route corridor, sorted chronologically.
   */
  public getTripsForRoute(routeId: string, travelDate?: string): TripRecord[] {
    const list = this.tripsByRouteId.get(routeId) || [];
    if (!travelDate) return list;

    // Filter by day of week if travelDate provided (e.g. "2026-09-21")
    const dateObj = new Date(travelDate);
    if (isNaN(dateObj.getTime())) return list;

    const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const dayName = days[dateObj.getDay()];

    return list.filter(t =>
      t.operating_days.includes('Daily') ||
      t.operating_days.includes(dayName)
    );
  }

  /**
   * Get upcoming trips departing from a specific stop after requested minutes.
   * Requirement 7: Search based on user's selected time.
   * Requirement 8: Chronologically sorted.
   */
  public getUpcomingTripsForStop(
    routeId: string,
    fromStopId: string,
    toStopId: string,
    afterMins: number,
    limit: number = 20,
    travelDate?: string
  ): {
    trip: TripRecord;
    fromStopDepartureMins: number;
    fromStopDepartureTime: string;
    toStopArrivalMins: number;
    toStopArrivalTime: string;
    durationMins: number;
  }[] {
    const routeTrips = this.getTripsForRoute(routeId, travelDate);
    const results: {
      trip: TripRecord;
      fromStopDepartureMins: number;
      fromStopDepartureTime: string;
      toStopArrivalMins: number;
      toStopArrivalTime: string;
      durationMins: number;
    }[] = [];

    for (const trip of routeTrips) {
      // Find fromStop and toStop in trip's stop_times
      const fromIdx = trip.stop_times.findIndex(st => st.stop_id === fromStopId);
      const toIdx = trip.stop_times.findIndex(st => st.stop_id === toStopId);

      if (fromIdx === -1 || toIdx === -1 || fromIdx >= toIdx) {
        continue;
      }

      const fromStopTiming = trip.stop_times[fromIdx];
      const toStopTiming = trip.stop_times[toIdx];

      // Must depart at or after requested time
      if (fromStopTiming.departure_mins >= afterMins) {
        let dur = toStopTiming.arrival_mins - fromStopTiming.departure_mins;
        if (dur <= 0) dur += 1440;

        results.push({
          trip,
          fromStopDepartureMins: fromStopTiming.departure_mins,
          fromStopDepartureTime: fromStopTiming.departure_time,
          toStopArrivalMins: toStopTiming.arrival_mins,
          toStopArrivalTime: toStopTiming.arrival_time,
          durationMins: dur,
        });

        if (results.length >= limit) break;
      }
    }

    return results;
  }

  /**
   * Get all scheduled/upcoming trips passing through a specific stop.
   * Enables WaitingTimeEstimator to display unique bus IDs and realistic spacings.
   */
  public getUpcomingDeparturesForStop(
    stopQuery: string,
    currentMins: number,
    limit: number = 8
  ): {
    trip: TripRecord;
    stopTiming: TripStopTime;
    waitingMins: number;
    destinationStopName: string;
    routePattern?: RoutePattern;
  }[] {
    const q = stopQuery.toLowerCase().trim();
    // Resolve matching stop IDs
    const matchedStopIds = new Set<string>();
    for (const [id, name] of nodeNameMap.entries()) {
      if (id.toLowerCase().includes(q) || name.toLowerCase().includes(q) || q.includes(name.toLowerCase())) {
        matchedStopIds.add(id);
      }
    }

    const matches: {
      trip: TripRecord;
      stopTiming: TripStopTime;
      waitingMins: number;
      destinationStopName: string;
      routePattern?: RoutePattern;
    }[] = [];

    for (const trip of this.trips) {
      // Find if trip visits this stop and departs after currentMins (not terminating here)
      const stIdx = trip.stop_times.findIndex(st => 
        matchedStopIds.has(st.stop_id) || st.stop_name.toLowerCase().includes(q)
      );

      if (stIdx !== -1 && stIdx < trip.stop_times.length - 1) {
        const timing = trip.stop_times[stIdx];
        if (timing.departure_mins >= currentMins && timing.departure_mins <= currentMins + 180) {
          const destTiming = trip.stop_times[trip.stop_times.length - 1];
          const pattern = NETWORK_ROUTE_PATTERNS.find(p => p.route_id === trip.route_id);
          matches.push({
            trip,
            stopTiming: timing,
            waitingMins: timing.departure_mins - currentMins,
            destinationStopName: destTiming.stop_name,
            routePattern: pattern,
          });
        }
      }
    }

    // Sort by departure time / waiting minutes
    matches.sort((a, b) => a.waitingMins - b.waitingMins);

    return matches.slice(0, limit);
  }

  /**
   * Generates a complete Timetable View for a route (Requirement 22).
   */
  public getRouteTimetable(routeId: string): RouteTimetable | null {
    const pattern = NETWORK_ROUTE_PATTERNS.find(p => p.route_id === routeId);
    const trips = this.getTripsForRoute(routeId);

    if (!pattern && trips.length === 0) return null;

    const originStopId = pattern ? pattern.stops[0] : trips[0]?.stop_times[0]?.stop_id || 'Origin';
    const destStopId = pattern ? pattern.stops[pattern.stops.length - 1] : trips[0]?.stop_times[trips[0].stop_times.length - 1]?.stop_id || 'Destination';

    const originName = getStopNameById(originStopId);
    const destName = getStopNameById(destStopId);

    const hasVerified = trips.some(t => t.is_verified_data);
    const routeNumber = pattern?.route_number || trips[0]?.route_number || 'Route';

    // Ensure alias properties are set on all trips
    const enrichedTrips = trips.map(t => ({
      ...t,
      origin_departure_time: t.origin_departure_time || t.departure_time,
      destination_arrival_time: t.destination_arrival_time || t.arrival_time,
    }));

    return {
      route_id: routeId,
      route_number: routeNumber,
      route_name: `${routeNumber} (${originName} ⇄ ${destName})`,
      operator: pattern?.operator || 'TGSRTC',
      service_type: pattern?.service_type || trips[0]?.service_type || 'Metro Express',
      direction: pattern?.direction_label || `${originName} → ${destName}`,
      origin: originName,
      destination: destName,
      is_verified_data: hasVerified,
      is_official_verified: hasVerified,
      data_source_label: hasVerified
        ? 'TGSRTC Verified Official Data'
        : 'DEMO DATA — NOT A REAL-TIME OFFICIAL TIMETABLE',
      trips: enrichedTrips,
    };
  }

  /**
   * Return full timetables for all routes in the system.
   */
  public getAllRoutesTimetables(): RouteTimetable[] {
    const list: RouteTimetable[] = [];
    for (const routeId of this.tripsByRouteId.keys()) {
      const tt = this.getRouteTimetable(routeId);
      if (tt) list.push(tt);
    }
    return list;
  }

  /**
   * DATABASE VALIDATION ENGINE (Requirement 18)
   * Runs 5 comprehensive automated validation checks on the entire database:
   * 1. Duplicate Departure Check
   * 2. Chronological Ordering Check
   * 3. Negative Duration Check
   * 4. Stop Sequence Chronology Check
   * 5. Unrealistic Interval Check (< 15 mins for standard buses)
   */
  public validateDatabase(): DatabaseValidationReport {
    const checks: DatabaseValidationReport['checks'] = [
      {
        checkName: 'Check 1: Duplicate Departure Detection',
        description: 'Verify no two buses on the same route share identical departure times.',
        passed: true,
        issues: [],
      },
      {
        checkName: 'Check 2: Invalid Chronology Check',
        description: 'Verify departure occurs before arrival, accounting for midnight rollovers.',
        passed: true,
        issues: [],
      },
      {
        checkName: 'Check 3: Negative/Zero Duration Check',
        description: 'Verify all trips have strictly positive, realistic duration.',
        passed: true,
        issues: [],
      },
      {
        checkName: 'Check 4: Stop Sequence Chronology',
        description: 'Verify stop-by-stop times are monotonically increasing without retroactive stops.',
        passed: true,
        issues: [],
      },
      {
        checkName: 'Check 5: Unrealistic Interval Check',
        description: 'Verify generated buses on identical routes maintain at least 15 min spacing.',
        passed: true,
        issues: [],
      },
    ];

    // Check 1: Duplicate departure detection
    for (const [routeId, routeTrips] of this.tripsByRouteId.entries()) {
      const seenTimes = new Set<string>();
      for (const trip of routeTrips) {
        if (seenTimes.has(trip.departure_time)) {
          checks[0].passed = false;
          checks[0].issues.push(
            `Duplicate departure detected on route ${routeId}: Trip ${trip.trip_id} at ${trip.departure_time}`
          );
        }
        seenTimes.add(trip.departure_time);
      }
    }

    // Check 2 & 3: Chronology & Duration
    for (const trip of this.trips) {
      if (trip.duration_mins <= 0) {
        checks[2].passed = false;
        checks[2].issues.push(`Trip ${trip.trip_id} has invalid duration: ${trip.duration_mins} min`);
      }
      if (trip.arrival_mins <= trip.departure_mins) {
        checks[1].passed = false;
        checks[1].issues.push(
          `Trip ${trip.trip_id} invalid chronology: dep ${trip.departure_time} arr ${trip.arrival_time}`
        );
      }
    }

    // Check 4: Stop sequence chronology
    for (const trip of this.trips) {
      for (let s = 1; s < trip.stop_times.length; s++) {
        const prev = trip.stop_times[s - 1];
        const curr = trip.stop_times[s];
        if (curr.arrival_mins < prev.departure_mins) {
          checks[3].passed = false;
          checks[3].issues.push(
            `Trip ${trip.trip_id} backwards stop time: Stop ${prev.stop_name} (${prev.departure_time}) to Stop ${curr.stop_name} (${curr.arrival_time})`
          );
        }
      }
    }

    // Check 5: Unrealistic intervals (< 15 mins for buses)
    for (const [routeId, routeTrips] of this.tripsByRouteId.entries()) {
      const pattern = NETWORK_ROUTE_PATTERNS.find(p => p.route_id === routeId);
      if (pattern && pattern.transport_type === 'bus' && !pattern.is_airport_pushpak) {
        for (let i = 1; i < routeTrips.length; i++) {
          const gap = routeTrips[i].departure_mins - routeTrips[i - 1].departure_mins;
          if (gap < 15 && !routeTrips[i].is_verified_data) {
            checks[4].passed = false;
            checks[4].issues.push(
              `Unrealistic interval on bus route ${routeId}: Gap of ${gap} min between ${routeTrips[i - 1].departure_time} and ${routeTrips[i].departure_time}`
            );
          }
        }
      }
    }

    const overallPassed = checks.every(c => c.passed);

    return {
      passed: overallPassed,
      totalTrips: this.trips.length,
      totalRoutes: this.tripsByRouteId.size,
      total_routes_checked: this.tripsByRouteId.size,
      total_trips_checked: this.trips.length,
      trips_with_duplicate_departure: checks[0].issues.length,
      trips_violating_min_interval: checks[4].issues.length,
      checks,
    };
  }
}

export const tripDatabase = new TripDatabase();
