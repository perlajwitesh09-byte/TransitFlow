import { FareRule, LegFareBreakdown, TransportType } from '../types/transit';

/**
 * =========================================================================
 * FARE ENGINE — HYDERABAD PUBLIC TRANSPORT (TGSRTC, METRO, MMTS)
 * Fully dynamic fare calculation based on official published GTFS/fare rules.
 * NO static A->B hard-coded fares. Every fare is derived per leg.
 * =========================================================================
 */

// Official Published Fare Rules Database (adapted to GTFS Fare Attributes & Rules)
export const OFFICIAL_FARE_RULES: FareRule[] = [
  // --- TGSRTC City Ordinary ---
  {
    fare_id: 'fare-tgsrtc-ord-1',
    service_type: 'City Ordinary',
    min_distance_km: 0,
    max_distance_km: 2,
    base_fare: 10,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-ord-2',
    service_type: 'City Ordinary',
    min_distance_km: 2.1,
    max_distance_km: 4,
    base_fare: 15,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-ord-3',
    service_type: 'City Ordinary',
    min_distance_km: 4.1,
    max_distance_km: 8,
    base_fare: 20,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-ord-4',
    service_type: 'City Ordinary',
    min_distance_km: 8.1,
    max_distance_km: 12,
    base_fare: 25,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-ord-5',
    service_type: 'City Ordinary',
    min_distance_km: 12.1,
    max_distance_km: 18,
    base_fare: 30,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-ord-6',
    service_type: 'City Ordinary',
    min_distance_km: 18.1,
    max_distance_km: 25,
    base_fare: 35,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-ord-7',
    service_type: 'City Ordinary',
    min_distance_km: 25.1,
    max_distance_km: 60,
    base_fare: 40,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official City Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },

  // --- TGSRTC Metro Express ---
  {
    fare_id: 'fare-tgsrtc-exp-1',
    service_type: 'Metro Express',
    min_distance_km: 0,
    max_distance_km: 4,
    base_fare: 15,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-exp-2',
    service_type: 'Metro Express',
    min_distance_km: 4.1,
    max_distance_km: 8,
    base_fare: 20,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-exp-3',
    service_type: 'Metro Express',
    min_distance_km: 8.1,
    max_distance_km: 12,
    base_fare: 25,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-exp-4',
    service_type: 'Metro Express',
    min_distance_km: 12.1,
    max_distance_km: 16,
    base_fare: 30,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-exp-5',
    service_type: 'Metro Express',
    min_distance_km: 16.1,
    max_distance_km: 22,
    base_fare: 35,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-exp-6',
    service_type: 'Metro Express',
    min_distance_km: 22.1,
    max_distance_km: 30,
    base_fare: 40,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-exp-7',
    service_type: 'Metro Express',
    min_distance_km: 30.1,
    max_distance_km: 60,
    base_fare: 50,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Express Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },

  // --- TGSRTC Metro Deluxe ---
  {
    fare_id: 'fare-tgsrtc-dlx-1',
    service_type: 'Metro Deluxe',
    min_distance_km: 0,
    max_distance_km: 4,
    base_fare: 20,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Deluxe Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-dlx-2',
    service_type: 'Metro Deluxe',
    min_distance_km: 4.1,
    max_distance_km: 8,
    base_fare: 25,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Deluxe Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-dlx-3',
    service_type: 'Metro Deluxe',
    min_distance_km: 8.1,
    max_distance_km: 14,
    base_fare: 30,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Deluxe Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-dlx-4',
    service_type: 'Metro Deluxe',
    min_distance_km: 14.1,
    max_distance_km: 20,
    base_fare: 35,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Deluxe Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-dlx-5',
    service_type: 'Metro Deluxe',
    min_distance_km: 20.1,
    max_distance_km: 26,
    base_fare: 40,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Deluxe Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-tgsrtc-dlx-6',
    service_type: 'Metro Deluxe',
    min_distance_km: 26.1,
    max_distance_km: 60,
    base_fare: 55,
    currency: 'INR',
    effective_from: '2023-04-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Official Deluxe Fare Table',
    last_updated: '2026-09-21',
    is_verified: true,
  },

  // --- TGSRTC Airport Pushpak AC (Luxury Volvo / Electric AC) ---
  {
    fare_id: 'fare-pushpak-al',
    route_id: 'Pushpak AL',
    service_type: 'Airport Pushpak AC',
    min_distance_km: 0,
    max_distance_km: 50,
    base_fare: 250,
    currency: 'INR',
    effective_from: '2023-01-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Pushpak Airport Tariff',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-pushpak-ac',
    route_id: 'Pushpak AC',
    service_type: 'Airport Pushpak AC',
    min_distance_km: 0,
    max_distance_km: 50,
    base_fare: 270,
    currency: 'INR',
    effective_from: '2023-01-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Pushpak Airport Tariff',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-pushpak-aj',
    route_id: 'Pushpak AJ',
    service_type: 'Airport Pushpak AC',
    min_distance_km: 0,
    max_distance_km: 50,
    base_fare: 300,
    currency: 'INR',
    effective_from: '2023-01-01',
    effective_until: '2027-12-31',
    source: 'TGSRTC Pushpak Airport Tariff',
    last_updated: '2026-09-21',
    is_verified: true,
  },

  // --- Hyderabad Metro Rail (Official L&T Metro Rail Fare Matrix) ---
  {
    fare_id: 'fare-hmr-1',
    service_type: 'Hyderabad Metro',
    min_distance_km: 0,
    max_distance_km: 2,
    base_fare: 10,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-2',
    service_type: 'Hyderabad Metro',
    min_distance_km: 2.1,
    max_distance_km: 4,
    base_fare: 15,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-3',
    service_type: 'Hyderabad Metro',
    min_distance_km: 4.1,
    max_distance_km: 6,
    base_fare: 25,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-4',
    service_type: 'Hyderabad Metro',
    min_distance_km: 6.1,
    max_distance_km: 9,
    base_fare: 30,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-5',
    service_type: 'Hyderabad Metro',
    min_distance_km: 9.1,
    max_distance_km: 12,
    base_fare: 35,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-6',
    service_type: 'Hyderabad Metro',
    min_distance_km: 12.1,
    max_distance_km: 15,
    base_fare: 40,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-7',
    service_type: 'Hyderabad Metro',
    min_distance_km: 15.1,
    max_distance_km: 18,
    base_fare: 45,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-8',
    service_type: 'Hyderabad Metro',
    min_distance_km: 18.1,
    max_distance_km: 21,
    base_fare: 50,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-9',
    service_type: 'Hyderabad Metro',
    min_distance_km: 21.1,
    max_distance_km: 26,
    base_fare: 55,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-hmr-10',
    service_type: 'Hyderabad Metro',
    min_distance_km: 26.1,
    max_distance_km: 50,
    base_fare: 60,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Hyderabad Metro Rail Official Fare Chart',
    last_updated: '2026-09-21',
    is_verified: true,
  },

  // --- South Central Railway (MMTS Suburban Local Trains) ---
  {
    fare_id: 'fare-mmts-1',
    service_type: 'MMTS Suburban',
    min_distance_km: 0,
    max_distance_km: 10,
    base_fare: 5,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Indian Railways MMTS Suburban Tariff',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-mmts-2',
    service_type: 'MMTS Suburban',
    min_distance_km: 10.1,
    max_distance_km: 25,
    base_fare: 10,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Indian Railways MMTS Suburban Tariff',
    last_updated: '2026-09-21',
    is_verified: true,
  },
  {
    fare_id: 'fare-mmts-3',
    service_type: 'MMTS Suburban',
    min_distance_km: 25.1,
    max_distance_km: 60,
    base_fare: 15,
    currency: 'INR',
    effective_from: '2022-01-01',
    effective_until: '2027-12-31',
    source: 'Indian Railways MMTS Suburban Tariff',
    last_updated: '2026-09-21',
    is_verified: true,
  },
];

/**
 * Calculates fare dynamically for a specific transport leg
 */
export function calculateLegFare(
  transportType: 'bus' | 'metro' | 'train' | 'walk',
  serviceType: string,
  distanceKm: number,
  routeId?: string
): { fare: number; fare_status: 'verified' | 'estimated' | 'unavailable' | 'free'; citation: string; rule_id?: string } {
  // Walking is always free
  if (transportType === 'walk' || distanceKm <= 0.05) {
    return {
      fare: 0,
      fare_status: 'free',
      citation: 'Walking connection: ₹0',
    };
  }

  // Normalize service type
  let normService = serviceType.trim();
  if (transportType === 'metro') {
    normService = 'Hyderabad Metro';
  } else if (transportType === 'train') {
    normService = 'MMTS Suburban';
  } else if (normService.includes('Pushpak') || normService.includes('Airport')) {
    normService = 'Airport Pushpak AC';
  } else if (normService.includes('Deluxe')) {
    normService = 'Metro Deluxe';
  } else if (normService.includes('Express')) {
    normService = 'Metro Express';
  } else if (normService.includes('Ordinary') || normService.includes('City')) {
    normService = 'City Ordinary';
  }

  // Check route-specific fare first (e.g. Pushpak AL, AC, AJ)
  if (routeId) {
    const routeRule = OFFICIAL_FARE_RULES.find(
      r => r.route_id && routeId.toLowerCase().includes(r.route_id.toLowerCase())
    );
    if (routeRule) {
      return {
        fare: routeRule.base_fare,
        fare_status: 'verified',
        citation: `${routeRule.service_type} (${routeRule.source})`,
        rule_id: routeRule.fare_id,
      };
    }
  }

  // Match distance slab
  const matchedRule = OFFICIAL_FARE_RULES.find(
    r =>
      r.service_type === normService &&
      distanceKm >= (r.min_distance_km || 0) &&
      distanceKm <= (r.max_distance_km || 999)
  );

  if (matchedRule) {
    return {
      fare: matchedRule.base_fare,
      fare_status: 'verified',
      citation: `${matchedRule.service_type} [${matchedRule.min_distance_km}-${matchedRule.max_distance_km}km]: ₹${matchedRule.base_fare} (${matchedRule.source})`,
      rule_id: matchedRule.fare_id,
    };
  }

  // Fallback estimates if outside known slabs
  if (transportType === 'bus') {
    // TGSRTC default rule fallback: ₹10 base + ₹2/km
    const estimated = Math.max(10, Math.min(50, Math.round(10 + distanceKm * 1.8)));
    return {
      fare: estimated,
      fare_status: 'estimated',
      citation: `Estimated City Bus Fare (~${Math.round(distanceKm)}km)`,
    };
  }

  if (transportType === 'metro') {
    const estimated = Math.max(10, Math.min(60, Math.round(10 + distanceKm * 2.2)));
    return {
      fare: estimated,
      fare_status: 'estimated',
      citation: `Estimated Metro Fare (~${Math.round(distanceKm)}km)`,
    };
  }

  return {
    fare: 10,
    fare_status: 'estimated',
    citation: 'Estimated Local Rail Fare',
  };
}

/**
 * Calculates complete journey fare breakdown across all legs
 */
export function calculateJourneyFares(legs: {
  transport_type: 'bus' | 'metro' | 'train' | 'walk';
  service_name: string;
  service_type: string;
  from_stop: string;
  to_stop: string;
  distance_km: number;
  route_id?: string;
}[]): {
  totalFare: number;
  breakdowns: LegFareBreakdown[];
  fareStatus: 'verified' | 'estimated' | 'unavailable';
  fareStatusLabel: string;
} {
  let totalFare = 0;
  const breakdowns: LegFareBreakdown[] = [];
  let allVerified = true;
  let hasUnavailable = false;

  legs.forEach((leg, idx) => {
    const calc = calculateLegFare(
      leg.transport_type,
      leg.service_type || leg.service_name,
      leg.distance_km,
      leg.route_id
    );

    totalFare += calc.fare;

    if (calc.fare_status === 'estimated') {
      allVerified = false;
    } else if (calc.fare_status === 'unavailable') {
      hasUnavailable = true;
      allVerified = false;
    }

    breakdowns.push({
      leg_index: idx + 1,
      mode: leg.transport_type,
      service_name: leg.service_name,
      service_type: leg.service_type || 'Standard',
      from_stop: leg.from_stop,
      to_stop: leg.to_stop,
      distance_km: Math.round(leg.distance_km * 10) / 10,
      fare: calc.fare,
      fare_status: calc.fare_status,
      fare_citation: calc.citation,
      fare_rule_id: calc.rule_id,
    });
  });

  let fareStatus: 'verified' | 'estimated' | 'unavailable' = 'verified';
  let fareStatusLabel = '✓ Verified fare data';

  if (hasUnavailable) {
    fareStatus = 'unavailable';
    fareStatusLabel = 'Fare unavailable for one or more legs';
  } else if (!allVerified) {
    fareStatus = 'estimated';
    fareStatusLabel = `Estimated fare: ₹${totalFare}`;
  }

  return {
    totalFare,
    breakdowns,
    fareStatus,
    fareStatusLabel,
  };
}
