import React, { useState, useEffect } from 'react';
import {
  TransportType,
  RouteOption,
  Stop,
  JourneyPreferences,
  UserSearchLog,
  SavedJourney,
  RecentJourneyPlan,
  PriorityMode
} from './types/transit';
import {
  INITIAL_STOPS,
  getRouteOptions,
  parseTimeToMinutes,
  formatTimeFromOffset,
  SAMPLE_SAVED_JOURNEYS,
  SAMPLE_RECENT_JOURNEYS
} from './data/transitData';
import { Header, NavTab } from './components/Header';
import { HomePage } from './components/HomePage';
import { JourneyPlanner } from './components/JourneyPlanner';
import { WaitingTimeEstimator } from './components/WaitingTimeEstimator';
import { AllRoutesView } from './components/AllRoutesView';
import { SavedJourneysPage } from './components/SavedJourneysPage';
import { AboutView } from './components/AboutView';
import { HelpView } from './components/HelpView';
import { AdminPanel } from './components/AdminPanel';
import { RouteDetailsModal } from './components/RouteDetailsModal';
import { JudgeWalkthroughModal } from './components/JudgeWalkthroughModal';
import { Bus, MapPin, Clock, ArrowRight, ShieldCheck, Heart, GraduationCap } from 'lucide-react';

export default function App() {
  // Navigation & Core States
  const [currentTab, setCurrentTab] = useState<NavTab>('home');
  const [fromLocation, setFromLocation] = useState('AS Rao Nagar');
  const [toLocation, setToLocation] = useState('Gachibowli');
  const [transportType, setTransportType] = useState<TransportType>('all');

  // Clock state — seeded at 10:17
  const [currentTimeOffsetMins, setCurrentTimeOffsetMins] = useState(0);
  const currentTimeStr = formatTimeFromOffset(10, 17, currentTimeOffsetMins);

  // Live vs Scheduled Telematics Toggle
  const [isLiveFeedActive, setIsLiveFeedActive] = useState(true);

  // Student Preferences
  const [preferences, setPreferences] = useState<JourneyPreferences>({
    shortestTime: false,
    fewerChanges: false,
    lowestFare: false,
    lessWaiting: false,
    transportMode: 'all',
    sortBy: 'recommended',
    priorityMode: 'balanced',
    maxBudget: null,
    maxChanges: null,
    maxWalkingKm: null,
    preferredDepartureTime: '10:17',
  });

  // Saved Journeys State
  const [savedJourneys, setSavedJourneys] = useState<SavedJourney[]>(() => {
    try {
      const stored = localStorage.getItem('transitflow_saved_journeys') || localStorage.getItem('campusroute_saved_journeys');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load saved journeys from localStorage', e);
    }
    return SAMPLE_SAVED_JOURNEYS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('transitflow_saved_journeys', JSON.stringify(savedJourneys));
    } catch (e) {
      console.error('Failed to save journeys to localStorage', e);
    }
  }, [savedJourneys]);

  // Recent Journey Plans State (for budget & activity tracking)
  const [recentPlans, setRecentPlans] = useState<RecentJourneyPlan[]>(() => {
    try {
      const stored = localStorage.getItem('transitflow_recent_plans');
      if (stored) {
        return JSON.parse(stored);
      }
    } catch (e) {
      console.error('Failed to load recent plans from localStorage', e);
    }
    return SAMPLE_RECENT_JOURNEYS;
  });

  useEffect(() => {
    try {
      localStorage.setItem('transitflow_recent_plans', JSON.stringify(recentPlans));
    } catch (e) {
      console.error('Failed to save recent plans to localStorage', e);
    }
  }, [recentPlans]);

  // Active Routes
  const [routes, setRoutes] = useState<RouteOption[]>(() =>
    getRouteOptions('AS Rao Nagar', 'Gachibowli', 'all', {
      shortestTime: false,
      fewerChanges: false,
      lowestFare: false,
      lessWaiting: false,
      transportMode: 'all',
      sortBy: 'recommended',
      priorityMode: 'balanced',
      maxBudget: null,
      maxChanges: null,
      maxWalkingKm: null,
      preferredDepartureTime: '10:17',
    }, true)
  );

  // Modals & Selected items
  const [selectedRouteForDetails, setSelectedRouteForDetails] = useState<RouteOption | null>(null);
  const [selectedStopForWaiting, setSelectedStopForWaiting] = useState('Secunderabad Station');
  const [judgeWalkthroughOpen, setJudgeWalkthroughOpen] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Admin and Stops state
  const [stopsList, setStopsList] = useState<Stop[]>(INITIAL_STOPS);
  const [searchLogs, setSearchLogs] = useState<UserSearchLog[]>([
    {
      id: 'log-1',
      timestamp: '10:14:22',
      source: 'AS Rao Nagar',
      destination: 'Gachibowli',
      transport_type: 'all',
      routes_found: 4,
    },
    {
      id: 'log-2',
      timestamp: '10:15:08',
      source: 'JNTUH Kukatpally',
      destination: 'Ameerpet',
      transport_type: 'metro',
      routes_found: 3,
    },
  ]);

  // Re-calculate routes whenever inputs change
  useEffect(() => {
    if (!fromLocation.trim() || !toLocation.trim()) {
      setRoutes([]);
      return;
    }

    const calculated = getRouteOptions(
      fromLocation,
      toLocation,
      transportType,
      preferences,
      isLiveFeedActive
    );
    setRoutes(calculated);
  }, [fromLocation, toLocation, transportType, preferences, isLiveFeedActive]);

  // Adjust simulation time
  const handleAdjustTime = (deltaMins: number) => {
    setCurrentTimeOffsetMins(prev => prev + deltaMins);
  };

  // Submit Plan from Home or other components
  const handlePlanJourney = () => {
    if (!fromLocation.trim() || !toLocation.trim()) {
      setErrorMessage('Please enter a valid Hyderabad source and destination.');
      setCurrentTab('plan');
      return;
    }

    if (fromLocation.trim().toLowerCase() === toLocation.trim().toLowerCase()) {
      setErrorMessage('Source and destination cannot be identical. Please choose different Hyderabad locations.');
      setCurrentTab('plan');
      return;
    }

    setErrorMessage(null);

    // Add search log
    const newLog: UserSearchLog = {
      id: `log-${Date.now()}`,
      timestamp: currentTimeStr,
      source: fromLocation,
      destination: toLocation,
      transport_type: transportType,
      routes_found: routes.length,
    };
    setSearchLogs(prev => [newLog, ...prev.slice(0, 49)]);

    // Add to recent plans for budget calculation
    const bestRoute = routes[0];
    const newRecentPlan: RecentJourneyPlan = {
      id: `recent-${Date.now()}`,
      source: fromLocation,
      destination: toLocation,
      fare_inr: bestRoute?.fare_inr || 35,
      transport_type: transportType,
      route_summary: bestRoute?.summary_line || (transportType === 'metro' ? 'Metro Transit' : 'TGSRTC Bus Corridor'),
      duration_min: bestRoute?.journey_time_min || 45,
      timestamp: currentTimeStr,
      frequency_per_month: 4,
    };
    setRecentPlans(prev => [
      newRecentPlan,
      ...prev.filter(p => !(p.source === fromLocation && p.destination === toLocation)).slice(0, 8),
    ]);

    setCurrentTab('plan');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleSelectCorridor = (from: string, to: string) => {
    setFromLocation(from);
    setToLocation(to);
    setErrorMessage(null);
    setCurrentTab('plan');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCheckStopWaitingTime = (stopName: string) => {
    setSelectedStopForWaiting(stopName);
    setCurrentTab('waiting-time');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Saved Journeys management
  const handleToggleSaveRoute = (route: RouteOption) => {
    setSavedJourneys(prev => {
      const exists = prev.some(item => item.route.id === route.id);
      if (exists) {
        return prev.filter(item => item.route.id !== route.id);
      } else {
        const newSaved: SavedJourney = {
          id: `saved-${Date.now()}`,
          source: route.all_stops[0] || fromLocation,
          destination: route.all_stops[route.all_stops.length - 1] || toLocation,
          custom_label: `${route.all_stops[0] || fromLocation} → ${route.all_stops[route.all_stops.length - 1] || toLocation}`,
          route,
          created_at: new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric' }),
        };
        return [newSaved, ...prev];
      }
    });
  };

  const handleRemoveSavedJourney = (id: string) => {
    setSavedJourneys(prev => prev.filter(item => item.id !== id));
  };

  const handleUpdateJourneyLabel = (id: string, newLabel: string) => {
    setSavedJourneys(prev =>
      prev.map(item => (item.id === id ? { ...item, custom_label: newLabel } : item))
    );
  };

  // Simulation of error scenarios from Help View
  const handleTestScenario = (scenario: 'no_route' | 'no_live' | 'invalid_loc' | 'service_unavail') => {
    if (scenario === 'no_route') {
      setFromLocation('Outer Himalayas');
      setToLocation('Secunderabad');
      setErrorMessage("We couldn't find a suitable public transport route between these locations.");
      setCurrentTab('plan');
    } else if (scenario === 'no_live') {
      setIsLiveFeedActive(false);
      setErrorMessage('Live arrival information is currently unavailable. Showing scheduled information instead.');
      setCurrentTab('waiting-time');
    } else if (scenario === 'invalid_loc') {
      setFromLocation('');
      setToLocation('');
      setErrorMessage('Please enter a valid source and destination.');
      setCurrentTab('plan');
    } else if (scenario === 'service_unavail') {
      setErrorMessage('This service may currently be unavailable. Please check another route.');
      setCurrentTab('plan');
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans selection:bg-blue-600 selection:text-white">
      {/* Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={(tab) => {
          setCurrentTab(tab);
          setErrorMessage(null);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        currentTimeStr={currentTimeStr}
        onAdjustTime={handleAdjustTime}
        isLiveFeedActive={isLiveFeedActive}
        onToggleLiveFeed={() => setIsLiveFeedActive(!isLiveFeedActive)}
        onOpenJudgeWalkthrough={() => setJudgeWalkthroughOpen(true)}
        savedCount={savedJourneys.length}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentTab === 'home' && (
          <HomePage
            fromLocation={fromLocation}
            toLocation={toLocation}
            transportType={transportType}
            priorityMode={preferences.priorityMode || 'balanced'}
            onFromChange={setFromLocation}
            onToChange={setToLocation}
            onTransportChange={setTransportType}
            onPriorityChange={(p: PriorityMode) => setPreferences({ ...preferences, priorityMode: p })}
            onSubmitPlan={handlePlanJourney}
            onNavigateToTab={(tab) => {
              setCurrentTab(tab);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSelectPredefinedCorridor={handleSelectCorridor}
            isLiveActive={isLiveFeedActive}
            savedJourneys={savedJourneys}
            recentPlans={recentPlans}
            onAddSampleJourneys={() => setSavedJourneys(SAMPLE_SAVED_JOURNEYS)}
          />
        )}

        {currentTab === 'plan' && (
          <JourneyPlanner
            source={fromLocation}
            destination={toLocation}
            routes={routes}
            preferences={preferences}
            onUpdatePreferences={setPreferences}
            onSelectRouteForDetails={(r) => setSelectedRouteForDetails(r)}
            onGoToWaitingTimeForStop={handleCheckStopWaitingTime}
            isLiveActive={isLiveFeedActive}
            onRefreshSearch={handlePlanJourney}
            onSaveJourney={handleToggleSaveRoute}
            savedJourneyIds={savedJourneys.map(s => s.route.id)}
            errorMessage={errorMessage}
          />
        )}

        {currentTab === 'waiting-time' && (
          <WaitingTimeEstimator
            selectedStopName={selectedStopForWaiting}
            onSelectStop={setSelectedStopForWaiting}
            currentTimeStr={currentTimeStr}
            isLiveFeedActive={isLiveFeedActive}
            onToggleLiveFeed={() => setIsLiveFeedActive(!isLiveFeedActive)}
            onAdvanceClock={handleAdjustTime}
          />
        )}

        {currentTab === 'routes' && (
          <AllRoutesView
            onPlanRoute={(source, dest) => {
              setFromLocation(source);
              setToLocation(dest);
              setCurrentTab('plan');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onCheckStop={handleCheckStopWaitingTime}
          />
        )}

        {currentTab === 'saved' && (
          <SavedJourneysPage
            savedJourneys={savedJourneys}
            onRemoveSavedJourney={handleRemoveSavedJourney}
            onUpdateJourneyLabel={handleUpdateJourneyLabel}
            onViewRouteDetails={(r) => setSelectedRouteForDetails(r)}
            onPlanJourney={(src, dest) => {
              setFromLocation(src);
              setToLocation(dest);
              setCurrentTab('plan');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onCheckWaitingTime={handleCheckStopWaitingTime}
            onAddSampleJourneys={() => setSavedJourneys(SAMPLE_SAVED_JOURNEYS)}
          />
        )}

        {currentTab === 'about' && <AboutView />}

        {currentTab === 'help' && (
          <HelpView onTestScenario={handleTestScenario} />
        )}

        {currentTab === 'admin' && (
          <AdminPanel
            stops={stopsList}
            onAddStop={(newStop) => setStopsList(prev => [...prev, newStop])}
            onUpdateServiceStatus={(service, status) => {}}
            searchLogs={searchLogs}
          />
        )}
      </main>

      {/* Route Details Modal (includes Leaflet RouteMap) */}
      {selectedRouteForDetails && (
        <RouteDetailsModal
          route={selectedRouteForDetails}
          onClose={() => setSelectedRouteForDetails(null)}
          onCheckWaitingTime={handleCheckStopWaitingTime}
          onSaveJourney={handleToggleSaveRoute}
          isSaved={savedJourneys.some(s => s.route.id === selectedRouteForDetails.id)}
        />
      )}

      {/* Judge Demonstration Walkthrough Modal */}
      <JudgeWalkthroughModal
        isOpen={judgeWalkthroughOpen}
        onClose={() => setJudgeWalkthroughOpen(false)}
        onNavigateTab={(tab) => {
          setCurrentTab(tab);
          setJudgeWalkthroughOpen(false);
        }}
        onSetDemoCorridor={(src, dest) => {
          setFromLocation(src);
          setToLocation(dest);
        }}
        onSetStop={(stop) => setSelectedStopForWaiting(stop)}
        onToggleLiveFeed={(force) => {
          if (typeof force === 'boolean') {
            setIsLiveFeedActive(force);
          } else {
            setIsLiveFeedActive(prev => !prev);
          }
        }}
        onOpenRouteDetails={() => {
          if (routes.length > 0) {
            setSelectedRouteForDetails(routes[0]);
          }
        }}
      />

      {/* Site Footer */}
      <footer className="bg-slate-900 text-slate-400 border-t border-slate-800 text-xs py-10 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-8">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center font-bold">
                <GraduationCap className="w-5 h-5" />
              </div>
              <div>
                <span className="text-base font-extrabold text-white tracking-tight">
                  Transit Flow
                </span>
                <p className="text-xs text-slate-400">
                  Student-Friendly Public Transport Journey Planner • Hyderabad, Telangana
                </p>
              </div>
            </div>

            <div className="flex items-center gap-6 text-slate-300 font-semibold text-xs flex-wrap">
              <button onClick={() => setCurrentTab('home')} className="hover:text-white cursor-pointer">
                Home
              </button>
              <button onClick={() => setCurrentTab('plan')} className="hover:text-white cursor-pointer">
                Plan Journey
              </button>
              <button onClick={() => setCurrentTab('waiting-time')} className="hover:text-white cursor-pointer">
                Waiting Time
              </button>
              <button onClick={() => setCurrentTab('routes')} className="hover:text-white cursor-pointer">
                Routes
              </button>
              <button onClick={() => setCurrentTab('saved')} className="hover:text-white cursor-pointer">
                Saved Journeys
              </button>
              <button onClick={() => setCurrentTab('about')} className="hover:text-white cursor-pointer">
                About
              </button>
              <button onClick={() => setCurrentTab('help')} className="hover:text-white cursor-pointer">
                Help
              </button>
              <button onClick={() => setCurrentTab('admin')} className="hover:text-white cursor-pointer text-indigo-400">
                Admin
              </button>
            </div>
          </div>

          <div className="pt-6 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-slate-500">
            <p>
              “Transport timings and fares are estimates and may change. Transit Flow demo transport data mode.”
            </p>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                🟢 Live GPS Feed
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-blue-500"></span>
                🔵 Scheduled Timetable
              </span>
              <span className="flex items-center gap-1.5">
                <span className="h-2 w-2 rounded-full bg-slate-400"></span>
                ⚪ System Estimated
              </span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
