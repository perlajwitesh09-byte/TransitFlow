import React, { useState, useEffect } from 'react';
import { StopDeparture, Stop, TransportType } from '../types/transit';
import { INITIAL_STOPS, HYDERABAD_LOCATIONS, getDeparturesForStop } from '../data/transitData';
import { DataSourceBadge, DataSourceExplanationCard } from './DataSourceBadge';
import {
  Clock,
  Search,
  Radio,
  CalendarClock,
  Bus,
  Train,
  Milestone,
  RefreshCw,
  Info,
  MapPin,
  HelpCircle,
  TrendingDown,
  Sparkles,
  ArrowRight,
  Filter
} from 'lucide-react';

interface WaitingTimeEstimatorProps {
  selectedStopName: string;
  onSelectStop: (stopName: string) => void;
  currentTimeStr: string;
  isLiveFeedActive: boolean;
  onToggleLiveFeed: () => void;
  onAdvanceClock?: (mins: number) => void;
}

export const WaitingTimeEstimator: React.FC<WaitingTimeEstimatorProps> = ({
  selectedStopName,
  onSelectStop,
  currentTimeStr,
  isLiveFeedActive,
  onToggleLiveFeed,
  onAdvanceClock,
}) => {
  const [searchTerm, setSearchTerm] = useState(selectedStopName || 'Ameerpet');
  const [activeSuggestions, setActiveSuggestions] = useState<Stop[]>([]);
  const [modeFilter, setModeFilter] = useState<TransportType>('all');
  const [isSearching, setIsSearching] = useState(false);
  const [showFormulaDetails, setShowFormulaDetails] = useState(true);

  // Fetch departures based on selectedStopName and currentTimeStr
  const departures = getDeparturesForStop(
    selectedStopName || 'Ameerpet',
    currentTimeStr,
    isLiveFeedActive
  );

  const filteredDepartures = departures.filter(dep => {
    if (modeFilter === 'all') return true;
    return dep.transport_type === modeFilter;
  });

  const handleSearchChange = (val: string) => {
    setSearchTerm(val);
    if (!val.trim()) {
      setActiveSuggestions([]);
    } else {
      const q = val.toLowerCase();
      const initialMatches = INITIAL_STOPS.filter(s =>
        s.stop_name.toLowerCase().includes(q) ||
        s.area.toLowerCase().includes(q)
      );
      const hydMatches: Stop[] = HYDERABAD_LOCATIONS.filter(l =>
        l.name.toLowerCase().includes(q) ||
        l.zone.toLowerCase().includes(q)
      ).map(l => ({
        stop_id: l.id,
        stop_name: l.name,
        city: 'Hyderabad',
        area: `${l.zone} Hyderabad`,
        latitude: l.latitude,
        longitude: l.longitude,
        connected_modes: ['bus', 'metro'] as ('bus' | 'metro' | 'train')[],
      }));

      const combined = [...initialMatches];
      for (const h of hydMatches) {
        if (!combined.some(c => c.stop_name.toLowerCase() === h.stop_name.toLowerCase())) {
          combined.push(h);
        }
      }
      setActiveSuggestions(combined.slice(0, 6));
    }
  };

  const handleSelectSuggestion = (stop: Stop) => {
    setSearchTerm(stop.stop_name);
    onSelectStop(stop.stop_name);
    setActiveSuggestions([]);
  };

  // Primary sample service for the formula breakdown (Bus 216D as specified in user request)
  const sampleService = departures.find(d => d.service_number === '216D') || departures[0] || {
    service_number: '216D',
    destination: 'Secunderabad',
    scheduled_arrival: '10:25',
    waiting_minutes: 8,
    data_source: 'scheduled' as const,
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Accuracy Warning Banner */}
      <div className="bg-amber-50 border border-amber-200/80 rounded-2xl px-4 py-2.5 text-xs text-amber-900 flex items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="font-semibold">
            «"Transport timings and fares are estimates and may change."»
          </span>
        </div>
        <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider hidden sm:inline">
          Estimated / Demo Data Mode
        </span>
      </div>

      {/* Feature Title Banner */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-bold mb-2">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>⭐ Core Innovation Engine</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Waiting Time Estimator
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-2xl">
              Real-time countdown intelligence with strict data provenance. We differentiate between verified GPS transponders and static published timetables.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="bg-slate-900 text-white px-4 py-2.5 rounded-2xl flex items-center gap-3 shadow-sm border border-slate-800">
              <div className="text-right">
                <span className="text-[10px] text-slate-400 uppercase tracking-widest block font-bold">
                  System Time
                </span>
                <span className="font-mono text-base font-extrabold text-emerald-400">
                  {currentTimeStr}
                </span>
              </div>
              {onAdvanceClock && (
                <div className="flex flex-col gap-1 pl-2 border-l border-slate-700">
                  <button
                    onClick={() => onAdvanceClock(1)}
                    className="cursor-pointer px-1.5 py-0.5 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-bold"
                    title="Advance clock by 1 minute"
                  >
                    +1m
                  </button>
                  <button
                    onClick={() => onAdvanceClock(5)}
                    className="cursor-pointer px-1.5 py-0.5 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded font-bold"
                    title="Advance clock by 5 minutes"
                  >
                    +5m
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Stop Selector & Autocomplete */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="max-w-2xl">
          <label htmlFor="search-bus-stop-input" className="block text-sm font-bold text-slate-900 mb-2">
            Select Stop / Station:
          </label>
          <div className="relative">
            <Search className="w-5 h-5 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              id="search-bus-stop-input"
              type="text"
              value={searchTerm}
              onChange={(e) => handleSearchChange(e.target.value)}
              placeholder="[ Search bus stop ] (e.g. Ameerpet Bus Stop)"
              className="w-full pl-11 pr-4 py-3.5 bg-slate-50 border border-slate-300 rounded-2xl text-slate-900 font-semibold placeholder-slate-400 focus:bg-white focus:border-blue-600 focus:ring-2 focus:ring-blue-100 outline-none transition-all"
            />

            {/* Suggestions */}
            {activeSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-1.5 bg-white border border-slate-200 rounded-2xl shadow-xl z-30 overflow-hidden">
                {activeSuggestions.map(stop => (
                  <div
                    key={stop.stop_id}
                    onMouseDown={() => handleSelectSuggestion(stop)}
                    className="px-4 py-3 hover:bg-blue-50 cursor-pointer flex items-center justify-between border-b border-slate-100 last:border-0"
                  >
                    <div className="flex items-center gap-2.5">
                      <MapPin className="w-4 h-4 text-blue-600" />
                      <div>
                        <span className="font-bold text-slate-800 text-sm">{stop.stop_name} Stop</span>
                        <span className="text-xs text-slate-400 ml-2">({stop.area})</span>
                      </div>
                    </div>
                    <span className="text-xs font-semibold px-2 py-0.5 bg-slate-100 rounded text-slate-600">
                      {stop.connected_modes.join(', ')}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Quick preset stop chips */}
          <div className="mt-3 flex items-center gap-2 flex-wrap">
            <span className="text-xs text-slate-400 font-semibold">Example Stops:</span>
            {['Ameerpet', 'Secunderabad', 'Begumpet', 'Paradise', 'Mehdipatnam'].map(stopName => (
              <button
                key={stopName}
                onClick={() => {
                  setSearchTerm(stopName);
                  onSelectStop(stopName);
                }}
                className={`cursor-pointer text-xs px-2.5 py-1 rounded-lg font-medium border transition-colors ${
                  selectedStopName === stopName
                    ? 'bg-blue-600 text-white border-blue-600 shadow-xs'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                }`}
              >
                {stopName} Stop
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* How the Waiting Time calculation works:
          Formula breakdown interactive box
          Waiting Time = Expected Arrival Time − Current Time
          e.g. Current time: 10:17, Expected arrival: 10:25 => Waiting Time = 8 minutes */}
      <div className="bg-gradient-to-br from-blue-900 to-indigo-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-blue-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-blue-800/80 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-blue-500/20 text-blue-300 rounded-xl">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-base font-extrabold tracking-wide uppercase text-blue-300">
                How the Waiting Time Calculation Works
              </h3>
              <p className="text-xs text-blue-100 mt-0.5">
                Mathematical formula enforced across every transit route & vehicle
              </p>
            </div>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-800/50 text-blue-200 text-xs font-mono">
            <span>Deterministic Engine</span>
          </div>
        </div>

        {/* Formula Box */}
        <div className="mt-6 bg-slate-900/90 rounded-2xl p-5 border border-blue-700/50 font-mono text-center sm:text-left">
          <div className="text-xs text-blue-400 font-bold uppercase tracking-widest mb-1">
            Mathematical Relation:
          </div>
          <div className="text-lg sm:text-2xl font-extrabold text-white tracking-wide">
            Waiting Time = Expected Arrival Time − Current Time
          </div>
        </div>

        {/* Concrete Live Example from prompt */}
        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-blue-800/40 rounded-2xl p-4 border border-blue-700/40">
            <span className="text-xs text-blue-300 block font-semibold">Step 1: Current Time</span>
            <div className="text-xl font-mono font-bold text-white mt-1">
              {currentTimeStr}
            </div>
            <p className="text-[11px] text-blue-200/80 mt-1">
              Real-time commuter reference point
            </p>
          </div>

          <div className="bg-blue-800/40 rounded-2xl p-4 border border-blue-700/40">
            <span className="text-xs text-blue-300 block font-semibold">Step 2: Expected Arrival</span>
            <div className="text-xl font-mono font-bold text-white mt-1">
              {sampleService.scheduled_arrival}
            </div>
            <p className="text-[11px] text-blue-200/80 mt-1">
              {sampleService.data_source === 'live' ? 'From live AVL transponder' : 'From published operator timetable'}
            </p>
          </div>

          <div className="bg-emerald-950/60 rounded-2xl p-4 border border-emerald-500/50">
            <span className="text-xs text-emerald-400 block font-bold">Step 3: Resulting Waiting Time</span>
            <div className="text-xl font-mono font-extrabold text-emerald-300 mt-1 flex items-center gap-1.5">
              <span>⏱️ {sampleService.waiting_minutes} minutes</span>
            </div>
            <p className="text-[11px] text-emerald-200/80 mt-1">
              until arrival at platform
            </p>
          </div>
        </div>

        <div className="mt-5 p-3 rounded-xl bg-blue-800/30 text-xs text-blue-200 flex items-center justify-between flex-wrap gap-2">
          <span>
            Current Service Example: <strong>Bus {sampleService.service_number}</strong> to <strong>{sampleService.destination}</strong>
          </span>
          <div className="flex items-center gap-2">
            <DataSourceBadge type={sampleService.data_source} showDetail={true} />
          </div>
        </div>
      </div>

      {/* Next Services Departure Board (The Table matching prompt):
          Next Services:
          Service | Destination | Arrival | Waiting
          🚌 216D | Secunderabad | 10:25 | 8 min  (🔵 Scheduled)
          🚌 218 | Mehdipatnam  | 10:37 | 20 min (🟢 Live)
          🚌 219 | Kukatpally   | 10:44 | 27 min (🟢 Live) */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-extrabold bg-blue-100 text-blue-800">
                {selectedStopName || 'Ameerpet'} Bus & Metro Hub
              </span>
              <span className="text-xs text-slate-400">Live Departure Board</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight mt-1">
              Next Services
            </h2>
          </div>

          {/* Mode filters */}
          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            {(['all', 'bus', 'metro', 'train'] as const).map(mode => (
              <button
                key={mode}
                onClick={() => setModeFilter(mode)}
                className={`cursor-pointer px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  modeFilter === mode
                    ? 'bg-white text-slate-900 shadow-2xs font-extrabold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {mode === 'all' && 'All'}
                {mode === 'bus' && '🚌 Bus'}
                {mode === 'metro' && '🚇 Metro'}
                {mode === 'train' && '🚆 Train'}
              </button>
            ))}
          </div>
        </div>

        {/* Departure Table */}
        <div className="overflow-x-auto mt-6">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-200 text-xs font-bold text-slate-400 uppercase tracking-wider">
                <th className="py-3 px-4">Service</th>
                <th className="py-3 px-4">Destination</th>
                <th className="py-3 px-4">Platform / Stand</th>
                <th className="py-3 px-4">Expected Arrival</th>
                <th className="py-3 px-4">Waiting Time</th>
                <th className="py-3 px-4">Data Source Provenance</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-sm">
              {filteredDepartures.map((dep, idx) => {
                const isBus = dep.transport_type === 'bus';
                const isMetro = dep.transport_type === 'metro';
                const isTrain = dep.transport_type === 'train';

                return (
                  <tr
                    key={dep.service_id}
                    id={`departure-row-${dep.service_number.replace(/\s+/g, '-')}`}
                    className="hover:bg-slate-50/80 transition-colors group"
                  >
                    {/* Service Column */}
                    <td className="py-4 px-4 font-extrabold text-slate-900">
                      <div className="flex items-center gap-2.5">
                        <span className="p-2 rounded-xl bg-slate-100 text-slate-700 group-hover:bg-blue-50 group-hover:text-blue-700 transition-colors">
                          {isBus && <Bus className="w-4 h-4" />}
                          {isMetro && <Milestone className="w-4 h-4" />}
                          {isTrain && <Train className="w-4 h-4" />}
                        </span>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="font-mono text-base font-extrabold text-slate-900">
                              {dep.service_number}
                            </span>
                            {dep.bus_id && (
                              <span className="px-1.5 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-100 text-slate-700 border border-slate-200" title="Vehicle Registration / Fleet ID">
                                🚍 {dep.bus_id}
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-2 mt-0.5">
                            <span className="text-[11px] text-slate-400 capitalize font-medium">
                              {dep.transport_type}
                            </span>
                            {dep.interval_from_prev_mins !== undefined && (
                              <span className="text-[10px] text-indigo-700 font-bold bg-indigo-50 px-1.5 py-0.2 rounded border border-indigo-100">
                                ⏱️ {dep.interval_from_prev_mins}m gap
                              </span>
                            )}
                          </div>
                        </div>
                      </div>
                    </td>

                    {/* Destination */}
                    <td className="py-4 px-4 font-bold text-slate-800">
                      <div className="flex items-center gap-1.5">
                        <ArrowRight className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{dep.destination}</span>
                      </div>
                    </td>

                    {/* Platform */}
                    <td className="py-4 px-4 text-xs font-semibold text-slate-600">
                      <span className="px-2 py-1 bg-slate-100 rounded-md">
                        {dep.platform || 'General'}
                      </span>
                    </td>

                    {/* Arrival Time */}
                    <td className="py-4 px-4 font-mono font-bold text-slate-900">
                      <div className="flex items-center gap-1.5">
                        <CalendarClock className="w-4 h-4 text-slate-400" />
                        <span>{dep.scheduled_arrival}</span>
                      </div>
                    </td>

                    {/* Waiting Time */}
                    <td className="py-4 px-4 font-bold">
                      <div className="inline-flex items-center gap-2">
                        <span className="px-3 py-1.5 rounded-xl bg-blue-50 text-blue-800 text-sm font-black font-mono border border-blue-200">
                          ⏱️ {dep.waiting_minutes} min
                        </span>
                        {dep.status === 'delayed' && (
                          <span className="text-[10px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded">
                            +{dep.delay_minutes}m delay
                          </span>
                        )}
                      </div>
                    </td>

                    {/* Data Source Label (🟢 Live or 🔵 Scheduled) */}
                    <td className="py-4 px-4">
                      <DataSourceBadge
                        type={dep.data_source}
                        showDetail={true}
                        updatedAgo={dep.last_updated_secs}
                      />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Data Source Explanation component */}
      <DataSourceExplanationCard
        onToggleLiveSim={onToggleLiveFeed}
        isLiveSim={isLiveFeedActive}
      />
    </div>
  );
};
