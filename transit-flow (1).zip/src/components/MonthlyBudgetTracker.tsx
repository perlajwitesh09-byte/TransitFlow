import React, { useState, useEffect, useId } from 'react';
import { RouteOption, SavedJourney, RecentJourneyPlan, TransportType } from '../types/transit';
import {
  Wallet,
  IndianRupee,
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  RotateCcw,
  Sliders,
  Plus,
  Bookmark,
  History,
  ArrowRight,
  Sparkles,
  Bus,
  Milestone,
  Train,
  Check,
  Percent,
  HelpCircle,
  Lightbulb
} from 'lucide-react';

interface MonthlyBudgetTrackerProps {
  savedJourneys: SavedJourney[];
  recentPlans: RecentJourneyPlan[];
  onNavigateToTab: (tab: 'home' | 'plan' | 'waiting-time' | 'routes' | 'saved' | 'about' | 'help' | 'admin') => void;
  onPlanCorridor: (source: string, destination: string) => void;
  onAddSampleJourneys?: () => void;
}

const STORAGE_KEYS = {
  BUDGET: 'transitflow_budget_amount',
  COMMUTE_DAYS: 'transitflow_budget_days',
  ROUND_TRIP: 'transitflow_budget_roundtrip',
  INCLUDED_SAVED: 'transitflow_budget_included_saved',
  INCLUDED_RECENT: 'transitflow_budget_included_recent',
  CUSTOM_FREQ: 'transitflow_budget_custom_freq',
};

const BUDGET_PRESETS = [800, 1200, 1500, 2000, 3000];
const COMMUTE_DAY_PRESETS = [
  { label: '20 Days (College)', days: 20 },
  { label: '22 Days (Mon–Fri)', days: 22 },
  { label: '26 Days (Mon–Sat)', days: 26 },
  { label: '15 Days (Hybrid)', days: 15 },
];

export const MonthlyBudgetTracker: React.FC<MonthlyBudgetTrackerProps> = ({
  savedJourneys,
  recentPlans,
  onNavigateToTab,
  onPlanCorridor,
  onAddSampleJourneys,
}) => {
  // Monthly Budget (in ₹)
  const [budget, setBudget] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.BUDGET);
      return stored ? Math.max(100, Number(stored)) : 1500;
    } catch {
      return 1500;
    }
  });

  // Commuting days per month (typically 22 working/college days)
  const [commutingDays, setCommutingDays] = useState<number>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.COMMUTE_DAYS);
      return stored ? Math.max(1, Math.min(31, Number(stored))) : 22;
    } catch {
      return 22;
    }
  });

  // Round trip per commuting day (2 trips / day)
  const [isRoundTrip, setIsRoundTrip] = useState<boolean>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.ROUND_TRIP);
      return stored !== null ? stored === 'true' : true;
    } catch {
      return true;
    }
  });

  // Track which saved journey IDs are actively included in the calculation
  const [includedSavedIds, setIncludedSavedIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.INCLUDED_SAVED);
      if (stored) return JSON.parse(stored);
    } catch {}
    // Default: include the first saved journey or all
    return savedJourneys.length > 0 ? [savedJourneys[0].id] : [];
  });

  // Track which recent plan IDs are actively included in the calculation
  const [includedRecentIds, setIncludedRecentIds] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.INCLUDED_RECENT);
      if (stored) return JSON.parse(stored);
    } catch {}
    // Default: include first 2 recent plans if available
    return recentPlans.slice(0, 2).map(r => r.id);
  });

  // Custom monthly frequency override per journey ID (e.g. { 'saved-1': 44, 'recent-1': 4 })
  const [customFrequency, setCustomFrequency] = useState<Record<string, number>>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEYS.CUSTOM_FREQ);
      if (stored) return JSON.parse(stored);
    } catch {}
    return {};
  });

  // UI state
  const [isEditingBudget, setIsEditingBudget] = useState(false);
  const [tempBudgetInput, setTempBudgetInput] = useState(budget.toString());
  const [activeTabFilter, setActiveTabFilter] = useState<'all' | 'saved' | 'recent'>('all');
  const [showSavingsTip, setShowSavingsTip] = useState(true);

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEYS.BUDGET, budget.toString());
      localStorage.setItem(STORAGE_KEYS.COMMUTE_DAYS, commutingDays.toString());
      localStorage.setItem(STORAGE_KEYS.ROUND_TRIP, isRoundTrip.toString());
      localStorage.setItem(STORAGE_KEYS.INCLUDED_SAVED, JSON.stringify(includedSavedIds));
      localStorage.setItem(STORAGE_KEYS.INCLUDED_RECENT, JSON.stringify(includedRecentIds));
      localStorage.setItem(STORAGE_KEYS.CUSTOM_FREQ, JSON.stringify(customFrequency));
    } catch (e) {
      console.error('Failed to sync budget tracker settings to localStorage', e);
    }
  }, [budget, commutingDays, isRoundTrip, includedSavedIds, includedRecentIds, customFrequency]);

  // Ensure newly added saved journeys have default selection if none selected
  useEffect(() => {
    if (savedJourneys.length > 0 && includedSavedIds.length === 0) {
      setIncludedSavedIds([savedJourneys[0].id]);
    }
  }, [savedJourneys]);

  // Calculations
  const defaultDailyTrips = isRoundTrip ? 2 : 1;
  const defaultMonthlyCommuteTrips = commutingDays * defaultDailyTrips;

  // Calculate cost for saved journeys
  const savedCalculations = savedJourneys.map(sj => {
    const isIncluded = includedSavedIds.includes(sj.id);
    const tripsPerMonth = customFrequency[sj.id] !== undefined
      ? customFrequency[sj.id]
      : defaultMonthlyCommuteTrips;
    const singleFare = sj.route.fare_inr || 25;
    const monthlyCost = isIncluded ? singleFare * tripsPerMonth : 0;
    return {
      journey: sj,
      isIncluded,
      singleFare,
      tripsPerMonth,
      monthlyCost,
    };
  });

  // Calculate cost for recent plans
  const recentCalculations = recentPlans.map(rp => {
    const isIncluded = includedRecentIds.includes(rp.id);
    const tripsPerMonth = customFrequency[rp.id] !== undefined
      ? customFrequency[rp.id]
      : (rp.frequency_per_month || 4);
    const singleFare = rp.fare_inr || 35;
    const monthlyCost = isIncluded ? singleFare * tripsPerMonth : 0;
    return {
      plan: rp,
      isIncluded,
      singleFare,
      tripsPerMonth,
      monthlyCost,
    };
  });

  const totalSavedMonthlyCost = savedCalculations.reduce((acc, curr) => acc + curr.monthlyCost, 0);
  const totalRecentMonthlyCost = recentCalculations.reduce((acc, curr) => acc + curr.monthlyCost, 0);
  const totalProjectedSpend = totalSavedMonthlyCost + totalRecentMonthlyCost;

  const budgetDifference = budget - totalProjectedSpend;
  const isOverBudget = budgetDifference < 0;
  const percentUsed = budget > 0 ? Math.round((totalProjectedSpend / budget) * 100) : 0;
  const dailyAverageSpend = commutingDays > 0 ? Math.round(totalProjectedSpend / commutingDays) : 0;

  // Toggle included status
  const toggleSavedIncluded = (id: string) => {
    setIncludedSavedIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const toggleRecentIncluded = (id: string) => {
    setIncludedRecentIds(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const handleUpdateFrequency = (id: string, delta: number, current: number) => {
    const newVal = Math.max(1, Math.min(100, current + delta));
    setCustomFrequency(prev => ({ ...prev, [id]: newVal }));
  };

  const handleSaveBudget = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const parsed = parseInt(tempBudgetInput, 10);
    if (!isNaN(parsed) && parsed >= 100 && parsed <= 30000) {
      setBudget(parsed);
      setIsEditingBudget(false);
    }
  };

  const handlePresetSelect = (amount: number) => {
    setBudget(amount);
    setTempBudgetInput(amount.toString());
  };

  // Helper mode icon
  const renderModeIcon = (type?: TransportType | string) => {
    if (type === 'metro') {
      return <Milestone className="w-3.5 h-3.5 text-blue-600" />;
    }
    if (type === 'train') {
      return <Train className="w-3.5 h-3.5 text-amber-600" />;
    }
    return <Bus className="w-3.5 h-3.5 text-emerald-600" />;
  };

  // Progress bar color indicator
  const getProgressColor = () => {
    if (percentUsed > 100) return 'bg-rose-500';
    if (percentUsed >= 85) return 'bg-amber-500';
    return 'bg-emerald-500';
  };

  const getStatusBadge = () => {
    if (isOverBudget) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-rose-50 text-rose-700 border border-rose-200">
          <AlertTriangle className="w-3.5 h-3.5 text-rose-600" />
          <span>Exceeding Budget by ₹{Math.abs(budgetDifference)}</span>
        </span>
      );
    }
    if (percentUsed >= 85) {
      return (
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-50 text-amber-800 border border-amber-200">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
          <span>Approaching Limit (₹{budgetDifference} remaining)</span>
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-50 text-emerald-800 border border-emerald-200">
        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
        <span>Within Monthly Budget (₹{budgetDifference} remaining)</span>
      </span>
    );
  };

  return (
    <section id="monthly-travel-budget-section" className="max-w-4xl mx-auto px-4">
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200/90 relative overflow-hidden">
        {/* Decorative corner glow */}
        <div className="absolute -top-20 -right-20 w-64 h-64 bg-indigo-50/60 rounded-full blur-3xl pointer-events-none" />

        {/* Section Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
          <div>
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-bold border border-indigo-200 mb-2">
              <Wallet className="w-3.5 h-3.5 text-indigo-600" />
              <span>Hyderabad Transit Budget Tracker</span>
            </div>
            <h2 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Monthly Travel Budget & Spending
            </h2>
            <p className="text-xs sm:text-sm text-slate-500 mt-1 max-w-xl">
              Track your projected monthly transit spending based on your saved college/work routes and recent journey plans.
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              id="btn-edit-monthly-budget"
              onClick={() => {
                setTempBudgetInput(budget.toString());
                setIsEditingBudget(!isEditingBudget);
              }}
              className="cursor-pointer px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>{isEditingBudget ? 'Close Settings' : 'Adjust Budget & Days'}</span>
            </button>
          </div>
        </div>

        {/* Inline Budget & Commute Settings Panel */}
        {isEditingBudget && (
          <div className="mt-6 p-5 sm:p-6 bg-slate-50 rounded-2xl border border-slate-200 space-y-5 animate-fade-in">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                <Sliders className="w-4 h-4 text-blue-600" />
                <span>Configure Monthly Travel Target</span>
              </h3>
              <span className="text-xs text-slate-500">Changes are saved automatically</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* Monthly Budget Input & Presets */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700">
                  Target Monthly Budget (₹ INR)
                </label>
                <div className="flex items-center gap-2">
                  <div className="relative flex-1">
                    <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 font-bold text-sm">
                      ₹
                    </span>
                    <input
                      type="number"
                      min={100}
                      max={30000}
                      step={50}
                      value={tempBudgetInput}
                      onChange={(e) => setTempBudgetInput(e.target.value)}
                      onBlur={handleSaveBudget}
                      className="w-full pl-8 pr-3 py-2 text-sm font-bold bg-white border border-slate-300 rounded-xl focus:outline-hidden focus:ring-2 focus:ring-blue-500"
                      placeholder="e.g. 1500"
                    />
                  </div>
                  <button
                    onClick={handleSaveBudget}
                    className="cursor-pointer px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold rounded-xl transition-colors shrink-0"
                  >
                    Apply
                  </button>
                </div>

                {/* Quick Presets */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[11px] text-slate-500 font-semibold mr-1">Presets:</span>
                  {BUDGET_PRESETS.map((amount) => (
                    <button
                      key={amount}
                      onClick={() => handlePresetSelect(amount)}
                      className={`cursor-pointer text-xs font-semibold px-2.5 py-1 rounded-lg border transition-all ${
                        budget === amount
                          ? 'bg-blue-600 text-white border-blue-600'
                          : 'bg-white text-slate-700 border-slate-200 hover:border-blue-300'
                      }`}
                    >
                      ₹{amount.toLocaleString('en-IN')}
                    </button>
                  ))}
                </div>
              </div>

              {/* Commute Schedule Configuration */}
              <div className="space-y-3">
                <label className="block text-xs font-bold text-slate-700">
                  Commute Days per Month
                </label>
                <div className="grid grid-cols-2 gap-2">
                  {COMMUTE_DAY_PRESETS.map((preset) => (
                    <button
                      key={preset.days}
                      onClick={() => setCommutingDays(preset.days)}
                      className={`cursor-pointer p-2 rounded-xl text-xs font-semibold border text-left transition-all ${
                        commutingDays === preset.days
                          ? 'bg-blue-50 text-blue-900 border-blue-400 font-bold'
                          : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-100'
                      }`}
                    >
                      <div>{preset.label}</div>
                      <div className="text-[11px] text-slate-500">{preset.days} travel days</div>
                    </button>
                  ))}
                </div>

                {/* Round Trip Checkbox */}
                <div className="pt-2">
                  <label className="flex items-center gap-2 cursor-pointer select-none text-xs font-semibold text-slate-700">
                    <input
                      type="checkbox"
                      checked={isRoundTrip}
                      onChange={(e) => setIsRoundTrip(e.target.checked)}
                      className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                    />
                    <span>Account for daily Return Trips (2 journeys per commute day)</span>
                  </label>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 4 Key Metric Stat Cards */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4 mt-6">
          {/* Card 1: Monthly Budget */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
              Monthly Budget
            </span>
            <div className="flex items-baseline gap-1 text-2xl font-black text-slate-900">
              <span className="text-base text-slate-400 font-bold">₹</span>
              <span>{budget.toLocaleString('en-IN')}</span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium mt-1 block">
              Limit set for transit
            </span>
          </div>

          {/* Card 2: Projected Spend */}
          <div className={`p-4 rounded-2xl border ${
            isOverBudget ? 'bg-rose-50/70 border-rose-200' : 'bg-blue-50/70 border-blue-200'
          }`}>
            <span className={`text-[11px] font-bold uppercase tracking-wider block mb-1 ${
              isOverBudget ? 'text-rose-700' : 'text-blue-700'
            }`}>
              Projected Spend
            </span>
            <div className="flex items-baseline gap-1 text-2xl font-black text-slate-900">
              <span className="text-base text-slate-400 font-bold">₹</span>
              <span className={isOverBudget ? 'text-rose-600' : 'text-blue-600'}>
                {totalProjectedSpend.toLocaleString('en-IN')}
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium mt-1 block">
              Based on active plans
            </span>
          </div>

          {/* Card 3: Remaining / Overspend */}
          <div className={`p-4 rounded-2xl border ${
            isOverBudget
              ? 'bg-rose-50 border-rose-200'
              : 'bg-emerald-50/70 border-emerald-200'
          }`}>
            <span className={`text-[11px] font-bold uppercase tracking-wider block mb-1 ${
              isOverBudget ? 'text-rose-700' : 'text-emerald-700'
            }`}>
              {isOverBudget ? 'Over Budget' : 'Remaining Balance'}
            </span>
            <div className="flex items-baseline gap-1 text-2xl font-black">
              <span className="text-base font-bold">₹</span>
              <span className={isOverBudget ? 'text-rose-600' : 'text-emerald-600'}>
                {Math.abs(budgetDifference).toLocaleString('en-IN')}
              </span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium mt-1 block">
              {isOverBudget ? 'Review routes below' : `${100 - percentUsed}% cushion left`}
            </span>
          </div>

          {/* Card 4: Daily Average */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 block mb-1">
              Avg. Per Commute Day
            </span>
            <div className="flex items-baseline gap-1 text-2xl font-black text-slate-900">
              <span className="text-base text-slate-400 font-bold">₹</span>
              <span>{dailyAverageSpend}</span>
            </div>
            <span className="text-[11px] text-slate-500 font-medium mt-1 block">
              Over {commutingDays} travel days
            </span>
          </div>
        </div>

        {/* Visual Budget Progress Bar */}
        <div className="mt-6 p-4 sm:p-5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-slate-700">Budget Utilization:</span>
              <span className="text-xs font-black text-slate-900">{percentUsed}% utilized</span>
            </div>
            <div>{getStatusBadge()}</div>
          </div>

          {/* Progress Bar Container */}
          <div className="w-full bg-slate-200 rounded-full h-3 overflow-hidden p-0.5">
            <div
              className={`h-full rounded-full transition-all duration-500 ${getProgressColor()}`}
              style={{ width: `${Math.min(100, percentUsed)}%` }}
            />
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500 font-medium">
            <span>₹0</span>
            <span>
              Projected: ₹{totalProjectedSpend.toLocaleString('en-IN')} of ₹{budget.toLocaleString('en-IN')}
            </span>
            <span>₹{budget.toLocaleString('en-IN')} max</span>
          </div>
        </div>

        {/* Journey Plans Contributing to Projection */}
        <div className="mt-8 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">
                Journeys Factored into Monthly Spend
              </h3>
              <p className="text-xs text-slate-500">
                Toggle routes on or off, or tweak monthly frequency to simulate your projected expense.
              </p>
            </div>

            {/* Filter Pills */}
            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl shrink-0">
              <button
                onClick={() => setActiveTabFilter('all')}
                className={`cursor-pointer px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  activeTabFilter === 'all'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                All ({savedCalculations.length + recentCalculations.length})
              </button>
              <button
                onClick={() => setActiveTabFilter('saved')}
                className={`cursor-pointer px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  activeTabFilter === 'saved'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Saved Commutes ({savedCalculations.length})
              </button>
              <button
                onClick={() => setActiveTabFilter('recent')}
                className={`cursor-pointer px-3 py-1 text-xs font-bold rounded-lg transition-all ${
                  activeTabFilter === 'recent'
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Recent Plans ({recentCalculations.length})
              </button>
            </div>
          </div>

          {/* List of Journeys */}
          <div className="space-y-2.5">
            {/* SAVED COMMUTES ROWS */}
            {(activeTabFilter === 'all' || activeTabFilter === 'saved') &&
              savedCalculations.map(({ journey, isIncluded, singleFare, tripsPerMonth, monthlyCost }) => (
                <div
                  key={journey.id}
                  className={`p-3.5 sm:p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isIncluded
                      ? 'bg-white border-slate-200 shadow-2xs'
                      : 'bg-slate-50/60 border-slate-200/60 opacity-60'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={isIncluded}
                      onChange={() => toggleSavedIncluded(journey.id)}
                      className="mt-1 w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                      title={isIncluded ? 'Exclude from projection' : 'Include in projection'}
                    />

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-xs sm:text-sm text-slate-900">
                          {journey.custom_label || `${journey.source} → ${journey.destination}`}
                        </span>
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-50 text-amber-800 border border-amber-200">
                          <Bookmark className="w-3 h-3 text-amber-600" />
                          <span>Saved Commute</span>
                        </span>
                      </div>

                      <div className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                        <span className="flex items-center gap-1 font-medium text-slate-700">
                          {renderModeIcon(journey.route.segments[0]?.transport_type)}
                          <span>{journey.route.summary_line}</span>
                        </span>
                        <span>•</span>
                        <span>{journey.source} → {journey.destination}</span>
                        <span>•</span>
                        <span className="font-semibold text-slate-700">₹{singleFare} / trip</span>
                      </div>
                    </div>
                  </div>

                  {/* Frequency Controls & Total Cost */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 pl-7 sm:pl-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
                    {/* Stepper for monthly trips */}
                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-xl border border-slate-200">
                      <button
                        onClick={() => handleUpdateFrequency(journey.id, -2, tripsPerMonth)}
                        disabled={!isIncluded || tripsPerMonth <= 2}
                        className="cursor-pointer w-6 h-6 rounded bg-white hover:bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold disabled:opacity-30"
                        title="Fewer trips per month"
                      >
                        -
                      </button>
                      <span className="text-xs font-bold text-slate-700 min-w-16 text-center">
                        {tripsPerMonth} trips/mo
                      </span>
                      <button
                        onClick={() => handleUpdateFrequency(journey.id, 2, tripsPerMonth)}
                        disabled={!isIncluded || tripsPerMonth >= 80}
                        className="cursor-pointer w-6 h-6 rounded bg-white hover:bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold disabled:opacity-30"
                        title="More trips per month"
                      >
                        +
                      </button>
                    </div>

                    {/* Calculated Monthly Cost */}
                    <div className="text-right min-w-20">
                      <div className="text-sm font-black text-slate-900">
                        ₹{monthlyCost.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium">/ month</div>
                    </div>

                    {/* Plan Corridor Action */}
                    <button
                      onClick={() => onPlanCorridor(journey.source, journey.destination)}
                      className="cursor-pointer p-2 rounded-xl bg-slate-50 hover:bg-blue-50 text-slate-600 hover:text-blue-600 border border-slate-200 transition-colors"
                      title="Plan this route now"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}

            {/* RECENT PLANS ROWS */}
            {(activeTabFilter === 'all' || activeTabFilter === 'recent') &&
              recentCalculations.map(({ plan, isIncluded, singleFare, tripsPerMonth, monthlyCost }) => (
                <div
                  key={plan.id}
                  className={`p-3.5 sm:p-4 rounded-2xl border transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 ${
                    isIncluded
                      ? 'bg-white border-slate-200 shadow-2xs'
                      : 'bg-slate-50/60 border-slate-200/60 opacity-60'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    <input
                      type="checkbox"
                      checked={isIncluded}
                      onChange={() => toggleRecentIncluded(plan.id)}
                      className="mt-1 w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"
                      title={isIncluded ? 'Exclude from projection' : 'Include in projection'}
                    />

                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-bold text-xs sm:text-sm text-slate-900">
                          {plan.source} → {plan.destination}
                        </span>
                        <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-50 text-blue-800 border border-blue-200">
                          <History className="w-3 h-3 text-blue-600" />
                          <span>Recent Plan ({plan.timestamp})</span>
                        </span>
                      </div>

                      <div className="text-xs text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                        <span className="flex items-center gap-1 font-medium text-slate-700">
                          {renderModeIcon(plan.transport_type)}
                          <span>{plan.route_summary || 'Transit Route'}</span>
                        </span>
                        {plan.duration_min && <span>• {plan.duration_min} mins</span>}
                        <span>•</span>
                        <span className="font-semibold text-slate-700">₹{singleFare} / trip</span>
                      </div>
                    </div>
                  </div>

                  {/* Frequency Controls & Total Cost */}
                  <div className="flex items-center justify-between sm:justify-end gap-4 pl-7 sm:pl-0 border-t sm:border-t-0 pt-2 sm:pt-0 border-slate-100">
                    {/* Stepper for monthly trips */}
                    <div className="flex items-center gap-1.5 bg-slate-50 px-2 py-1 rounded-xl border border-slate-200">
                      <button
                        onClick={() => handleUpdateFrequency(plan.id, -1, tripsPerMonth)}
                        disabled={!isIncluded || tripsPerMonth <= 1}
                        className="cursor-pointer w-6 h-6 rounded bg-white hover:bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold disabled:opacity-30"
                        title="Fewer trips per month"
                      >
                        -
                      </button>
                      <span className="text-xs font-bold text-slate-700 min-w-16 text-center">
                        {tripsPerMonth} trips/mo
                      </span>
                      <button
                        onClick={() => handleUpdateFrequency(plan.id, 1, tripsPerMonth)}
                        disabled={!isIncluded || tripsPerMonth >= 60}
                        className="cursor-pointer w-6 h-6 rounded bg-white hover:bg-slate-100 border border-slate-200 flex items-center justify-center text-xs font-bold disabled:opacity-30"
                        title="More trips per month"
                      >
                        +
                      </button>
                    </div>

                    {/* Calculated Monthly Cost */}
                    <div className="text-right min-w-20">
                      <div className="text-sm font-black text-slate-900">
                        ₹{monthlyCost.toLocaleString('en-IN')}
                      </div>
                      <div className="text-[10px] text-slate-400 font-medium">/ month</div>
                    </div>

                    {/* Plan Corridor Action */}
                    <button
                      onClick={() => onPlanCorridor(plan.source, plan.destination)}
                      className="cursor-pointer p-2 rounded-xl bg-slate-50 hover:bg-blue-50 text-slate-600 hover:text-blue-600 border border-slate-200 transition-colors"
                      title="Plan this route now"
                    >
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}

            {/* Empty state when no journeys */}
            {savedCalculations.length === 0 && recentCalculations.length === 0 && (
              <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-300 space-y-3">
                <Bookmark className="w-8 h-8 text-slate-400 mx-auto" />
                <h4 className="text-sm font-bold text-slate-700">No journeys tracked yet</h4>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  Bookmark daily commutes or plan routes above. They will automatically appear here with fare tracking!
                </p>
                {onAddSampleJourneys && (
                  <button
                    onClick={onAddSampleJourneys}
                    className="cursor-pointer text-xs font-bold px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors shadow-xs"
                  >
                    Load Sample Hyderabad Student Commutes
                  </button>
                )}
              </div>
            )}
          </div>
        </div>

        {/* Hyderabad Transit Fare Optimization Tip Card */}
        {showSavingsTip && (
          <div className="mt-8 p-4 sm:p-5 rounded-2xl bg-indigo-50/70 border border-indigo-200 flex items-start justify-between gap-3 text-xs text-indigo-900">
            <div className="flex items-start gap-3">
              <span className="p-2 rounded-xl bg-white text-indigo-600 shadow-2xs shrink-0 mt-0.5">
                <Lightbulb className="w-4 h-4" />
              </span>
              <div className="space-y-1">
                <div className="font-bold text-indigo-950 flex items-center gap-1.5">
                  <span>Hyderabad Transit Fare Optimization & Pass Insights</span>
                </div>
                <p className="text-indigo-800 leading-relaxed">
                  {totalProjectedSpend >= 600 ? (
                    <>
                      With your projected spend of <strong>₹{totalProjectedSpend.toLocaleString('en-IN')}/mo</strong>, a{' '}
                      <strong>TGSRTC Student Bus Pass</strong> (available for ~₹165–₹400/quarter) or a{' '}
                      <strong>Hyderabad Metro Smart Card</strong> (10% flat discount) could save you up to{' '}
                      <strong>₹{Math.round(totalProjectedSpend * 0.45)} each month</strong>.
                    </>
                  ) : (
                    <>
                      Your projected spend of <strong>₹{totalProjectedSpend.toLocaleString('en-IN')}/mo</strong> is very efficient!
                      Opting for TGSRTC Ordinary city buses over Express or AC legs keeps your per-trip fare under ₹25.
                    </>
                  )}
                </p>
              </div>
            </div>
            <button
              onClick={() => setShowSavingsTip(false)}
              className="cursor-pointer text-indigo-400 hover:text-indigo-700 text-xs p-1"
              title="Dismiss tip"
            >
              ✕
            </button>
          </div>
        )}
      </div>
    </section>
  );
};
