import React, { useState } from 'react';
import { HelpCircle, AlertTriangle, AlertCircle, CheckCircle2, ChevronDown, ChevronUp, Compass, Radio } from 'lucide-react';

interface HelpViewProps {
  onTestScenario: (scenario: 'no_route' | 'no_live' | 'invalid_loc' | 'service_unavail') => void;
}

export const HelpView: React.FC<HelpViewProps> = ({ onTestScenario }) => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const faqs = [
    {
      q: 'What is the difference between Live and Scheduled arrival time?',
      a: '🟢 LIVE arrival indicates that the vehicle is actively emitting GPS coordinates via an Automated Vehicle Location (AVL) transponder, and the arrival time reflects current traffic speed. 🔵 SCHEDULED arrival indicates that the vehicle does not currently have an active GPS broadcast, so Transit Flow falls back to the published official timetable. We never mislead passengers into thinking timetable data is real-time tracking.'
    },
    {
      q: 'How does Transit Flow calculate my waiting time?',
      a: 'The system uses the formula: Waiting Time = Expected Arrival Time − Current Time. For example, if the current time is 10:17 and Bus 216D is expected at 10:25, your waiting time is 8 minutes.'
    },
    {
      q: 'Why doesn\'t Transit Flow mark one route as "The Best Route"?',
      a: 'Every commuter has distinct priorities: some prefer 0 transfers even if it takes 5 minutes longer; others want the lowest fare or the fastest metro speed. We provide objective data—journey duration, physical changes, and waiting time—letting you decide without algorithm bias.'
    },
    {
      q: 'Can I use Transit Flow when offline or in poor connectivity?',
      a: 'Yes! When live telematics are unavailable due to server or cellular dropouts, Transit Flow seamlessly transitions to 🔵 SCHEDULED timetable calculation and clearly marks the source to keep you informed.'
    }
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-10">
      {/* Title */}
      <div className="bg-white rounded-3xl p-8 shadow-sm border border-slate-200">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-blue-50 text-blue-600 rounded-2xl">
            <HelpCircle className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Help Center & Error Diagnostics
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Guidelines on system workflow, waiting time calculation, and edge-case handling.
            </p>
          </div>
        </div>
      </div>

      {/* System Error Handling Test Center */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-amber-600 bg-amber-50 px-3 py-1 rounded-full">
            Fault Tolerance & Resilience
          </span>
          <h2 className="text-xl font-bold text-slate-900 mt-2">
            System Error State Handling
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Transit Flow gracefully handles unpredictable transit disruptions, missing GPS data, and network outages. Test how the system responds:
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Situation 1 */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                <AlertCircle className="w-4 h-4 text-blue-600" />
                <span>1. No Route Found</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 italic">
                “We couldn't find a suitable public transport route between these locations.”
              </p>
            </div>
            <button
              onClick={() => onTestScenario('no_route')}
              className="cursor-pointer mt-4 py-2 px-3 rounded-xl bg-slate-200 hover:bg-blue-600 hover:text-white text-slate-800 text-xs font-bold transition-colors text-left"
            >
              Simulate: No Route Found →
            </button>
          </div>

          {/* Situation 2 */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                <Radio className="w-4 h-4 text-emerald-600" />
                <span>2. No Live Information</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 italic">
                “Live arrival information is currently unavailable. Showing scheduled information instead.”
              </p>
            </div>
            <button
              onClick={() => onTestScenario('no_live')}
              className="cursor-pointer mt-4 py-2 px-3 rounded-xl bg-slate-200 hover:bg-emerald-600 hover:text-white text-slate-800 text-xs font-bold transition-colors text-left"
            >
              Simulate: Lost Live GPS Feed →
            </button>
          </div>

          {/* Situation 3 */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                <AlertTriangle className="w-4 h-4 text-amber-600" />
                <span>3. Invalid Location</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 italic">
                “Please enter a valid source and destination.”
              </p>
            </div>
            <button
              onClick={() => onTestScenario('invalid_loc')}
              className="cursor-pointer mt-4 py-2 px-3 rounded-xl bg-slate-200 hover:bg-amber-600 hover:text-white text-slate-800 text-xs font-bold transition-colors text-left"
            >
              Simulate: Empty/Invalid Input →
            </button>
          </div>

          {/* Situation 4 */}
          <div className="p-5 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold text-slate-700 mb-1">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <span>4. Service Unavailable</span>
              </div>
              <p className="text-xs text-slate-600 mt-1 italic">
                “This service may currently be unavailable. Please check another route.”
              </p>
            </div>
            <button
              onClick={() => onTestScenario('service_unavail')}
              className="cursor-pointer mt-4 py-2 px-3 rounded-xl bg-slate-200 hover:bg-red-600 hover:text-white text-slate-800 text-xs font-bold transition-colors text-left"
            >
              Simulate: Service Disruption →
            </button>
          </div>
        </div>
      </div>

      {/* Frequently Asked Questions */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
        <h2 className="text-xl font-bold text-slate-900 mb-4">
          Frequently Asked Questions
        </h2>
        <div className="space-y-3">
          {faqs.map((faq, idx) => {
            const isOpen = openFaq === idx;
            return (
              <div
                key={idx}
                className="border border-slate-200 rounded-2xl overflow-hidden transition-all"
              >
                <button
                  onClick={() => setOpenFaq(isOpen ? null : idx)}
                  className="cursor-pointer w-full p-4 text-left font-bold text-slate-900 text-sm flex items-center justify-between bg-slate-50 hover:bg-slate-100 transition-colors"
                >
                  <span>{faq.q}</span>
                  {isOpen ? <ChevronUp className="w-4 h-4 text-slate-500" /> : <ChevronDown className="w-4 h-4 text-slate-500" />}
                </button>
                {isOpen && (
                  <div className="p-4 bg-white text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
