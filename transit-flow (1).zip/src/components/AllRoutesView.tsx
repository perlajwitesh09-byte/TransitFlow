import React, { useState } from 'react';
import { NETWORK_ROUTES_CATALOG } from '../data/transitData';
import { Bus, Train, Milestone, Clock, MapPin, Search, ChevronRight } from 'lucide-react';
import { DataSourceBadge } from './DataSourceBadge';

interface AllRoutesViewProps {
  onPlanRoute: (source: string, dest: string) => void;
  onCheckStop: (stopName: string) => void;
}

export const AllRoutesView: React.FC<AllRoutesViewProps> = ({ onPlanRoute, onCheckStop }) => {
  const [filterType, setFilterType] = useState<'all' | 'bus' | 'metro' | 'train'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const filtered = NETWORK_ROUTES_CATALOG.filter(r => {
    if (filterType !== 'all' && r.transport_type !== filterType) return false;
    if (searchTerm) {
      const q = searchTerm.toLowerCase();
      return (
        r.route_number.toLowerCase().includes(q) ||
        r.name.toLowerCase().includes(q) ||
        r.stops.some(s => s.toLowerCase().includes(q))
      );
    }
    return true;
  });

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-8">
      {/* Title */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              Network Catalog
            </span>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight mt-2">
              Transit Routes & Corridors
            </h1>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Browse all scheduled bus lines, rapid metro lines, and suburban train services across the Hyderabad metro network.
            </p>
          </div>

          <div className="flex items-center gap-1.5 bg-slate-100 p-1 rounded-xl">
            {(['all', 'bus', 'metro', 'train'] as const).map(mode => (
              <button
                key={mode}
                onClick={() => setFilterType(mode)}
                className={`cursor-pointer px-3 py-1.5 rounded-lg text-xs font-bold capitalize transition-all ${
                  filterType === mode
                    ? 'bg-white text-slate-900 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                {mode}
              </button>
            ))}
          </div>
        </div>

        {/* Search */}
        <div className="mt-6 relative max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by line number, stop name, or corridor..."
            className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-xs font-semibold placeholder-slate-400 focus:bg-white focus:border-blue-600 outline-none"
          />
        </div>
      </div>

      {/* Routes Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filtered.map(route => (
          <div
            key={route.route_id}
            className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-3 mb-3">
                <div className="flex items-center gap-3">
                  <div className="p-3 rounded-2xl bg-blue-50 text-blue-600">
                    {route.transport_type === 'bus' && <Bus className="w-5 h-5" />}
                    {route.transport_type === 'metro' && <Milestone className="w-5 h-5" />}
                    {route.transport_type === 'train' && <Train className="w-5 h-5" />}
                  </div>
                  <div>
                    <span className="text-xs font-extrabold uppercase text-slate-400 tracking-wider">
                      {route.transport_type} Line
                    </span>
                    <h3 className="text-lg font-black text-slate-900">
                      {route.route_number} — {route.name}
                    </h3>
                  </div>
                </div>

                <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 text-slate-700">
                  Every {route.frequency_mins}m
                </span>
              </div>

              {/* Operating hours & Fare */}
              <div className="grid grid-cols-3 gap-2 py-3 border-y border-slate-100 text-xs text-center my-3">
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold">Hours</span>
                  <span className="font-semibold text-slate-800">{route.operating_hours}</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold">Distance</span>
                  <span className="font-semibold text-slate-800">{route.distance_km} km</span>
                </div>
                <div>
                  <span className="text-slate-400 block text-[10px] font-bold">Base Fare</span>
                  <span className="font-semibold text-slate-800">₹{route.base_fare}</span>
                </div>
              </div>

              {/* Stops list */}
              <div className="mt-3">
                <span className="text-xs font-bold text-slate-500 block mb-2">
                  Key Stops on Route:
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {route.stops.map(stop => (
                    <button
                      key={stop}
                      onClick={() => onCheckStop(stop)}
                      className="cursor-pointer text-[11px] px-2.5 py-1 bg-slate-100 hover:bg-blue-50 hover:text-blue-700 rounded-lg text-slate-700 font-medium transition-colors border border-slate-200"
                    >
                      {stop}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Action */}
            <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
              <span className="text-xs text-slate-400">
                {route.stops[0]} → {route.stops[route.stops.length - 1]}
              </span>

              <button
                onClick={() => onPlanRoute(route.stops[0], route.stops[route.stops.length - 1])}
                className="cursor-pointer px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors flex items-center gap-1.5"
              >
                <span>Plan Corridor</span>
                <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
