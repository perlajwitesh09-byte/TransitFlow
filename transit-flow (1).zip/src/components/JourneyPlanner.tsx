import React, { useState } from 'react';
import { RouteOption, TransportType, JourneyPreferences, SortCriteria, PriorityMode, SavedJourney } from '../types/transit';
import { DataSourceBadge } from './DataSourceBadge';
import { validate24HourTime, getCurrentKolkataDateTime } from '../utils/time24';
import {
  Clock,
  Compass,
  ArrowRight,
  Filter,
  SlidersHorizontal,
  Bus,
  Train,
  Milestone,
  AlertCircle,
  Eye,
  Info,
  Check,
  RefreshCw,
  IndianRupee,
  Footprints,
  Bookmark,
  BookmarkCheck,
  Layers,
  Sparkles,
  MapPin,
  ShieldCheck
} from 'lucide-react';

interface JourneyPlannerProps {
  source: string;
  destination: string;
  routes: RouteOption[];
  preferences: JourneyPreferences;
  onUpdatePreferences: (newPrefs: JourneyPreferences) => void;
  onSelectRouteForDetails: (route: RouteOption) => void;
  onGoToWaitingTimeForStop: (stopName: string) => void;
  isLiveActive: boolean;
  onRefreshSearch: () => void;
  onSaveJourney?: (route: RouteOption) => void;
  savedJourneyIds?: string[];
  errorMessage?: string | null;
}

export const JourneyPlanner: React.FC<JourneyPlannerProps> = ({
  source,
  destination,
  routes,
  preferences,
  onUpdatePreferences,
  onSelectRouteForDetails,
  onGoToWaitingTimeForStop,
  isLiveActive,
  onRefreshSearch,
  onSaveJourney,
  savedJourneyIds = [],
  errorMessage,
}) => {
  const [showFiltersMobile, setShowFiltersMobile] = useState(false);
  const [compareMode, setCompareMode] = useState(false);
  const [localSavedIds, setLocalSavedIds] = useState<string[]>(savedJourneyIds);
  const [timeValidationError, setTimeValidationError] = useState<string | null>(null);

  const handleTimeInputChange = (inputVal: string) => {
    const clean = inputVal.trim();
    if (!clean) {
      setTimeValidationError(null);
      onUpdatePreferences({
        ...preferences,
        preferredDepartureTime: '',
      });
      return;
    }

    const validation = validate24HourTime(clean);
    if (validation.isValid) {
      setTimeValidationError(null);
      onUpdatePreferences({
        ...preferences,
        preferredDepartureTime: validation.normalized || clean,
      });
    } else {
      // If user is actively typing partial time, e.g. "2" or "21:", give typing leeway before showing error
      if (clean.length >= 4 || !/^(\d{0,2}):?(\d{0,2})$/.test(clean)) {
        setTimeValidationError(validation.error || 'Invalid 24-hour time. Use HH:MM between 00:00 and 23:59.');
      } else {
        setTimeValidationError(null);
      }
      onUpdatePreferences({
        ...preferences,
        preferredDepartureTime: clean,
      });
    }
  };

  const handleQuickTimeSelect = (quickTime: string) => {
    setTimeValidationError(null);
    if (quickTime === 'Now') {
      const kolkataNow = getCurrentKolkataDateTime().time24;
      onUpdatePreferences({
        ...preferences,
        preferredDepartureTime: kolkataNow,
      });
    } else {
      onUpdatePreferences({
        ...preferences,
        preferredDepartureTime: quickTime,
      });
    }
  };

  const handleSortChange = (sortBy: SortCriteria) => {
    onUpdatePreferences({
      ...preferences,
      sortBy,
      lowestFare: sortBy === 'cheapest',
      shortestTime: sortBy === 'fastest',
      fewerChanges: sortBy === 'fewest_changes',
    });
  };

  const handlePriorityChange = (priorityMode: PriorityMode) => {
    onUpdatePreferences({
      ...preferences,
      priorityMode,
    });
  };

  const handleModeFilter = (mode: TransportType) => {
    onUpdatePreferences({
      ...preferences,
      transportMode: mode,
    });
  };

  const handleSaveClick = (route: RouteOption) => {
    if (onSaveJourney) {
      onSaveJourney(route);
    }
    setLocalSavedIds(prev =>
      prev.includes(route.id) ? prev.filter(id => id !== route.id) : [...prev, route.id]
    );
  };

  const clearAllFilters = () => {
    onUpdatePreferences({
      shortestTime: false,
      fewerChanges: false,
      lowestFare: false,
      lessWaiting: false,
      transportMode: 'all',
      sortBy: 'recommended',
      priorityMode: 'balanced',
      maxBudget: null,
      maxChanges: null,
      maxWalkingKm: null,
      preferredDepartureTime: '10:17',
    });
  };

  // Format minutes into "1 hr 35 min" or "32 min"
  const formatDuration = (mins: number) => {
    if (mins < 60) return `${mins} min`;
    const h = Math.floor(mins / 60);
    const m = mins % 60;
    return m > 0 ? `${h} hr ${m} min` : `${h} hr`;
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8 space-y-6">
      {/* Accuracy Warning Banner as required */}
      <div className="bg-amber-50 border border-amber-200/80 rounded-2xl px-4 py-2.5 text-xs text-amber-900 flex items-center justify-between gap-3 shadow-2xs">
        <div className="flex items-center gap-2">
          <Info className="w-4 h-4 text-amber-600 shrink-0" />
          <span className="font-semibold">
            «"Transport timings and fares are estimates and may change."»
          </span>
        </div>
        <span className="text-[10px] font-bold text-amber-700 uppercase tracking-wider hidden sm:inline">
          Demo Transport Data
        </span>
      </div>

      {/* Corridor Header */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-3 py-1 rounded-full">
              Hyderabad Journey Plan
            </span>
            <div className="flex items-center gap-3 mt-2 flex-wrap">
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {source || 'Starting Location'}
              </h1>
              <ArrowRight className="w-6 h-6 text-slate-400" />
              <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
                {destination || 'Destination'}
              </h1>
            </div>
            <p className="text-xs sm:text-sm text-slate-500 mt-1">
              Select your preferred route option based on budget, travel time, and physical transfers.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowFiltersMobile(!showFiltersMobile)}
              className="cursor-pointer md:hidden px-4 py-2.5 rounded-xl border border-slate-200 bg-slate-50 text-slate-700 text-xs font-bold flex items-center gap-2"
            >
              <Filter className="w-3.5 h-3.5" />
              <span>Filters</span>
            </button>

            <button
              onClick={() => setCompareMode(!compareMode)}
              className={`cursor-pointer px-4 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${
                compareMode
                  ? 'bg-slate-900 text-white border-slate-900 shadow-xs'
                  : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>{compareMode ? 'Show Route Cards' : 'Compare Matrix'}</span>
            </button>

            <button
              onClick={onRefreshSearch}
              title="Refresh Routes"
              className="cursor-pointer p-2.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-600 transition-colors"
            >
              <RefreshCw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sorting and Student Preference Bar */}
        <div className="mt-6 pt-6 border-t border-slate-100 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          {/* Sort Tabs */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <span className="text-xs font-bold text-slate-400 mr-1 uppercase">Sort:</span>
            {[
              { id: 'recommended', label: '💡 Recommended' },
              { id: 'cheapest', label: '💰 Lowest Fare' },
              { id: 'fastest', label: '⚡ Shortest Time' },
              { id: 'fewest_changes', label: '🔄 Fewest Changes' },
              { id: 'least_walking', label: '🚶 Least Walking' },
              { id: 'earliest_arrival', label: '⏱️ Earliest Arrival' },
              { id: 'latest_departure', label: '🌙 Latest Departure' },
            ].map(tab => (
              <button
                key={tab.id}
                onClick={() => handleSortChange(tab.id as SortCriteria)}
                className={`cursor-pointer px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  preferences.sortBy === tab.id
                    ? 'bg-blue-600 text-white shadow-2xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          {/* Student Priority Mode */}
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase">Student Priority:</span>
            {(['budget', 'time', 'balanced'] as PriorityMode[]).map(p => (
              <button
                key={p}
                onClick={() => handlePriorityChange(p)}
                className={`cursor-pointer text-[11px] font-bold px-2.5 py-1 rounded-md capitalize transition-all border ${
                  preferences.priorityMode === p
                    ? p === 'budget'
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300 font-extrabold'
                      : p === 'time'
                      ? 'bg-blue-50 text-blue-800 border-blue-300 font-extrabold'
                      : 'bg-indigo-50 text-indigo-800 border-indigo-300 font-extrabold'
                    : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'
                }`}
              >
                {p === 'budget' ? '💰 Budget' : p === 'time' ? '⚡ Time' : '⚖️ Balanced'}
              </button>
            ))}
          </div>
        </div>

        {/* Student Constraints & Filters Panel (Collapsible on mobile) */}
        <div className={`mt-4 pt-4 border-t border-slate-100 ${showFiltersMobile ? 'block' : 'hidden md:block'}`}>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 text-xs">
            {/* Max Budget */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Max Budget:
              </label>
              <select
                value={preferences.maxBudget || ''}
                onChange={(e) => onUpdatePreferences({
                  ...preferences,
                  maxBudget: e.target.value ? Number(e.target.value) : null
                })}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 outline-none"
              >
                <option value="">Any Budget (₹)</option>
                <option value="20">Up to ₹20</option>
                <option value="35">Up to ₹35</option>
                <option value="50">Up to ₹50</option>
                <option value="75">Up to ₹75</option>
                <option value="120">Up to ₹120</option>
              </select>
            </div>

            {/* Max Changes */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Max Changes:
              </label>
              <select
                value={preferences.maxChanges !== null && preferences.maxChanges !== undefined ? preferences.maxChanges : ''}
                onChange={(e) => onUpdatePreferences({
                  ...preferences,
                  maxChanges: e.target.value !== '' ? Number(e.target.value) : null
                })}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 outline-none"
              >
                <option value="">Any Changes</option>
                <option value="0">Direct Only (0 changes)</option>
                <option value="1">Max 1 Change</option>
                <option value="2">Max 2 Changes</option>
              </select>
            </div>

            {/* Max Walking */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Max Walking:
              </label>
              <select
                value={preferences.maxWalkingKm || ''}
                onChange={(e) => onUpdatePreferences({
                  ...preferences,
                  maxWalkingKm: e.target.value ? Number(e.target.value) : null
                })}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 outline-none"
              >
                <option value="">Any Distance</option>
                <option value="0.3">Under 300 m</option>
                <option value="0.5">Under 500 m</option>
                <option value="1.0">Under 1.0 km</option>
                <option value="2.0">Under 2.0 km</option>
              </select>
            </div>

            {/* Max Journey Time */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Max Journey Time:
              </label>
              <select
                value={preferences.maxTimeMin || ''}
                onChange={(e) => onUpdatePreferences({
                  ...preferences,
                  maxTimeMin: e.target.value ? Number(e.target.value) : undefined
                })}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 outline-none"
              >
                <option value="">Any Duration</option>
                <option value="30">Under 30 min</option>
                <option value="45">Under 45 min</option>
                <option value="60">Under 60 min</option>
                <option value="90">Under 90 min</option>
                <option value="120">Under 2 hours</option>
              </select>
            </div>

            {/* Bus Service Type */}
            <div>
              <label className="block text-[11px] font-bold text-slate-500 uppercase mb-1">
                Bus Service Type:
              </label>
              <select
                value={preferences.busServiceType || 'All'}
                onChange={(e) => onUpdatePreferences({
                  ...preferences,
                  busServiceType: e.target.value
                })}
                className="w-full px-2.5 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs font-semibold text-slate-800 outline-none"
              >
                <option value="All">All Bus Types</option>
                <option value="Ordinary">Ordinary / City Ordinary</option>
                <option value="Express">Metro Express</option>
                <option value="Deluxe">Metro Deluxe</option>
                <option value="Pushpak">Pushpak Airport AC</option>
              </select>
            </div>

            {/* Preferred Departure Time & Target */}
            <div>
              <div className="flex items-center justify-between mb-1">
                <label className="block text-[11px] font-bold text-slate-500 uppercase">
                  Time (24H: HH:MM):
                </label>
                <span className="text-[10px] font-semibold text-slate-400">
                  IST
                </span>
              </div>

              <div className="relative">
                <input
                  type="text"
                  value={preferences.preferredDepartureTime ?? '10:17'}
                  onChange={(e) => handleTimeInputChange(e.target.value)}
                  className={`w-full px-2.5 py-1.5 bg-slate-50 border rounded-lg text-xs font-semibold text-slate-800 outline-none ${
                    timeValidationError
                      ? 'border-red-400 bg-red-50/40 text-red-900 focus:ring-1 focus:ring-red-400'
                      : 'border-slate-200 focus:border-blue-400'
                  }`}
                  placeholder="e.g. 08:30"
                />
              </div>

              {timeValidationError && (
                <div className="mt-1.5 p-1.5 bg-red-50 border border-red-200 rounded-lg text-[10px] text-red-700 flex items-start gap-1 leading-tight">
                  <AlertCircle className="w-3 h-3 text-red-600 shrink-0 mt-0.5" />
                  <span>{timeValidationError}</span>
                </div>
              )}

              {/* Quick Select */}
              <div className="mt-1.5 flex items-center gap-1 flex-wrap">
                {[
                  { label: 'Now', val: 'Now' },
                  { label: '08:00', val: '08:00' },
                  { label: '17:00', val: '17:00' },
                  { label: '21:00', val: '21:00' },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => handleQuickTimeSelect(item.val)}
                    className={`cursor-pointer px-1.5 py-0.5 rounded text-[9px] font-bold border transition-colors ${
                      preferences.preferredDepartureTime === item.val
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'bg-white text-slate-600 border-slate-200 hover:border-blue-300'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Error State Banner */}
      {errorMessage && (
        <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-2xl flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
          <span className="text-sm font-semibold">{errorMessage}</span>
        </div>
      )}

      {/* Empty State */}
      {routes.length === 0 && !errorMessage && (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-4">
          <div className="w-12 h-12 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <AlertCircle className="w-6 h-6" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            No routes matching current filters
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            “We couldn't find a suitable public transport route between these locations under the selected budget or transfer constraints.”
          </p>
          <button
            onClick={clearAllFilters}
            className="cursor-pointer text-xs font-bold px-4 py-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors"
          >
            Reset All Filters
          </button>
        </div>
      )}

      {/* Section 14 Fallback / Timings Disclaimer Notice */}
      {routes.length > 0 && (
        <div className="bg-amber-50/80 border border-amber-200/90 rounded-2xl p-3.5 text-center text-xs text-amber-900 font-medium flex items-center justify-center gap-2">
          <Info className="w-4 h-4 text-amber-600 shrink-0" />
          <span>«"Timings and fares may change. Please verify the latest service information before travelling."»</span>
        </div>
      )}

      {/* ROUTE CARDS VIEW (Standard Flow - Section 7) */}
      {!compareMode && routes.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between px-2 text-xs font-semibold text-slate-600">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
              Found <strong className="text-slate-900">{routes.length}</strong> valid transit journey {routes.length === 1 ? 'option' : 'options'}
            </span>
            <span className="text-[11px] text-slate-400">
              Up to 20 options • Real timetable schedules
            </span>
          </div>

          {routes.map((route, idx) => {
            const isSaved = localSavedIds.includes(route.id);
            return (
              <div
                key={route.id}
                className="bg-white rounded-3xl p-6 sm:p-7 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-center gap-2.5 flex-wrap">
                    <span className="px-3 py-1 rounded-full text-xs font-black bg-blue-50 text-blue-700 border border-blue-200 flex items-center gap-1.5">
                      <Bus className="w-3.5 h-3.5 text-blue-600" />
                      <span>{route.operator ? `${route.operator} ${route.route_number || ''}` : route.route_label.split('—')[0]?.trim()}</span>
                    </span>

                    {route.bus_id && (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-blue-100/70 text-blue-900 border border-blue-200">
                        Bus: {route.bus_id}
                      </span>
                    )}

                    {route.interval_from_prev_mins !== undefined && (
                      <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-800 border border-emerald-200 flex items-center gap-1">
                        <Clock className="w-3 h-3 text-emerald-600" />
                        <span>+{route.interval_from_prev_mins}m gap</span>
                      </span>
                    )}

                    {route.bus_type && (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700 border border-slate-200">
                        {route.bus_type}
                      </span>
                    )}

                    {/* Section 9: Realistic Route Labels (Cheapest, Fastest, Fewest Changes, Balanced) */}
                    <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-extrabold ${
                      route.score_tag === 'Cheapest'
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : route.score_tag === 'Fastest'
                        ? 'bg-blue-100 text-blue-800 border border-blue-300'
                        : route.score_tag === 'Fewest Changes'
                        ? 'bg-purple-100 text-purple-800 border border-purple-300'
                        : 'bg-slate-100 text-slate-800 border border-slate-300'
                    }`}>
                      • {route.score_tag}
                    </span>
                  </div>

                  <div className="flex items-center gap-2">
                    {/* Section 10: Transport status/source badge */}
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-700 bg-slate-50 px-2.5 py-1 rounded-full border border-slate-200">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{route.data_source_label || 'TGSRTC Verified transport information'}</span>
                    </span>

                    <button
                      type="button"
                      onClick={() => handleSaveClick(route)}
                      title={isSaved ? 'Remove from Saved' : 'Save Journey'}
                      className={`cursor-pointer p-2 rounded-xl border transition-colors ${
                        isSaved
                          ? 'bg-amber-50 border-amber-300 text-amber-600'
                          : 'bg-slate-50 border-slate-200 text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      {isSaved ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Direction Subtitle (Section 7) and Late-Night Rollover Indicator */}
                {(() => {
                  const isNextDay = Boolean(
                    route.next_day_arrival ||
                    route.arrival_destination_time?.includes('+1') ||
                    (route.departure_time && route.arrival_destination_time && !route.arrival_is_estimated && route.arrival_destination_time < route.departure_time)
                  );
                  const cleanArrivalDisplay = (route.arrival_destination_time || '').replace(/\s*\(\+1\s*day\)/i, '');

                  return (
                    <>
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                        <div className="text-base sm:text-lg font-black text-slate-900 flex items-center gap-2">
                          <span>{route.direction || `${source || route.all_stops[0]} → ${destination || route.all_stops[route.all_stops.length - 1]}`}</span>
                        </div>

                        {isNextDay && (
                          <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-indigo-50 border border-indigo-200 text-indigo-900 rounded-full text-xs font-bold w-fit shadow-2xs">
                            <span>🌙</span>
                            <span>Overnight Journey — Arrives Next Day (+1 day)</span>
                          </span>
                        )}
                      </div>

                      {/* Timeline: Departure ─────────── Arrival */}
                      <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
                        <div className="flex items-center justify-between text-xs">
                          <div>
                            <span className="text-slate-400 block text-[10px] uppercase font-bold">Departure (24H)</span>
                            <span className="text-base sm:text-lg font-black text-blue-700">{route.departure_time}</span>
                            {route.departure_datetime && (
                              <span className="text-[10px] text-slate-400 block font-mono">
                                {route.departure_datetime}
                              </span>
                            )}
                            <span className="text-slate-600 block text-[11px] font-medium truncate max-w-[120px] sm:max-w-none">
                              {route.all_stops[0]}
                            </span>
                          </div>

                          <div className="flex-1 mx-3 sm:mx-8 flex flex-col items-center">
                            <span className="text-[11px] font-extrabold text-slate-700 mb-1">
                              ⏱ {route.duration_text || formatDuration(route.journey_time_min)}
                            </span>
                            <div className="w-full h-0.5 bg-slate-300 relative flex items-center justify-center">
                              <div className="w-2 h-2 rounded-full bg-blue-600 absolute left-0" />
                              <ArrowRight className="w-4 h-4 text-slate-400 absolute" />
                              <div className="w-2 h-2 rounded-full bg-emerald-600 absolute right-0" />
                            </div>
                            <span className="text-[10px] font-bold text-slate-500 mt-1">
                              {route.changes_count === 0 ? '🔄 0 changes' : `🔄 ${route.changes_count} change`}
                            </span>
                          </div>

                          <div className="text-right">
                            <span className="text-slate-400 block text-[10px] uppercase font-bold">
                              {route.arrival_is_estimated ? 'Arrival (Est.)' : 'Arrival (24H)'}
                            </span>
                            <div className="flex items-baseline justify-end gap-1">
                              <span className="text-base sm:text-lg font-black text-emerald-700">
                                {route.arrival_is_estimated ? 'Estimated' : cleanArrivalDisplay}
                              </span>
                              {isNextDay && !route.arrival_is_estimated && (
                                <span className="text-xs font-black text-indigo-700 bg-indigo-100 px-1.5 py-0.5 rounded">
                                  +1 day
                                </span>
                              )}
                            </div>
                            {route.arrival_datetime && (
                              <span className="text-[10px] text-slate-400 block font-mono">
                                {route.arrival_datetime}
                              </span>
                            )}
                            <span className="text-slate-600 block text-[11px] font-medium truncate max-w-[120px] sm:max-w-none">
                              {route.all_stops[route.all_stops.length - 1]}
                            </span>
                          </div>
                        </div>
                      </div>
                    </>
                  );
                })()}

                {/* Metrics Grid */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 py-2 text-xs">
                  <div>
                    <span className="text-slate-400 block text-[11px] font-bold">Fare</span>
                    <span className="text-lg font-black text-emerald-700">
                      {route.fare_verified ? (route.fare_formatted || `₹${route.fare_inr}`) : 'Check current fare'}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[11px] font-bold">Journey Duration</span>
                    <span className="text-base font-extrabold text-slate-900">
                      {route.duration_text || formatDuration(route.journey_time_min)}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[11px] font-bold">Changes / Transfers</span>
                    <span className="text-base font-extrabold text-slate-900">
                      {route.changes_count === 0 ? '0 changes (Direct)' : `${route.changes_count} transfer`}
                    </span>
                  </div>

                  <div>
                    <span className="text-slate-400 block text-[11px] font-bold">Total Stops</span>
                    <span className="text-base font-extrabold text-slate-900">
                      {route.total_stops_count} stops ({route.distance_km} km)
                    </span>
                  </div>
                </div>

                {/* Via Highlights (Section 7: Via: Begumpet • Punjagutta • Film Nagar • Dargah) */}
                {route.via_highlights && route.via_highlights.length > 0 && (
                  <div className="text-xs text-slate-700 bg-slate-50/80 rounded-xl p-3 border border-slate-100 flex items-start gap-2">
                    <span className="font-bold text-slate-900 shrink-0">Via:</span>
                    <span className="font-medium text-slate-600">
                      {route.via_highlights.join(' • ')}
                    </span>
                  </div>
                )}

                {/* Footer & Actions */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2 border-t border-slate-100">
                  <div className="text-[11px] text-slate-500">
                    {route.last_verified && <span>Last verified: {route.last_verified} • </span>}
                    <span>Service: {route.operating_days?.join(', ') || 'Daily'}</span>
                  </div>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => onGoToWaitingTimeForStop(route.segments[0]?.from_stop || source)}
                      className="cursor-pointer px-3.5 py-2.5 rounded-xl border border-slate-200 bg-slate-50 hover:bg-slate-100 text-slate-700 text-xs font-bold transition-colors"
                    >
                      Check Waiting Time
                    </button>

                    <button
                      type="button"
                      onClick={() => onSelectRouteForDetails(route)}
                      className="cursor-pointer px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors shadow-xs flex items-center gap-1.5"
                    >
                      <Eye className="w-3.5 h-3.5" />
                      <span>View Full Route</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* MATRIX COMPARISON VIEW (Side-by-side) */}
      {compareMode && routes.length > 0 && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm overflow-x-auto">
          <table className="w-full text-left text-xs min-w-[650px]">
            <thead>
              <tr className="border-b border-slate-200 text-slate-500 font-bold uppercase">
                <th className="py-3 px-4">Route</th>
                <th className="py-3 px-4">Mode Summary</th>
                <th className="py-3 px-4">Fare</th>
                <th className="py-3 px-4">Duration</th>
                <th className="py-3 px-4">Changes</th>
                <th className="py-3 px-4">Walking</th>
                <th className="py-3 px-4">Student Score</th>
                <th className="py-3 px-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {routes.map(r => (
                <tr key={r.id} className="hover:bg-slate-50 transition-colors">
                  <td className="py-3.5 px-4 font-bold text-slate-900">{r.route_label.split('—')[0]}</td>
                  <td className="py-3.5 px-4 font-medium text-slate-700">{r.summary_line}</td>
                  <td className="py-3.5 px-4 font-bold text-emerald-700">₹{r.fare_inr}</td>
                  <td className="py-3.5 px-4 font-semibold text-slate-800">{formatDuration(r.journey_time_min)}</td>
                  <td className="py-3.5 px-4">{r.changes_count === 0 ? 'Direct (0)' : r.changes_count}</td>
                  <td className="py-3.5 px-4">{r.walking_distance_km} km</td>
                  <td className="py-3.5 px-4 font-bold text-blue-600">{r.route_score}/100</td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => onSelectRouteForDetails(r)}
                      className="cursor-pointer px-3 py-1.5 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs"
                    >
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
