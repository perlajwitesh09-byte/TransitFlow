import React, { useState } from 'react';
import { RouteOption, SavedJourney } from '../types/transit';
import { DataSourceBadge } from './DataSourceBadge';
import {
  Bookmark,
  BookmarkCheck,
  Trash2,
  MapPin,
  Clock,
  IndianRupee,
  Footprints,
  Sparkles,
  ArrowRight,
  Eye,
  Plus,
  GraduationCap,
  Bus,
  Train,
  Milestone
} from 'lucide-react';

interface SavedJourneysPageProps {
  savedJourneys: SavedJourney[];
  onRemoveSavedJourney: (id: string) => void;
  onUpdateJourneyLabel: (id: string, label: string) => void;
  onViewRouteDetails: (route: RouteOption) => void;
  onPlanJourney: (source: string, destination: string) => void;
  onCheckWaitingTime: (stopName: string) => void;
  onAddSampleJourneys: () => void;
}

export const SavedJourneysPage: React.FC<SavedJourneysPageProps> = ({
  savedJourneys,
  onRemoveSavedJourney,
  onUpdateJourneyLabel,
  onViewRouteDetails,
  onPlanJourney,
  onCheckWaitingTime,
  onAddSampleJourneys,
}) => {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLabelText, setEditLabelText] = useState('');

  const startEdit = (item: SavedJourney) => {
    setEditingId(item.id);
    setEditLabelText(item.custom_label);
  };

  const saveEdit = (id: string) => {
    if (editLabelText.trim()) {
      onUpdateJourneyLabel(id, editLabelText.trim());
    }
    setEditingId(null);
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-6">
      <div className="bg-white rounded-3xl p-6 sm:p-8 shadow-sm border border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 text-xs font-bold border border-amber-200 mb-2">
            <BookmarkCheck className="w-3.5 h-3.5" />
            <span>Saved Student Commutes</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
            My Saved Journeys
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 mt-1">
            Bookmarked routes for daily classes, college labs, internships, and weekend trips across Hyderabad.
          </p>
        </div>

        {savedJourneys.length === 0 && (
          <button
            onClick={onAddSampleJourneys}
            className="cursor-pointer px-4 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-2 shrink-0"
          >
            <Plus className="w-4 h-4" />
            <span>Add Student Daily Commutes</span>
          </button>
        )}
      </div>

      {savedJourneys.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-600 flex items-center justify-center mx-auto">
            <Bookmark className="w-7 h-7" />
          </div>
          <h3 className="text-lg font-bold text-slate-900">
            No saved commutes yet
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto">
            Bookmark frequent journeys like your daily college trip or hostel commute from the Plan Journey results to access them here instantly.
          </p>
          <button
            onClick={onAddSampleJourneys}
            className="cursor-pointer text-xs font-bold px-5 py-2.5 bg-blue-600 text-white rounded-xl hover:bg-blue-700 transition-colors shadow-xs"
          >
            Load Sample Hyderabad Student Routes
          </button>
        </div>
      ) : (
        <div className="space-y-4">
          {savedJourneys.map(item => {
            const { route } = item;
            const isEditing = editingId === item.id;

            return (
              <div
                key={item.id}
                className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4"
              >
                {/* Header & Custom Label */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-slate-100 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="p-2 rounded-xl bg-blue-50 text-blue-600">
                      <GraduationCap className="w-4 h-4" />
                    </span>
                    {isEditing ? (
                      <div className="flex items-center gap-2">
                        <input
                          type="text"
                          value={editLabelText}
                          onChange={(e) => setEditLabelText(e.target.value)}
                          className="px-2.5 py-1 text-xs font-bold text-slate-900 border border-blue-400 rounded-lg outline-none"
                          autoFocus
                        />
                        <button
                          onClick={() => saveEdit(item.id)}
                          className="cursor-pointer text-[11px] font-bold px-2 py-1 bg-blue-600 text-white rounded-md"
                        >
                          Save
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <h3 className="text-sm font-extrabold text-slate-900">
                          {item.custom_label}
                        </h3>
                        <button
                          onClick={() => startEdit(item)}
                          className="cursor-pointer text-[10px] text-slate-400 hover:text-blue-600 underline font-semibold"
                        >
                          Edit Name
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-slate-100 text-slate-600">
                      Saved on {item.created_at}
                    </span>
                    <button
                      onClick={() => onRemoveSavedJourney(item.id)}
                      title="Remove from saved"
                      className="cursor-pointer p-1.5 rounded-lg text-slate-400 hover:text-red-600 hover:bg-red-50 transition-colors"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>

                {/* Corridor & Summary */}
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <div className="flex items-center gap-2 text-base font-black text-slate-900">
                    <span>{item.source}</span>
                    <ArrowRight className="w-4 h-4 text-slate-400" />
                    <span>{item.destination}</span>
                  </div>
                  <span className="text-xs font-bold text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full">
                    {route.summary_line}
                  </span>
                </div>

                {/* Metrics */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 bg-slate-50 p-3 rounded-2xl text-xs">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Estimated Fare</span>
                    <span className="text-base font-black text-emerald-700">₹{route.fare_inr}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Journey Time</span>
                    <span className="text-base font-extrabold text-slate-900">{route.journey_time_min} mins</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Transfers</span>
                    <span className="text-base font-extrabold text-slate-900">
                      {route.changes_count === 0 ? 'Direct (0)' : `${route.changes_count} changes`}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Student Score</span>
                    <span className="text-base font-extrabold text-blue-600 flex items-center gap-1">
                      <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                      <span>{route.route_score}/100</span>
                    </span>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex items-center justify-end gap-2 pt-2">
                  <button
                    onClick={() => onCheckWaitingTime(item.source)}
                    className="cursor-pointer text-xs font-bold px-3.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 transition-colors"
                  >
                    Check Waiting Time
                  </button>

                  <button
                    onClick={() => onPlanJourney(item.source, item.destination)}
                    className="cursor-pointer text-xs font-bold px-3.5 py-2 rounded-xl border border-blue-200 text-blue-600 hover:bg-blue-50 transition-colors"
                  >
                    Re-Plan Corridor
                  </button>

                  <button
                    onClick={() => onViewRouteDetails(route)}
                    className="cursor-pointer text-xs font-bold px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white transition-colors flex items-center gap-1.5 shadow-2xs"
                  >
                    <Eye className="w-3.5 h-3.5" />
                    <span>View Map & Stops</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
