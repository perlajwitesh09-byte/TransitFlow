import React, { useState } from 'react';
import {
  Award,
  X,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  Radio,
  Clock,
  MapPin,
  Sparkles,
  ArrowRight
} from 'lucide-react';
import { NavTab } from './Header';

interface JudgeWalkthroughModalProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigateTab: (tab: NavTab) => void;
  onSetDemoCorridor: (source: string, dest: string) => void;
  onSetStop: (stop: string) => void;
  onToggleLiveFeed: (forceState?: boolean) => void;
  onOpenRouteDetails: () => void;
}

export const JudgeWalkthroughModal: React.FC<JudgeWalkthroughModalProps> = ({
  isOpen,
  onClose,
  onNavigateTab,
  onSetDemoCorridor,
  onSetStop,
  onToggleLiveFeed,
  onOpenRouteDetails,
}) => {
  const [currentStep, setCurrentStep] = useState(1);

  if (!isOpen) return null;

  const steps = [
    {
      step: 1,
      title: 'Step 1: Open Transit Flow',
      description: 'First screen is simple and attractive: Brand slogan “Beyond Routes, Towards Better Journeys.” with clean input fields and immediate feature cards.',
      actionLabel: 'Go to Home Screen',
      action: () => {
        onNavigateTab('home');
      }
    },
    {
      step: 2,
      title: 'Step 2: Enter Source and Destination',
      description: 'Enter starting location (From: Ameerpet) and destination (To: Secunderabad). Select preferred transit mode (🚌 Bus, 🚆 Train, 🚇 Metro, or 🔄 All).',
      actionLabel: 'Fill Ameerpet → Secunderabad',
      action: () => {
        onSetDemoCorridor('Ameerpet', 'Secunderabad');
        onNavigateTab('home');
      }
    },
    {
      step: 3,
      title: 'Step 3: Display Multiple Routes',
      description: 'Display realistic route options: Route 1 (Direct Bus 216D), Route 2 (Bus 218 → Metro Blue Line), and Route 3 (Bus 219 Fewer Changes). Note that Transit Flow avoids declaring one "best" route; commuters compare variables objectively.',
      actionLabel: 'Open Route Comparison',
      action: () => {
        onNavigateTab('plan');
      }
    },
    {
      step: 4,
      title: 'Step 4: Select a Route',
      description: 'Commuters inspect detailed attributes (Duration, Distance, Transfers, Waiting Time, Fare) and click “View Journey”.',
      actionLabel: 'Select Route 1 (Bus 216D)',
      action: () => {
        onNavigateTab('plan');
        onOpenRouteDetails();
      }
    },
    {
      step: 5,
      title: 'Step 5: Show Stops and Journey Time',
      description: 'Display Journey Details modal with origin Ameerpet, destination Secunderabad, total journey 32 min, distance 14.5 km, 0 changes, and complete intermediate stops (Begumpet, Paradise).',
      actionLabel: 'Inspect Stops & Schematic Line',
      action: () => {
        onOpenRouteDetails();
      }
    },
    {
      step: 6,
      title: 'Step 6: Open Waiting Time Estimator',
      description: 'Navigate to the ⭐ Main Feature: The Waiting Time Estimator with Ameerpet Stop selected. Observe the mathematical formula: Waiting Time = Expected Arrival Time − Current Time.',
      actionLabel: 'Open Waiting Time Estimator',
      action: () => {
        onSetStop('Ameerpet');
        onNavigateTab('waiting-time');
      }
    },
    {
      step: 7,
      title: 'Step 7: Show “8 minutes – Scheduled”',
      description: 'Under Bus 216D to Secunderabad, show Expected Arrival 10:25, Waiting: 8 min, with the 🔵 SCHEDULED badge. Timetable information is never falsely claimed as real-time.',
      actionLabel: 'Verify 🔵 Scheduled Provenance',
      action: () => {
        onSetStop('Ameerpet');
        onToggleLiveFeed(false);
        onNavigateTab('waiting-time');
      }
    },
    {
      step: 8,
      title: 'Step 8: Demonstrate Live GPS Badge Transition',
      description: 'When live telemetry is received from the transport operator API, the label dynamically transitions to 🟢 LIVE with real-time GPS tracking and vehicle arrival countdowns.',
      actionLabel: 'Activate 🟢 Live GPS Telemetry',
      action: () => {
        onToggleLiveFeed(true);
        onNavigateTab('waiting-time');
      }
    }
  ];

  const currentStepData = steps[currentStep - 1];

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl max-w-xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col animate-scale-in">
        {/* Header */}
        <div className="p-6 bg-gradient-to-r from-amber-600 via-orange-600 to-amber-700 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-white/20 text-white">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-amber-200 block">
                Official Presentation Mode
              </span>
              <h2 className="text-xl font-black">
                Judge Demonstration Walkthrough
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="cursor-pointer p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Step Progress Bar */}
        <div className="bg-amber-50 px-6 py-3 border-b border-amber-200/60 flex items-center justify-between">
          <div className="flex items-center gap-1.5">
            {steps.map(s => (
              <button
                key={s.step}
                onClick={() => {
                  setCurrentStep(s.step);
                  s.action();
                }}
                className={`cursor-pointer w-7 h-7 rounded-full text-xs font-bold transition-all flex items-center justify-center ${
                  s.step === currentStep
                    ? 'bg-amber-600 text-white ring-2 ring-amber-400 font-extrabold scale-110'
                    : s.step < currentStep
                    ? 'bg-emerald-600 text-white'
                    : 'bg-slate-200 text-slate-600 hover:bg-slate-300'
                }`}
              >
                {s.step < currentStep ? '✓' : s.step}
              </button>
            ))}
          </div>

          <span className="text-xs font-bold text-amber-900">
            Step {currentStep} of 8
          </span>
        </div>

        {/* Step Body */}
        <div className="p-6 sm:p-8 space-y-6">
          <div>
            <span className="text-xs font-bold uppercase tracking-wider text-amber-700 block mb-1">
              Demonstration Stage
            </span>
            <h3 className="text-xl font-black text-slate-900">
              {currentStepData.title}
            </h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              {currentStepData.description}
            </p>
          </div>

          {/* Interactive Trigger for this step */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3">
            <span className="text-xs font-bold text-slate-700">
              Execute live on screen:
            </span>
            <button
              onClick={currentStepData.action}
              className="cursor-pointer w-full sm:w-auto px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-bold transition-colors shadow-xs flex items-center justify-center gap-1.5"
            >
              <span>{currentStepData.actionLabel}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Final One-Line Pitch banner on Step 8 */}
          {currentStep === 8 && (
            <div className="bg-slate-900 text-white p-5 rounded-2xl border border-slate-800 space-y-2">
              <span className="text-[11px] font-bold text-amber-400 uppercase tracking-wider block">
                The One-Line Pitch
              </span>
              <p className="text-sm font-semibold text-slate-200 italic">
                “Transit Flow transforms public transport information into a simple journey decision—where to go, which route to take, and how long to wait.”
              </p>
              <p className="text-[11px] text-slate-400">
                This minimalist approach eliminates decision fatigue for daily commuters.
              </p>
            </div>
          )}
        </div>

        {/* Modal Controls */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={() => {
              if (currentStep > 1) {
                const prev = currentStep - 1;
                setCurrentStep(prev);
                steps[prev - 1].action();
              }
            }}
            disabled={currentStep === 1}
            className="cursor-pointer px-4 py-2 rounded-xl text-xs font-bold border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 disabled:opacity-40 disabled:cursor-not-allowed flex items-center gap-1 transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          {currentStep < 8 ? (
            <button
              onClick={() => {
                const next = currentStep + 1;
                setCurrentStep(next);
                steps[next - 1].action();
              }}
              className="cursor-pointer px-5 py-2.5 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-xs flex items-center gap-1.5 transition-all"
            >
              <span>Next Step ({currentStep + 1}/8)</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={onClose}
              className="cursor-pointer px-5 py-2.5 rounded-xl text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs transition-colors"
            >
              Finish Walkthrough
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
