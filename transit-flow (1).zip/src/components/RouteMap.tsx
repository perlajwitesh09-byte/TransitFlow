import React, { useEffect, useRef } from 'react';
import { RouteOption } from '../types/transit';
import { HYDERABAD_LOCATIONS } from '../data/transitData';
import { NETWORK_NODES, TRANSIT_LOCATIONS } from '../data/networkDatabase';
import L from 'leaflet';
import { MapPin, Navigation, Info } from 'lucide-react';

interface RouteMapProps {
  route: RouteOption;
  source: string;
  destination: string;
}

export const RouteMap: React.FC<RouteMapProps> = ({ route, source, destination }) => {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);

  // Helper to find coords or estimate in Hyderabad range
  const getLocationCoords = (name: string, index: number, total: number): [number, number] => {
    const clean = name.trim().toLowerCase();

    // 1. Check Network Nodes first
    const foundNode = NETWORK_NODES.find(
      n => n.name.toLowerCase() === clean || n.aliases.some(a => a.toLowerCase() === clean) || clean.includes(n.name.toLowerCase())
    );
    if (foundNode) {
      return [foundNode.latitude, foundNode.longitude];
    }

    // 2. Check Transit Locations
    const foundLoc = TRANSIT_LOCATIONS.find(
      l => l.name.toLowerCase() === clean || l.aliases.some(a => a.toLowerCase() === clean) || clean.includes(l.name.toLowerCase())
    );
    if (foundLoc) {
      return [foundLoc.latitude, foundLoc.longitude];
    }

    // 3. Check legacy HYDERABAD_LOCATIONS
    const found = HYDERABAD_LOCATIONS.find(
      l => l.name.toLowerCase() === clean ||
           l.aliases?.some(a => a.toLowerCase() === clean) ||
           clean.includes(l.name.toLowerCase())
    );
    if (found) {
      return [found.latitude, found.longitude];
    }

    // Interpolate between Ameerpet (17.4375, 78.4482) and Secunderabad (17.4399, 78.4983)
    const factor = total > 1 ? index / (total - 1) : 0.5;
    const baseLat = 17.44 + (Math.sin(factor * Math.PI) * 0.03);
    const baseLng = 78.42 + factor * 0.12;
    return [baseLat, baseLng];
  };

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Destroy prior map instance if exists
    if (mapInstanceRef.current) {
      mapInstanceRef.current.remove();
      mapInstanceRef.current = null;
    }

    // Determine stops list
    const stopsToRender = route.all_stops && route.all_stops.length > 0
      ? route.all_stops
      : [source, 'Intermediate Point', destination];

    const coordinates: [number, number][] = stopsToRender.map((stop, idx) =>
      getLocationCoords(stop, idx, stopsToRender.length)
    );

    // Initial center on Hyderabad
    const center = coordinates[0] || [17.4375, 78.4482];
    const map = L.map(mapContainerRef.current, {
      center,
      zoom: 12,
      zoomControl: true,
      attributionControl: true,
    });

    mapInstanceRef.current = map;

    // OpenStreetMap Tile Layer (Free, public, no private API key needed)
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    }).addTo(map);

    // Custom DivIcon creator
    const createCustomIcon = (label: string, colorClass: string, isTerminal: boolean) => {
      return L.divIcon({
        className: 'custom-leaflet-marker',
        html: `
          <div style="
            background-color: ${colorClass};
            color: white;
            padding: ${isTerminal ? '4px 8px' : '2px 6px'};
            border-radius: ${isTerminal ? '12px' : '8px'};
            font-size: ${isTerminal ? '11px' : '9px'};
            font-weight: 700;
            white-space: nowrap;
            box-shadow: 0 2px 6px rgba(0,0,0,0.3);
            border: 2px solid white;
            display: flex;
            align-items: center;
            gap: 4px;
            transform: translate(-50%, -50%);
          ">
            <span>${label}</span>
          </div>
        `,
        iconSize: [20, 20],
        iconAnchor: [10, 10],
      });
    };

    // Add markers
    coordinates.forEach((coord, idx) => {
      const stopName = stopsToRender[idx];
      const isStart = idx === 0;
      const isEnd = idx === coordinates.length - 1;
      const isTransfer = idx > 0 && idx < coordinates.length - 1 && (stopName.includes('Metro') || stopName.includes('Concourse') || stopName.includes('Transfer'));

      let color = '#2563eb'; // blue
      let badgeLabel = `● ${stopName}`;

      if (isStart) {
        color = '#16a34a'; // green
        badgeLabel = `🟢 From: ${stopName}`;
      } else if (isEnd) {
        color = '#dc2626'; // red
        badgeLabel = `🔴 To: ${stopName}`;
      } else if (isTransfer) {
        color = '#d97706'; // amber transfer
        badgeLabel = `🔄 Change: ${stopName}`;
      }

      const marker = L.marker(coord, {
        icon: createCustomIcon(badgeLabel, color, isStart || isEnd || isTransfer),
      }).addTo(map);

      marker.bindPopup(`
        <div style="font-family: sans-serif; font-size: 12px; padding: 4px;">
          <strong style="color: #0f172a; display: block; margin-bottom: 2px;">${stopName}</strong>
          <span style="color: #64748b;">${isStart ? 'Origin Point' : isEnd ? 'Destination Terminus' : isTransfer ? 'Transfer Interchange Point' : 'Intermediate Scheduled Stop'}</span>
          <br/>
          <span style="color: #2563eb; font-weight: 600;">Stop #${idx + 1} of ${stopsToRender.length}</span>
        </div>
      `);
    });

    // Draw connecting route polyline
    const polyline = L.polyline(coordinates, {
      color: '#2563eb',
      weight: 4,
      opacity: 0.85,
      dashArray: route.summary_line.includes('Walk') ? '6, 8' : undefined,
    }).addTo(map);

    // Fit map bounds to encompass all points comfortably
    const bounds = L.latLngBounds(coordinates);
    map.fitBounds(bounds, { padding: [40, 40] });

    // Handle container resize
    setTimeout(() => {
      map.invalidateSize();
    }, 200);

    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, [route, source, destination]);

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-xs text-slate-500">
        <div className="flex items-center gap-2">
          <Navigation className="w-3.5 h-3.5 text-blue-600" />
          <span className="font-semibold text-slate-700">Interactive OpenStreetMap Route View</span>
        </div>
        <div className="flex items-center gap-3 text-[11px]">
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-600"></span> Start
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-amber-500"></span> Transfer
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-red-600"></span> Destination
          </span>
        </div>
      </div>

      <div
        ref={mapContainerRef}
        className="w-full h-72 sm:h-80 rounded-2xl border border-slate-300 overflow-hidden shadow-inner z-0"
        style={{ minHeight: '280px' }}
      />

      <div className="flex items-center justify-between text-[11px] text-slate-400 px-1 pt-1">
        <span className="flex items-center gap-1">
          <Info className="w-3 h-3 text-slate-400" />
          Zoom and pan freely. Click on any stop node to inspect stop sequencing and transfer alerts.
        </span>
        <span className="font-mono text-[10px]">OpenStreetMap + Leaflet Engine</span>
      </div>
    </div>
  );
};
