import React, { useState, useRef, useEffect } from 'react';
import { TransportType, HyderabadLocation, PriorityMode, SavedJourney, RecentJourneyPlan } from '../types/transit';
import { HYDERABAD_LOCATIONS, POPULAR_HYDERABAD_JOURNEYS } from '../data/transitData';
import { NavTab } from './Header';
import { MonthlyBudgetTracker } from './MonthlyBudgetTracker';
import {
  Search,
  ArrowRightLeft,
  Bus,
  Train,
  Milestone,
  Clock,
  MapPin,
  GraduationCap,
  Sparkles,
  ArrowRight,
  ShieldCheck,
  Zap,
  SlidersHorizontal,
  Compass,
  Building,
  Info
} from 'lucide-react';
import { DataSourceBadge } from './DataSourceBadge';

interface HomePageProps {
  fromLocation: string;
  toLocation: string;
  transportType: TransportType;
  priorityMode: PriorityMode;
  onFromChange: (val: string) => void;
  onToChange: (val: string) => void;
  onTransportChange: (val: TransportType) => void;
  onPriorityChange: (val: PriorityMode) => void;
  onSubmitPlan: () => void;
  onNavigateToTab: (tab: NavTab) => void;
  onSelectPredefinedCorridor: (from: string, to: string) => void;
  isLiveActive: boolean;
  savedJourneys: SavedJourney[];
  recentPlans: RecentJourneyPlan[];
  onAddSampleJourneys?: () => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  fromLocation,
  toLocation,
  transportType,
  priorityMode,
  onFromChange,
  onToChange,
  onTransportChange,
  onPriorityChange,
  onSubmitPlan,
  onNavigateToTab,
  onSelectPredefinedCorridor,
  isLiveActive,
  savedJourneys,
  recentPlans,
  onAddSampleJourneys,
}) => {
  // Autocomplete suggestions
  const [fromSuggestions, setFromSuggestions] = useState<HyderabadLocation[]>([]);
  const [toSuggestions, setToSuggestions] = useState<HyderabadLocation[]>([]);
  const [showFromDropdown, setShowFromDropdown] = useState(false);
  const [showToDropdown, setShowToDropdown] = useState(false);
  const [exploreFilter, setExploreFilter] = useState<'all' | 'bus' | 'metro' | 'train' | 'college' | 'popular'>('all');

  const fromRef = useRef<HTMLDivElement>(null);
  const toRef = useRef<HTMLDivElement>(null);

  // Close dropdowns on outside click
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (fromRef.current && !fromRef.current.contains(event.target as Node)) {
        setShowFromDropdown(false);
      }
      if (toRef.current && !toRef.current.contains(event.target as Node)) {
        setShowToDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Smart search filter: matches by name, zone, nearbyTransport, or nearby area keywords
  const filterLocations = (val: string): HyderabadLocation[] => {
    if (!val.trim()) {
      return HYDERABAD_LOCATIONS.slice(0, 8);
    }
    const q = val.toLowerCase().trim();

    // Contextual proximity: e.g. if user types "AS Rao Nagar", also suggest ECIL, Sainikpuri, Kapra!
    const contextBonusIds: string[] = [];
    if (q.includes('as rao') || q.includes('ecil') || q.includes('sainikpuri') || q.includes('kapra')) {
      contextBonusIds.push('loc-n7', 'loc-n8', 'loc-n9', 'loc-n10');
    } else if (q.includes('kukatpally') || q.includes('jntu') || q.includes('kphb')) {
      contextBonusIds.push('loc-w1', 'loc-w2', 'loc-w3', 'col-1');
    } else if (q.includes('gachibowli') || q.includes('hitec') || q.includes('raidurg')) {
      contextBonusIds.push('loc-w9', 'loc-w15', 'loc-w17', 'col-3', 'col-6');
    }

    const directMatches = HYDERABAD_LOCATIONS.filter(loc =>
      loc.name.toLowerCase().includes(q) ||
      loc.zone.toLowerCase().includes(q) ||
      (loc.nearbyTransport && loc.nearbyTransport.toLowerCase().includes(q))
    );

    const bonusMatches = HYDERABAD_LOCATIONS.filter(loc =>
      contextBonusIds.includes(loc.id) && !directMatches.some(dm => dm.id === loc.id)
    );

    return [...directMatches, ...bonusMatches].slice(0, 7);
  };

  const handleFromInput = (val: string) => {
    onFromChange(val);
    setFromSuggestions(filterLocations(val));
    setShowFromDropdown(true);
  };

  const handleToInput = (val: string) => {
    onToChange(val);
    setToSuggestions(filterLocations(val));
    setShowToDropdown(true);
  };

  const swapLocations = () => {
    const temp = fromLocation;
    onFromChange(toLocation);
    onToChange(temp);
  };

  // Helper for location type badge
  const renderTypeIcon = (type: HyderabadLocation['type']) => {
    switch (type) {
      case 'college':
        return <GraduationCap className="w-3.5 h-3.5 text-purple-600" />;
      case 'metro':
        return <Milestone className="w-3.5 h-3.5 text-blue-600" />;
      case 'railway':
        return <Train className="w-3.5 h-3.5 text-amber-600" />;
      case 'bus_hub':
        return <Bus className="w-3.5 h-3.5 text-emerald-600" />;
      default:
        return <MapPin className="w-3.5 h-3.5 text-slate-500" />;
    }
  };

  // Filtered Explore list
  const exploreList = HYDERABAD_LOCATIONS.filter(loc => {
    if (exploreFilter === 'all') return true;
    if (exploreFilter === 'college') return loc.type === 'college';
    if (exploreFilter === 'metro') return loc.type === 'metro';
    if (exploreFilter === 'train') return loc.type === 'railway';
    if (exploreFilter === 'bus') return loc.type === 'bus_hub';
    if (exploreFilter === 'popular') return loc.zone === 'West' || loc.zone === 'Central';
    return true;
  }).slice(0, 10);

  return (
    <div className="space-y-10 pb-16">
      {/* Accuracy & Demo Notice Banner as specified in prompt */}
      <div className="bg-amber-50 border-b border-amber-200/80 px-4 py-2.5 text-xs text-amber-900 flex items-center justify-center gap-2">
        <Info className="w-4 h-4 text-amber-600 shrink-0" />
        <span className="font-semibold text-center">
          “Transport timings and fares are estimates and may change. Transit Flow demo transport data mode is active.”
        </span>
      </div>

      {/* Main Search Hero Section */}
      <section className="max-w-4xl mx-auto px-4 pt-4 sm:pt-8">
        <div className="bg-white rounded-3xl p-6 sm:p-10 shadow-sm border border-slate-200/80 relative overflow-hidden">
          {/* Subtle decorative background tint */}
          <div className="absolute -top-24 -right-24 w-72 h-72 bg-blue-50/70 rounded-full blur-3xl pointer-events-none" />

          {/* Heading strictly as specified */}
          <div className="text-center max-w-2xl mx-auto space-y-2 mb-8">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200">
              <GraduationCap className="w-3.5 h-3.5" />
              <span>Transit Flow • Hyderabad Edition</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
              Plan Your Hyderabad Journey 🎓
            </h1>
            <p className="text-sm sm:text-base text-slate-600 font-medium">
              Affordable routes. Fewer changes. Smarter journeys.
            </p>
          </div>

          {/* Origin & Destination Inputs with Autocomplete */}
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-[1fr_auto_1fr] gap-3 items-center">
              {/* FROM field */}
              <div ref={fromRef} className="relative">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center justify-between">
                  <span>From (Origin):</span>
                  <span className="text-[10px] font-normal text-slate-400">Area, Metro, College</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <MapPin className="w-4 h-4 text-emerald-600" />
                  </div>
                  <input
                    type="text"
                    value={fromLocation}
                    onChange={(e) => handleFromInput(e.target.value)}
                    onFocus={() => {
                      setFromSuggestions(filterLocations(fromLocation));
                      setShowFromDropdown(true);
                    }}
                    placeholder="Enter starting location or college (e.g. AS Rao Nagar)..."
                    className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border border-slate-300 rounded-2xl text-sm font-semibold text-slate-900 placeholder-slate-400 focus:bg-white focus:border-blue-600 focus:ring-3 focus:ring-blue-100 transition-all outline-none"
                  />
                </div>

                {/* Suggestions Dropdown */}
                {showFromDropdown && fromSuggestions.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1.5 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 overflow-hidden py-1 max-h-64 overflow-y-auto">
                    <div className="px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                      Hyderabad Locations & Hubs
                    </div>
                    {fromSuggestions.map(loc => (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => {
                          onFromChange(loc.name);
                          setShowFromDropdown(false);
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-xs font-medium hover:bg-slate-50 transition-colors flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-2">
                          <span className="p-1 rounded-md bg-slate-100 group-hover:bg-blue-50">
                            {renderTypeIcon(loc.type)}
                          </span>
                          <div>
                            <span className="font-bold text-slate-800 group-hover:text-blue-600 block">
                              {loc.name}
                            </span>
                            <span className="text-[11px] text-slate-400 block truncate max-w-xs">
                              {loc.nearbyTransport || `${loc.zone} Hyderabad`}
                            </span>
                          </div>
                        </div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-100">
                          {loc.type.replace('_', ' ')}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>

              {/* Swap Button */}
              <div className="flex justify-center md:pt-6">
                <button
                  type="button"
                  onClick={swapLocations}
                  title="Swap Starting Location and Destination"
                  className="cursor-pointer p-3 rounded-2xl bg-slate-100 hover:bg-blue-50 hover:text-blue-600 text-slate-600 transition-all shadow-2xs hover:scale-105"
                >
                  <ArrowRightLeft className="w-4 h-4" />
                </button>
              </div>

              {/* TO field */}
              <div ref={toRef} className="relative">
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-1.5 flex items-center justify-between">
                  <span>To (Destination):</span>
                  <span className="text-[10px] font-normal text-slate-400">Hub, Office, College</span>
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none">
                    <MapPin className="w-4 h-4 text-red-600" />
                  </div>
                  <input
                    type="text"
                    value={toLocation}
                    onChange={(e) => handleToInput(e.target.value)}
                    onFocus={() => {
                      setToSuggestions(filterLocations(toLocation));
                      setShowToDropdown(true);
                    }}
                    placeholder="Enter destination (e.g. Gachibowli or JNTUH)..."
                    className="w-full pl-10 pr-4 py-3.5 bg-slate-50 border border-slate-300 rounded-2xl text-sm font-semibold text-slate-900 placeholder-slate-400 focus:bg-white focus:border-blue-600 focus:ring-3 focus:ring-blue-100 transition-all outline-none"
                  />
                </div>

                {/* Suggestions Dropdown */}
                {showToDropdown && toSuggestions.length > 0 && (
                  <div className="absolute left-0 right-0 top-full mt-1.5 bg-white rounded-2xl shadow-xl border border-slate-200 z-50 overflow-hidden py-1 max-h-64 overflow-y-auto">
                    <div className="px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                      Hyderabad Locations & Hubs
                    </div>
                    {toSuggestions.map(loc => (
                      <button
                        key={loc.id}
                        type="button"
                        onClick={() => {
                          onToChange(loc.name);
                          setShowToDropdown(false);
                        }}
                        className="w-full px-3.5 py-2.5 text-left text-xs font-medium hover:bg-slate-50 transition-colors flex items-center justify-between group"
                      >
                        <div className="flex items-center gap-2">
                          <span className="p-1 rounded-md bg-slate-100 group-hover:bg-blue-50">
                            {renderTypeIcon(loc.type)}
                          </span>
                          <div>
                            <span className="font-bold text-slate-800 group-hover:text-blue-600 block">
                              {loc.name}
                            </span>
                            <span className="text-[11px] text-slate-400 block truncate max-w-xs">
                              {loc.nearbyTransport || `${loc.zone} Hyderabad`}
                            </span>
                          </div>
                        </div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 px-2 py-0.5 rounded bg-slate-100">
                          {loc.type.replace('_', ' ')}
                        </span>
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>

            {/* Transport Mode & Student Priority Toggles */}
            <div className="pt-2 grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <span className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Transport Preference:
                </span>
                <div className="grid grid-cols-4 gap-2">
                  <button
                    type="button"
                    onClick={() => onTransportChange('bus')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                      transportType === 'bus'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Bus className="w-3.5 h-3.5" />
                    <span>🚌 Bus</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onTransportChange('metro')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                      transportType === 'metro'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Milestone className="w-3.5 h-3.5" />
                    <span>🚇 Metro</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onTransportChange('train')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                      transportType === 'train'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <Train className="w-3.5 h-3.5" />
                    <span>🚆 Train</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => onTransportChange('all')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all ${
                      transportType === 'all'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    <span>🔄 All</span>
                  </button>
                </div>
              </div>

              <div>
                <span className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-2">
                  Student Priority Weight:
                </span>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    type="button"
                    onClick={() => onPriorityChange('budget')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                      priorityMode === 'budget'
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    💰 Budget
                  </button>

                  <button
                    type="button"
                    onClick={() => onPriorityChange('time')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                      priorityMode === 'time'
                        ? 'bg-blue-600 text-white border-blue-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    ⚡ Fastest
                  </button>

                  <button
                    type="button"
                    onClick={() => onPriorityChange('balanced')}
                    className={`cursor-pointer py-2.5 px-2 rounded-xl text-xs font-bold border transition-all ${
                      priorityMode === 'balanced'
                        ? 'bg-indigo-600 text-white border-indigo-600 shadow-2xs'
                        : 'bg-slate-50 text-slate-700 border-slate-200 hover:bg-slate-100'
                    }`}
                  >
                    ⚖️ Balanced
                  </button>
                </div>
              </div>
            </div>

            {/* Main Action Button */}
            <div className="pt-3">
              <button
                type="button"
                onClick={onSubmitPlan}
                className="cursor-pointer w-full py-4 px-6 rounded-2xl bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white font-black text-base shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 tracking-wide"
              >
                <Search className="w-5 h-5" />
                <span>🔎 Find Journey (Plan My Journey)</span>
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* MONTHLY TRAVEL BUDGET & PROJECTED SPENDING TRACKER */}
      <MonthlyBudgetTracker
        savedJourneys={savedJourneys}
        recentPlans={recentPlans}
        onNavigateToTab={onNavigateToTab}
        onPlanCorridor={(src, dest) => {
          onFromChange(src);
          onToChange(dest);
          onNavigateToTab('plan');
        }}
        onAddSampleJourneys={onAddSampleJourneys}
      />

      {/* POPULAR HYDERABAD JOURNEYS SECTION */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-blue-600 bg-blue-50 px-2.5 py-0.5 rounded-full">
                Quick Route Demo
              </span>
              <h2 className="text-lg sm:text-xl font-black text-slate-900 mt-1">
                Popular Hyderabad Commute Corridors
              </h2>
            </div>
            <span className="text-xs text-slate-400 hidden sm:inline">
              1-click to test route options
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2.5">
            {POPULAR_HYDERABAD_JOURNEYS.map((j, idx) => (
              <button
                key={idx}
                onClick={() => onSelectPredefinedCorridor(j.from, j.to)}
                className="cursor-pointer p-3 rounded-2xl bg-slate-50 hover:bg-blue-50 hover:border-blue-300 border border-slate-200 text-left transition-all group flex items-center justify-between"
              >
                <div>
                  <div className="text-xs font-bold text-slate-800 group-hover:text-blue-700 flex items-center gap-1.5">
                    <span>{j.from}</span>
                    <ArrowRight className="w-3 h-3 text-slate-400 group-hover:text-blue-600" />
                    <span>{j.to}</span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">{j.badge}</span>
                </div>
              </button>
            ))}
          </div>
        </div>
      </section>

      {/* EXPLORE HYDERABAD SECTION */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h2 className="text-xl font-black text-slate-900">
                Explore Hyderabad
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Quickly discover transit connectivity across colleges, metro stations, and hubs.
              </p>
            </div>

            {/* Sub filters */}
            <div className="flex flex-wrap gap-1.5">
              {[
                { id: 'all', label: 'All' },
                { id: 'college', label: '🎓 Colleges' },
                { id: 'metro', label: '🚇 Metro' },
                { id: 'bus', label: '🚌 Bus' },
                { id: 'train', label: '🚆 Train' },
                { id: 'popular', label: '📍 Popular Areas' },
              ].map(f => (
                <button
                  key={f.id}
                  onClick={() => setExploreFilter(f.id as any)}
                  className={`cursor-pointer px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                    exploreFilter === f.id
                      ? 'bg-slate-900 text-white'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {f.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {exploreList.map(loc => (
              <div
                key={loc.id}
                className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 flex items-start justify-between gap-2"
              >
                <div className="flex items-start gap-2.5">
                  <span className="p-2 rounded-xl bg-white shadow-2xs mt-0.5">
                    {renderTypeIcon(loc.type)}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">{loc.name}</h4>
                    <span className="text-[11px] text-slate-500 block">
                      {loc.nearbyTransport || `${loc.zone} Zone`}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-1">
                  <button
                    onClick={() => {
                      onFromChange(loc.name);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="cursor-pointer text-[10px] font-bold px-2 py-1 rounded bg-white hover:bg-blue-50 text-blue-700 border border-slate-200"
                  >
                    Set From
                  </button>
                  <button
                    onClick={() => {
                      onToChange(loc.name);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="cursor-pointer text-[10px] font-bold px-2 py-1 rounded bg-white hover:bg-red-50 text-red-700 border border-slate-200"
                  >
                    Set To
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* THREE CORE VALUE PILLARS (Preserved from original design) */}
      <section className="max-w-4xl mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card 1 */}
          <div
            onClick={() => onNavigateToTab('plan')}
            className="cursor-pointer bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Bus className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                🚌 Smart Routes
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                Find suitable public transport routes connecting colleges, railway hubs, and residential corridors across Hyderabad.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1 text-xs font-bold text-blue-600 group-hover:translate-x-1 transition-transform">
              <span>Compare Options</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 2 */}
          <div
            onClick={() => onNavigateToTab('waiting-time')}
            className="cursor-pointer bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <Clock className="w-6 h-6" />
              </div>
              <div className="flex items-center gap-2 mb-2">
                <h3 className="text-lg font-bold text-slate-900">
                  ⏱️ Waiting Time
                </h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  Core
                </span>
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                Know the estimated time until your next service. Transparently separates 🟢 LIVE telematics from 🔵 SCHEDULED timetables.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1 text-xs font-bold text-emerald-600 group-hover:translate-x-1 transition-transform">
              <span>Check Live Board</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>

          {/* Card 3 */}
          <div
            onClick={() => onNavigateToTab('routes')}
            className="cursor-pointer bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all group flex flex-col justify-between"
          >
            <div>
              <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                <MapPin className="w-6 h-6" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">
                📍 Journey Details
              </h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                View stops, distance, duration, and physical changes with interactive OpenStreetMap route paths.
              </p>
            </div>
            <div className="mt-6 flex items-center gap-1 text-xs font-bold text-purple-600 group-hover:translate-x-1 transition-transform">
              <span>View Route Lines</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
