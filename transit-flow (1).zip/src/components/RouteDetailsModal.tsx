import React, { useState } from 'react';
import { RouteOption, RouteTimetable, TripRecord } from '../types/transit';
import { DataSourceBadge } from './DataSourceBadge';
import { RouteMap } from './RouteMap';
import { tripDatabase } from '../data/tripDatabase';
import {
  X,
  Clock,
  MapPin,
  Bus,
  Train,
  Milestone,
  ArrowRight,
  ShieldCheck,
  Radio,
  Footprints,
  IndianRupee,
  Share2,
  CheckCircle2,
  Map as MapIcon,
  ListOrdered,
  Bookmark,
  BookmarkCheck,
  CreditCard,
  Calendar,
  Sparkles,
  Info
} from 'lucide-react';

interface RouteDetailsModalProps {
  route: RouteOption | null;
  onClose: () => void;
  onCheckWaitingTime: (stopName: string) => void;
  onSaveJourney?: (route: RouteOption) => void;
  isSaved?: boolean;
}

export const RouteDetailsModal: React.FC<RouteDetailsModalProps> = ({
  route,
  onClose,
  onCheckWaitingTime,
  onSaveJourney,
  isSaved = false,
}) => {
  const [viewTab, setViewTab] = useState<'map' | 'stops' | 'timetable'>('map');
  const [savedLocally, setSavedLocally] = useState(isSaved);
  const [copyNotification, setCopyNotification] = useState(false);

  if (!route) return null;

  const originStop = route.all_stops[0] || 'Origin';
  const destinationStop = route.all_stops[route.all_stops.length - 1] || 'Destination';

  // Find corresponding route timetable from TripDatabase
  const routeTimetable = route.timetable_link_route_id
    ? tripDatabase.getRouteTimetable(route.timetable_link_route_id)
    : tripDatabase.getAllRoutesTimetables().find((rt: RouteTimetable) => 
        route.route_number && (rt.route_id.includes(route.route_number.toLowerCase()) || (rt.route_name && rt.route_name.includes(route.route_number)))
      );

  const handleSave = () => {
    if (onSaveJourney) {
      onSaveJourney(route);
    }
    setSavedLocally(!savedLocally);
  };

  const handleShare = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(
        `Transit Flow Hyderabad: ${route.summary_line} from ${originStop} to ${destinationStop}. Total Time: ${route.journey_time_min} mins, Fare: ₹${route.fare_inr}.`
      );
      setCopyNotification(true);
      setTimeout(() => setCopyNotification(false), 2500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 sm:p-6 animate-fade-in">
      <div className="bg-white rounded-3xl max-w-2xl w-full shadow-2xl border border-slate-200 overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="p-6 bg-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-blue-600 text-white">
              <Bus className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-blue-400">
                🚌 Journey Details
              </span>
              <h2 className="text-xl font-black text-white">
                {route.route_label}
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSave}
              title="Save to My Journeys"
              className={`cursor-pointer p-2 rounded-xl border transition-colors ${
                savedLocally
                  ? 'bg-amber-500/20 text-amber-400 border-amber-500/40'
                  : 'bg-slate-800 text-slate-300 border-slate-700 hover:text-white'
              }`}
            >
              {savedLocally ? <BookmarkCheck className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
            </button>

            <button
              onClick={handleShare}
              title="Copy Summary"
              className="cursor-pointer p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            >
              <Share2 className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="cursor-pointer p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition-colors ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* View Mode Toggle: Interactive Map vs Stops List vs Full Route Timetable */}
        <div className="bg-slate-100 px-6 py-2 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setViewTab('map')}
              className={`cursor-pointer px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewTab === 'map'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <MapIcon className="w-3.5 h-3.5 text-blue-600" />
              <span>Map View</span>
            </button>

            <button
              onClick={() => setViewTab('stops')}
              className={`cursor-pointer px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewTab === 'stops'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <ListOrdered className="w-3.5 h-3.5 text-emerald-600" />
              <span>Stops & Stop Timings</span>
            </button>

            <button
              onClick={() => setViewTab('timetable')}
              className={`cursor-pointer px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-1.5 transition-all ${
                viewTab === 'timetable'
                  ? 'bg-white text-slate-900 shadow-2xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Clock className="w-3.5 h-3.5 text-indigo-600" />
              <span>Full Route Timetable</span>
              {routeTimetable && (
                <span className="ml-1 px-1.5 py-0.2 bg-indigo-100 text-indigo-800 rounded-full text-[10px]">
                  {routeTimetable.trips.length} trips
                </span>
              )}
            </button>
          </div>

          <span className="text-[11px] font-bold text-slate-500">
            Score: <strong className="text-blue-600">{route.route_score}/100</strong>
          </span>
        </div>

        {copyNotification && (
          <div className="bg-emerald-50 text-emerald-800 text-xs font-bold px-4 py-2 border-b border-emerald-200 flex items-center justify-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Journey summary copied to clipboard!</span>
          </div>
        )}

        {/* Scrollable Body */}
        <div className="p-6 sm:p-8 overflow-y-auto space-y-6">
          {/* TGSRTC Verified Service Banner */}
          {route.operator === 'TGSRTC' && (
            <div className="bg-blue-50 border border-blue-200 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-black bg-blue-600 text-white">
                    TGSRTC {route.route_number}
                  </span>
                  {route.bus_type && (
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-white text-blue-900 border border-blue-300">
                      {route.bus_type}
                    </span>
                  )}
                  {route.is_airport_pushpak && (
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-500 text-white">
                      Airport Pushpak AC
                    </span>
                  )}
                </div>
                <div className="text-xs text-slate-600 mt-1">
                  Service ID: <strong>{route.service_number || 'TGSRTC-SCHEDULED'}</strong> • Direction: <strong>{route.direction || `${originStop} → ${destinationStop}`}</strong>
                </div>
              </div>

              <div className="text-right sm:text-right">
                <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-300">
                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-700" />
                  <span>{route.data_source_label || 'TGSRTC Verified transport information'}</span>
                </span>
                {route.last_verified && (
                  <span className="block text-[10px] text-slate-500 mt-0.5">
                    Last verified: {route.last_verified}
                  </span>
                )}
              </div>
            </div>
          )}

          {/* Journey Overview Bar */}
          <div className="bg-slate-50 rounded-2xl p-5 border border-slate-200">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-3 border-b border-slate-200 gap-2">
              <div className="text-sm font-bold text-slate-800">
                <span>From: <strong className="text-blue-700">{originStop}</strong></span>
                <span className="mx-2 text-slate-400">→</span>
                <span>To: <strong className="text-red-700">{destinationStop}</strong></span>
              </div>
              <div className="flex items-center gap-2">
                <DataSourceBadge type={route.data_source} />
                {route.operating_days && (
                  <span className="text-[11px] font-bold text-slate-500 bg-white px-2 py-0.5 rounded border border-slate-200">
                    Runs: {route.operating_days.join(', ')}
                  </span>
                )}
              </div>
            </div>

            {/* Late Night Rollover Banner if applicable */}
            {(route.next_day_arrival || route.arrival_destination_time?.includes('+1')) && (
              <div className="mt-3 p-2.5 bg-indigo-50 border border-indigo-200 rounded-xl text-xs text-indigo-900 flex items-center gap-2 font-bold">
                <span>🌙</span>
                <span>Overnight Journey Notice: This service completes after midnight on the following day (+1 day).</span>
              </div>
            )}

            <div className="grid grid-cols-2 sm:grid-cols-6 gap-3 pt-3 text-center text-xs">
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Departure</span>
                <span className="text-base font-extrabold text-blue-700">{route.departure_time}</span>
                {route.departure_datetime && (
                  <span className="text-[9px] text-slate-400 block font-mono">{route.departure_datetime}</span>
                )}
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Arrival</span>
                <span className="text-base font-extrabold text-emerald-700">
                  {route.arrival_destination_time}
                </span>
                {route.arrival_datetime && (
                  <span className="text-[9px] text-slate-400 block font-mono">{route.arrival_datetime}</span>
                )}
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Total Duration</span>
                <span className="text-base font-extrabold text-slate-900">
                  {route.duration_text || `${route.journey_time_min} min`}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Distance</span>
                <span className="text-base font-extrabold text-slate-900">{route.distance_km} km</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Transfers</span>
                <span className="text-base font-extrabold text-slate-900">
                  {route.changes_count === 0 ? 'Direct (0)' : `${route.changes_count} changes`}
                </span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px] uppercase font-bold">Verified Fare</span>
                <span className="text-base font-extrabold text-emerald-700">
                  {route.fare_formatted || `₹${route.fare_inr}`}
                </span>
              </div>
            </div>

            {/* Via Highlights if available */}
            {route.via_highlights && route.via_highlights.length > 0 && (
              <div className="mt-3 pt-3 border-t border-slate-200 text-xs flex items-center gap-2 flex-wrap">
                <span className="font-bold text-slate-600">Via Highlights:</span>
                <div className="flex items-center gap-1.5 flex-wrap">
                  {route.via_highlights.map((vh, vIdx) => (
                    <span
                      key={vIdx}
                      className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-[11px] font-semibold text-slate-700"
                    >
                      {vh}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Individual Bus Trip & Vehicle Badge Bar */}
            <div className="mt-3 pt-3 border-t border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs">
              <div className="flex items-center gap-2 flex-wrap">
                {route.bus_id && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-blue-100/70 text-blue-900 border border-blue-200 font-mono font-bold text-[11px]">
                    <Bus className="w-3.5 h-3.5 text-blue-700" />
                    <span>Bus: {route.bus_id}</span>
                  </span>
                )}
                {route.trip_id && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-100 text-slate-800 border border-slate-200 font-mono text-[11px]">
                    <span>Trip ID: {route.trip_id}</span>
                  </span>
                )}
                {route.interval_from_prev_mins !== undefined && (
                  <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200 text-[11px] font-bold">
                    <Clock className="w-3 h-3 text-emerald-600" />
                    <span>Interval: +{route.interval_from_prev_mins}m from previous trip</span>
                  </span>
                )}
              </div>

              <span className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                route.fare_verified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-900'
              }`}>
                {route.data_source_label || 'TGSRTC Service'}
              </span>
            </div>
          </div>

          {/* VIEW TAB 1: INTERACTIVE MAP */}
          {viewTab === 'map' && (
            <div className="space-y-4">
              <RouteMap
                route={route}
                source={originStop}
                destination={destinationStop}
              />
            </div>
          )}

          {/* VIEW TAB 2: STOPS & STOP TIMINGS */}
          {viewTab === 'stops' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-extrabold uppercase tracking-wider text-slate-900 flex items-center gap-2">
                  <MapPin className="w-4 h-4 text-blue-600" />
                  <span>
                    {route.stop_by_stop_timings && route.stop_by_stop_timings.length > 0
                      ? `Stop-by-Stop Scheduled Timings (${route.bus_id || 'Vehicle Schedule'})`
                      : route.stage_timings && route.stage_timings.length > 0
                      ? 'Stage-Wise Stop Schedule & Timings'
                      : 'Stop-by-Stop Transit Line'}
                  </span>
                </h3>
                {route.stop_by_stop_timings && route.stop_by_stop_timings.length > 0 ? (
                  <span className="text-[11px] font-bold text-indigo-700 bg-indigo-50 px-2.5 py-1 rounded-full border border-indigo-200">
                    Individual Bus Timings (24H)
                  </span>
                ) : route.stage_timings && route.stage_timings.length > 0 ? (
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                    Official Stage Timings Verified
                  </span>
                ) : null}
              </div>

              {/* RENDER STOP-BY-STOP TIMINGS FROM TRIP RECORD */}
              {route.stop_by_stop_timings && route.stop_by_stop_timings.length > 0 ? (
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-2.5 font-mono text-xs">
                  <div className="text-[11px] text-slate-500 font-sans mb-2 flex items-center justify-between">
                    <span>Specific scheduled departure and arrival time at each intermediate stop for this trip:</span>
                    <span className="font-bold text-blue-700">{route.departure_time} → {route.arrival_destination_time}</span>
                  </div>
                  {route.stop_by_stop_timings.map((st, idx) => {
                    const isFirst = idx === 0;
                    const isLast = idx === route.stop_by_stop_timings!.length - 1;
                    return (
                      <div
                        key={idx}
                        className={`rounded-xl p-3 border space-y-1 shadow-2xs transition-all ${
                          isFirst
                            ? 'bg-blue-50/70 border-blue-200'
                            : isLast
                            ? 'bg-emerald-50/70 border-emerald-200'
                            : 'bg-white border-slate-200'
                        }`}
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <span className={`h-5 w-5 rounded-full flex items-center justify-center text-[10px] font-bold ${
                              isFirst ? 'bg-blue-600 text-white' : isLast ? 'bg-emerald-600 text-white' : 'bg-slate-200 text-slate-700'
                            }`}>
                              {idx + 1}
                            </span>
                            <span className="font-bold text-slate-900 text-sm font-sans">{st.stop_name}</span>
                          </div>

                          <div className="flex items-center gap-2">
                            {st.distance_from_origin_km !== undefined && st.distance_from_origin_km > 0 && (
                              <span className="text-[10px] text-slate-400 font-mono">
                                {st.distance_from_origin_km} km
                              </span>
                            )}
                            <span className={`px-2.5 py-1 rounded-md font-extrabold text-xs ${
                              isFirst
                                ? 'bg-blue-600 text-white'
                                : isLast
                                ? 'bg-emerald-600 text-white'
                                : 'bg-slate-100 text-slate-800'
                            }`}>
                              {isFirst ? st.departure_time : isLast ? st.arrival_time : st.departure_time || st.arrival_time}
                            </span>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : route.stage_timings && route.stage_timings.length > 0 ? (
                <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200 space-y-3 font-mono text-xs">
                  {route.stage_timings.map((st, idx) => {
                    const isFirst = idx === 0;
                    const isLast = idx === route.stage_timings!.length - 1;
                    return (
                      <div
                        key={idx}
                        className="bg-white rounded-xl p-3 border border-slate-200 space-y-1.5 shadow-2xs"
                      >
                        {isFirst ? (
                          <div className="flex items-center justify-between">
                            <span className="font-extrabold text-blue-700 bg-blue-50 px-2.5 py-1 rounded-md border border-blue-200 text-xs">
                              {st.departure || route.departure_time}
                            </span>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                              Departure
                            </span>
                            <span className="font-bold text-slate-900 text-sm font-sans">{st.stop}</span>
                          </div>
                        ) : isLast ? (
                          <div className="flex items-center justify-between">
                            <span className="font-extrabold text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-md border border-emerald-200 text-xs">
                              {st.arrival || route.arrival_destination_time}
                            </span>
                            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 bg-slate-100 px-2 py-0.5 rounded">
                              Arrival
                            </span>
                            <span className="font-bold text-slate-900 text-sm font-sans">{st.stop}</span>
                          </div>
                        ) : (
                          <div className="space-y-1">
                            {st.arrival && (
                              <div className="flex items-center justify-between text-slate-700">
                                <span className="font-extrabold text-slate-800 bg-slate-100 px-2 py-0.5 rounded text-xs">
                                  {st.arrival}
                                </span>
                                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                  Arrival
                                </span>
                                <span className="font-bold text-slate-900 text-sm font-sans">{st.stop}</span>
                              </div>
                            )}
                            {st.departure && st.departure !== st.arrival && (
                              <div className="flex items-center justify-between text-slate-700 pt-1 border-t border-slate-100">
                                <span className="font-extrabold text-blue-700 bg-blue-50 px-2 py-0.5 rounded border border-blue-200 text-xs">
                                  {st.departure}
                                </span>
                                <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">
                                  Departure
                                </span>
                                <span className="font-bold text-slate-900 text-sm font-sans">{st.stop}</span>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="relative pl-6 space-y-6 before:absolute before:left-2.5 before:top-2 before:bottom-2 before:w-0.5 before:bg-slate-200">
                  {route.all_stops.map((stop, idx) => {
                    const isFirst = idx === 0;
                    const isLast = idx === route.all_stops.length - 1;
                    const isTransfer = idx > 0 && !isLast && (stop.includes('Metro') || stop.includes('Concourse') || stop.includes('Interchange') || stop.includes('Transfer'));

                    return (
                      <div key={idx} className="relative flex items-start gap-3">
                        <span
                          className={`absolute -left-6 top-1 h-5 w-5 rounded-full border-2 flex items-center justify-center text-[10px] font-bold ${
                            isFirst
                              ? 'bg-emerald-600 border-white text-white shadow-xs'
                              : isLast
                              ? 'bg-red-600 border-white text-white shadow-xs'
                              : isTransfer
                              ? 'bg-amber-500 border-white text-white shadow-xs ring-2 ring-amber-200'
                              : 'bg-white border-slate-400 text-slate-600'
                          }`}
                        >
                          {isFirst ? 'A' : isLast ? 'B' : idx + 1}
                        </span>

                        <div className="flex-1 bg-slate-50 p-3.5 rounded-2xl border border-slate-200 flex items-center justify-between">
                          <div>
                            <h4 className="text-xs font-bold text-slate-900">
                              {stop}
                            </h4>
                            <span className="text-[11px] text-slate-500">
                              {isFirst
                                ? `Origin Departure Stop (${route.departure_time})`
                                : isLast
                                ? `Destination Terminal (${route.arrival_destination_time})`
                                : isTransfer
                                ? '🔄 Physical Transfer / Interchange'
                                : 'Intermediate Scheduled Stop'}
                            </span>
                          </div>

                          <button
                            onClick={() => {
                              onCheckWaitingTime(stop);
                              onClose();
                            }}
                            className="cursor-pointer text-[11px] font-bold px-2.5 py-1 bg-white hover:bg-blue-50 text-blue-700 rounded-lg border border-slate-200 transition-colors"
                          >
                            Check Board
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* VIEW TAB 3: FULL ROUTE TIMETABLE */}
          {viewTab === 'timetable' && (
            <div className="space-y-4">
              <div className="bg-slate-900 text-white rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 rounded-md text-xs font-black bg-blue-600 text-white">
                      {routeTimetable ? routeTimetable.route_name : route.route_number || 'Route Schedule'}
                    </span>
                    <span className="text-xs text-slate-300">Full Day Scheduled Service</span>
                  </div>
                  <p className="text-xs text-slate-400 mt-1">
                    Every bus on this route operates with its own unique scheduled departure and arrival time.
                  </p>
                </div>

                <div className="text-right">
                  <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[11px] font-bold ${
                    routeTimetable?.is_official_verified
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
                      : 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                  }`}>
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>{routeTimetable?.data_source_label || route.data_source_label}</span>
                  </span>
                </div>
              </div>

              {routeTimetable && routeTimetable.trips.length > 0 ? (
                <div className="overflow-x-auto rounded-2xl border border-slate-200">
                  <table className="w-full text-left text-xs">
                    <thead>
                      <tr className="bg-slate-100 text-slate-600 uppercase text-[10px] font-bold border-b border-slate-200">
                        <th className="py-2.5 px-3">Trip #</th>
                        <th className="py-2.5 px-3">Departure</th>
                        <th className="py-2.5 px-3">Arrival</th>
                        <th className="py-2.5 px-3">Bus / Vehicle</th>
                        <th className="py-2.5 px-3">Spacing / Gap</th>
                        <th className="py-2.5 px-3">Duration</th>
                        <th className="py-2.5 px-3 text-right">Status</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {routeTimetable.trips.map((trip: TripRecord, tIdx: number) => {
                        const isCurrentTrip =
                          trip.origin_departure_time === route.departure_time ||
                          trip.trip_id === route.trip_id;

                        return (
                          <tr
                            key={trip.trip_id || tIdx}
                            className={`transition-colors ${
                              isCurrentTrip
                                ? 'bg-blue-50/80 font-bold border-l-4 border-l-blue-600'
                                : 'hover:bg-slate-50'
                            }`}
                          >
                            <td className="py-2.5 px-3 font-mono text-slate-500">
                              #{tIdx + 1}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="font-extrabold text-blue-700 bg-blue-50 px-2 py-0.5 rounded text-xs">
                                {trip.origin_departure_time}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 font-extrabold text-emerald-700">
                              {trip.destination_arrival_time}
                            </td>
                            <td className="py-2.5 px-3 font-mono text-[11px] text-slate-700">
                              {trip.bus_id}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600">
                              {trip.interval_from_prev_trip_mins ? (
                                <span className="inline-flex items-center gap-1 text-[11px] font-bold text-slate-600 bg-slate-100 px-1.5 py-0.5 rounded">
                                  +{trip.interval_from_prev_trip_mins} min
                                </span>
                              ) : (
                                <span className="text-[10px] text-slate-400">First bus</span>
                              )}
                            </td>
                            <td className="py-2.5 px-3 text-slate-600">
                              {trip.duration_mins} min
                            </td>
                            <td className="py-2.5 px-3 text-right">
                              {isCurrentTrip ? (
                                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-blue-600 text-white">
                                  Selected
                                </span>
                              ) : (
                                <span className="text-[11px] text-slate-400">Scheduled</span>
                              )}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ) : (
                <div className="p-6 text-center text-slate-500 bg-slate-50 rounded-2xl border border-slate-200">
                  <p className="text-xs">
                    Individual departures for this route are actively operated with distinct vehicle schedules throughout the day.
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Multimodal Segments Breakdown */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-500">
              Service Leg Breakdown
            </h3>
            {route.segments.map((seg, idx) => (
              <div
                key={idx}
                className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {seg.transport_type === 'bus' && <Bus className="w-4 h-4 text-emerald-600" />}
                    {seg.transport_type === 'metro' && <Milestone className="w-4 h-4 text-blue-600" />}
                    {seg.transport_type === 'train' && <Train className="w-4 h-4 text-amber-600" />}
                    <span className="font-extrabold text-xs text-slate-900">
                      Leg {idx + 1}: {seg.line_number} — {seg.line_name}
                    </span>
                  </div>
                  <span className="text-xs font-bold text-slate-600">
                    {seg.duration_min} min
                  </span>
                </div>

                <div className="text-xs text-slate-600 flex items-center justify-between">
                  <span>From: <strong>{seg.from_stop}</strong></span>
                  <ArrowRight className="w-3.5 h-3.5 text-slate-400" />
                  <span>To: <strong>{seg.to_stop}</strong></span>
                </div>

                {seg.live_gps && (
                  <div className="p-2 rounded-xl bg-emerald-50 text-emerald-800 text-[11px] font-mono flex items-center justify-between border border-emerald-100">
                    <span className="flex items-center gap-1.5">
                      <Radio className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                      Speed: {seg.live_gps.speed_kmh} km/h • Next: {seg.live_gps.next_stop}
                    </span>
                    <span>{seg.live_gps.updated_seconds_ago}s ago</span>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* Dynamic Leg-by-Leg Fare Breakdown (Section 13) */}
          {route.fare_breakdowns && route.fare_breakdowns.length > 0 && (
            <div className="p-4 rounded-2xl border border-emerald-200 bg-emerald-50/40 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-emerald-700" />
                  <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-900">
                    Dynamic Fare Calculation Breakdown
                  </h3>
                </div>
                <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                  route.fare_verified ? 'bg-emerald-100 text-emerald-800' : 'bg-amber-100 text-amber-800'
                }`}>
                  {route.fare_status_label || (route.fare_verified ? '✓ Verified fare data' : 'Estimated fare')}
                </span>
              </div>

              <div className="divide-y divide-emerald-100 text-xs">
                {route.fare_breakdowns.map((fb, idx) => (
                  <div key={idx} className="py-2.5 flex items-start justify-between gap-3">
                    <div>
                      <div className="flex items-center gap-1.5">
                        <strong className="text-slate-900">Leg {idx + 1}: {fb.service_name}</strong>
                        <span className="text-slate-500">({fb.service_type})</span>
                        <span className="text-[10px] font-mono text-slate-400">• {fb.distance_km} km</span>
                      </div>
                      <span className="text-[11px] text-slate-500 block">
                        {fb.from_stop} → {fb.to_stop}
                      </span>
                      {fb.fare_citation && (
                        <span className="text-[10px] text-slate-400 block italic mt-0.5">
                          Source: {fb.fare_citation}
                        </span>
                      )}
                    </div>
                    <div className="text-right">
                      <span className="text-sm font-black text-emerald-800">
                        {fb.fare === 0 ? 'Free' : `₹${fb.fare}`}
                      </span>
                      <span className="text-[10px] text-slate-400 block">
                        {fb.fare_status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>

              <div className="pt-2 border-t border-emerald-200 flex items-center justify-between text-xs font-bold">
                <span className="text-slate-700">Total Calculated Journey Fare:</span>
                <span className="text-base text-emerald-700 font-extrabold">{route.fare_formatted || `₹${route.fare_inr}`}</span>
              </div>
            </div>
          )}

          {/* Section 14 Verified Transport Disclaimer */}
          <div className="p-3 rounded-xl bg-amber-50/70 border border-amber-200/80 text-center">
            <p className="text-xs text-amber-900 font-medium">
              «"Timings and fares may change. Please verify the latest service information before travelling."»
            </p>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-6 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <button
            onClick={() => onCheckWaitingTime(originStop)}
            className="cursor-pointer text-xs font-bold text-blue-600 hover:text-blue-800 flex items-center gap-1"
          >
            <Clock className="w-4 h-4" />
            <span>Check Waiting Time for {originStop}</span>
          </button>

          <button
            onClick={onClose}
            className="cursor-pointer px-5 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-colors"
          >
            Close Details
          </button>
        </div>
      </div>
    </div>
  );
};
