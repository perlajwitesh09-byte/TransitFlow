import React from 'react';
import { Bus, Clock, ShieldCheck, Database, GitFork, Award, CheckCircle2 } from 'lucide-react';
import { DataSourceBadge } from './DataSourceBadge';

export const AboutView: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 py-8 space-y-10">
      {/* Hero section */}
      <div className="bg-white rounded-3xl p-8 sm:p-10 shadow-sm border border-slate-200 text-center space-y-4">
        <div className="w-16 h-16 rounded-2xl bg-blue-600 text-white flex items-center justify-center mx-auto shadow-md">
          <Bus className="w-8 h-8" />
        </div>
        <div className="inline-block px-4 py-1 rounded-full bg-blue-50 text-blue-700 text-xs font-bold border border-blue-200">
          TRANSIT FLOW
        </div>
        <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tight">
          “Beyond Routes, Towards Better Journeys.”
        </h1>
        <p className="text-slate-600 text-base max-w-2xl mx-auto leading-relaxed">
          Public transport navigation often tells you which bus or metro line to take, but leaves you stranded at the stop wondering when your trip will actually begin. Transit Flow closes that critical gap.
        </p>
      </div>

      {/* Main Innovation Callout */}
      <div className="bg-gradient-to-br from-slate-900 to-indigo-950 text-white rounded-3xl p-8 shadow-xl border border-slate-800 space-y-4">
        <span className="text-xs font-bold text-emerald-400 uppercase tracking-widest">
          The Core Innovation
        </span>
        <blockquote className="text-xl sm:text-2xl font-bold leading-snug">
          “Transit Flow does not simply show where to go; it helps passengers understand when their journey can begin.”
        </blockquote>
        <p className="text-sm text-slate-300 leading-relaxed">
          The combination of <strong>Route Planning</strong> + <strong>Waiting Time Estimation</strong> + <strong>Data Source Transparency</strong> gives Transit Flow its unique identity. By explicitly separating real-time GPS feeds from published timetables, commuters never face false expectations.
        </p>
      </div>

      {/* 3 Pillars */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center mb-4">
            <GitFork className="w-5 h-5" />
          </div>
          <h3 className="text-base font-extrabold text-slate-900">Unbiased Planning</h3>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            We don't arbitrarily designate one route as "best". We present duration, distance, transfers, and waiting time side-by-side so commuters decide based on their personal priorities.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-4">
            <Clock className="w-5 h-5" />
          </div>
          <h3 className="text-base font-extrabold text-slate-900">Waiting Time Engine</h3>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            Deterministic countdown calculated via <code className="bg-slate-100 px-1 py-0.5 rounded text-slate-900 font-mono text-[11px]">Waiting Time = Expected Arrival - Current Time</code>, updated dynamically every minute.
          </p>
        </div>

        <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-xs">
          <div className="w-10 h-10 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center mb-4">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h3 className="text-base font-extrabold text-slate-900">Provenance Labels</h3>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed">
            Every departure is clearly marked as 🟢 LIVE (telemetry), 🔵 SCHEDULED (timetable), or 🟡 ESTIMATED (congestion algorithm).
          </p>
        </div>
      </div>

      {/* Relational Database Architecture (from prompt specifications) */}
      <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-indigo-50 text-indigo-600 rounded-xl">
            <Database className="w-6 h-6" />
          </div>
          <div>
            <h2 className="text-xl font-bold text-slate-900">
              System Database Schema Specification
            </h2>
            <p className="text-xs text-slate-500">
              Designed for seamless scaling from local JSON datasets to relational MySQL/PostgreSQL backends.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs font-mono">
          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span className="font-bold text-blue-700 block mb-2">TABLE: stops</span>
            <ul className="space-y-1 text-slate-700">
              <li>• stop_id: VARCHAR (e.g. S001)</li>
              <li>• stop_name: VARCHAR (e.g. Ameerpet)</li>
              <li>• latitude: DECIMAL (e.g. 17.4375)</li>
              <li>• longitude: DECIMAL (e.g. 78.4482)</li>
            </ul>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span className="font-bold text-blue-700 block mb-2">TABLE: routes</span>
            <ul className="space-y-1 text-slate-700">
              <li>• route_id: VARCHAR (e.g. R001)</li>
              <li>• route_number: VARCHAR (e.g. 216D)</li>
              <li>• transport_type: ENUM (Bus, Train, Metro)</li>
              <li>• source: VARCHAR (e.g. Ameerpet)</li>
              <li>• destination: VARCHAR (e.g. Secunderabad)</li>
            </ul>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span className="font-bold text-blue-700 block mb-2">TABLE: schedule</span>
            <ul className="space-y-1 text-slate-700">
              <li>• route_id: VARCHAR (e.g. R001)</li>
              <li>• stop_id: VARCHAR (e.g. S001)</li>
              <li>• arrival_time: TIME (e.g. 10:25)</li>
              <li>• departure_time: TIME (e.g. 10:27)</li>
            </ul>
          </div>

          <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200">
            <span className="font-bold text-blue-700 block mb-2">TABLE: users</span>
            <ul className="space-y-1 text-slate-700">
              <li>• user_id: VARCHAR (e.g. 001)</li>
              <li>• name: VARCHAR (e.g. Student)</li>
              <li>• email: VARCHAR (e.g. student@example.com)</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};
