import React from 'react';
import { Bus, Clock, Radio, Award, ShieldAlert, Menu, X, ChevronRight, GraduationCap, Bookmark } from 'lucide-react';

export type NavTab = 'home' | 'plan' | 'waiting-time' | 'routes' | 'saved' | 'about' | 'help' | 'admin';

interface HeaderProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  currentTimeStr: string;
  onAdjustTime?: (deltaMins: number) => void;
  isLiveFeedActive: boolean;
  onToggleLiveFeed: () => void;
  onOpenJudgeWalkthrough: () => void;
  savedCount?: number;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  currentTimeStr,
  onAdjustTime,
  isLiveFeedActive,
  onToggleLiveFeed,
  onOpenJudgeWalkthrough,
  savedCount = 0,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = React.useState(false);

  const navItems: { id: NavTab; label: string; badge?: string }[] = [
    { id: 'home', label: 'Home' },
    { id: 'plan', label: 'Plan Journey' },
    { id: 'waiting-time', label: 'Waiting Time', badge: 'Live' },
    { id: 'routes', label: 'Routes' },
    { id: 'saved', label: 'Saved', badge: savedCount > 0 ? String(savedCount) : undefined },
    { id: 'about', label: 'About' },
    { id: 'help', label: 'Help' },
  ];

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      {/* Top micro-bar with current time and live data indicator */}
      <div className="bg-slate-900 text-slate-300 text-xs px-4 py-1.5 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-3">
          <span className="text-slate-400 font-medium hidden sm:inline">
            🚍 Hyderabad Metropolitan Transit Network
          </span>
          <div className="flex items-center gap-1.5 bg-slate-800 px-2 py-0.5 rounded text-[11px] font-mono text-emerald-400">
            <Clock className="w-3 h-3" />
            <span>Clock: <strong className="text-white">{currentTimeStr}</strong></span>
          </div>

          {onAdjustTime && (
            <div className="hidden sm:flex items-center gap-1">
              <button
                id="btn-time-step-1"
                onClick={() => onAdjustTime(1)}
                className="cursor-pointer px-1.5 py-0.5 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
                title="Advance simulation by 1 minute"
              >
                +1m
              </button>
              <button
                id="btn-time-step-5"
                onClick={() => onAdjustTime(5)}
                className="cursor-pointer px-1.5 py-0.5 text-[10px] bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
                title="Advance simulation by 5 minutes"
              >
                +5m
              </button>
            </div>
          )}
        </div>

        <div className="flex items-center gap-3">
          <button
            id="toggle-telematics-feed"
            onClick={onToggleLiveFeed}
            className={`cursor-pointer px-2.5 py-0.5 rounded text-[11px] font-semibold flex items-center gap-1.5 border transition-all ${
              isLiveFeedActive
                ? 'bg-emerald-950/80 text-emerald-300 border-emerald-600/50 hover:bg-emerald-900'
                : 'bg-blue-950/80 text-blue-300 border-blue-600/50 hover:bg-blue-900'
            }`}
            title="Click to toggle between real-time GPS telemetry and published timetable fallbacks"
          >
            <span className={`h-1.5 w-1.5 rounded-full ${isLiveFeedActive ? 'bg-emerald-400 animate-pulse' : 'bg-blue-400'}`}></span>
            <span>{isLiveFeedActive ? '🟢 Live GPS Feed: Active' : '🔵 Mode: Scheduled Timetable'}</span>
          </button>

          <button
            id="btn-judge-walkthrough"
            onClick={onOpenJudgeWalkthrough}
            className="cursor-pointer bg-gradient-to-r from-amber-500 to-orange-500 hover:from-amber-600 hover:to-orange-600 text-white px-2.5 py-0.5 rounded text-[11px] font-bold flex items-center gap-1 shadow-xs transition-transform active:scale-95"
            title="Open 8-Step Interactive Presentation for Judges"
          >
            <Award className="w-3 h-3" />
            <span>Judge Demo Flow</span>
          </button>

          <button
            id="btn-admin-panel"
            onClick={() => onSelectTab('admin')}
            className={`cursor-pointer text-[11px] px-2 py-0.5 rounded transition-colors flex items-center gap-1 ${
              currentTab === 'admin'
                ? 'bg-indigo-600 text-white font-semibold'
                : 'text-slate-400 hover:text-white hover:bg-slate-800'
            }`}
          >
            <ShieldAlert className="w-3 h-3" />
            <span className="hidden sm:inline">Admin</span>
          </button>
        </div>
      </div>

      {/* Main navigation container */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-18">
          {/* Logo & Brand */}
          <div
            id="brand-logo"
            onClick={() => onSelectTab('home')}
            className="cursor-pointer flex items-center gap-3 select-none group"
          >
            <div className="w-11 h-11 rounded-xl bg-blue-600 text-white flex items-center justify-center shadow-md group-hover:bg-blue-700 transition-colors">
              <GraduationCap className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-slate-900 group-hover:text-blue-600 transition-colors">
                  Transit Flow
                </span>
                <span className="hidden sm:inline-block px-2 py-0.5 bg-blue-50 text-blue-700 text-[10px] font-extrabold rounded-full border border-blue-200">
                  Hyderabad 🎓
                </span>
              </div>
              <p className="text-xs text-slate-500 font-medium">
                Student-Friendly Public Transport Journey Planner
              </p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map(item => {
              const isActive = currentTab === item.id;
              return (
                <button
                  key={item.id}
                  id={`nav-link-${item.id}`}
                  onClick={() => onSelectTab(item.id)}
                  className={`cursor-pointer px-3.5 py-2 rounded-xl text-sm font-semibold transition-all relative flex items-center gap-1.5 ${
                    isActive
                      ? 'text-blue-600 bg-blue-50/80 shadow-2xs font-bold'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <span>{item.label}</span>
                  {item.badge && (
                    <span className={`px-1.5 py-0.2 text-[10px] font-bold rounded-full border ${
                      item.id === 'waiting-time'
                        ? 'bg-emerald-100 text-emerald-800 border-emerald-300'
                        : 'bg-amber-100 text-amber-800 border-amber-300'
                    }`}>
                      {item.badge}
                    </span>
                  )}
                  {isActive && (
                    <span className="absolute bottom-0 left-3 right-3 h-0.5 bg-blue-600 rounded-full"></span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Mobile hamburger button */}
          <div className="flex items-center md:hidden">
            <button
              id="mobile-menu-toggle"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="cursor-pointer p-2 rounded-xl text-slate-600 hover:bg-slate-100 hover:text-slate-900"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile menu dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 bg-white px-4 pt-2 pb-4 space-y-1 shadow-lg animate-fade-in">
          {navItems.map(item => (
            <button
              key={item.id}
              onClick={() => {
                onSelectTab(item.id);
                setMobileMenuOpen(false);
              }}
              className={`cursor-pointer w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold flex items-center justify-between ${
                currentTab === item.id
                  ? 'bg-blue-50 text-blue-600 font-bold'
                  : 'text-slate-700 hover:bg-slate-50'
              }`}
            >
              <span>{item.label}</span>
              {item.badge && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-blue-100 text-blue-700">
                  {item.badge}
                </span>
              )}
            </button>
          ))}
          <button
            onClick={() => {
              onSelectTab('admin');
              setMobileMenuOpen(false);
            }}
            className="cursor-pointer w-full text-left px-3 py-2.5 rounded-xl text-sm font-semibold text-indigo-600 hover:bg-indigo-50 flex items-center justify-between"
          >
            <span>Admin Control Portal</span>
            <ChevronRight className="w-4 h-4 text-indigo-400" />
          </button>
        </div>
      )}
    </header>
  );
};
