import React from 'react';
import { DataSourceType } from '../types/transit';
import { Radio, CalendarClock, Sparkles, Info } from 'lucide-react';

interface DataSourceBadgeProps {
  type: DataSourceType;
  showDetail?: boolean;
  pulse?: boolean;
  updatedAgo?: number;
  className?: string;
}

export const DataSourceBadge: React.FC<DataSourceBadgeProps> = ({
  type,
  showDetail = false,
  pulse = true,
  updatedAgo,
  className = '',
}) => {
  if (type === 'live') {
    return (
      <div className={`inline-flex flex-col ${className}`}>
        <div
          id="badge-live"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-300 shadow-xs"
          title="Information received from active real-time GPS transport feed"
        >
          <span className="relative flex h-2 w-2">
            {pulse && (
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            )}
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <Radio className="w-3.5 h-3.5 text-emerald-600" />
          <span className="tracking-wide">LIVE</span>
        </div>
        {showDetail && (
          <span className="text-[11px] text-emerald-700 font-medium mt-0.5 flex items-center gap-1">
            Real-time GPS {updatedAgo ? `• Updated ${updatedAgo}s ago` : '• Connected'}
          </span>
        )}
      </div>
    );
  }

  if (type === 'scheduled') {
    return (
      <div className={`inline-flex flex-col ${className}`}>
        <div
          id="badge-scheduled"
          className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-blue-100 text-blue-800 border border-blue-300 shadow-xs"
          title="Information calculated strictly from published official timetables"
        >
          <span className="h-2 w-2 rounded-full bg-blue-500"></span>
          <CalendarClock className="w-3.5 h-3.5 text-blue-600" />
          <span className="tracking-wide">SCHEDULED</span>
        </div>
        {showDetail && (
          <span className="text-[11px] text-blue-700 font-medium mt-0.5">
            Based on published timetable
          </span>
        )}
      </div>
    );
  }

  // Estimated
  return (
    <div className={`inline-flex flex-col ${className}`}>
      <div
        id="badge-estimated"
        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-amber-100 text-amber-800 border border-amber-300 shadow-xs"
        title="Calculated by Transit Flow algorithmic estimation when live telemetry is offline"
      >
        <span className="h-2 w-2 rounded-full bg-amber-500"></span>
        <Sparkles className="w-3.5 h-3.5 text-amber-600" />
        <span className="tracking-wide">ESTIMATED</span>
      </div>
      {showDetail && (
        <span className="text-[11px] text-amber-700 font-medium mt-0.5">
          Algorithmic approximation
        </span>
      )}
    </div>
  );
};

export const DataSourceExplanationCard: React.FC<{ onToggleLiveSim?: () => void; isLiveSim?: boolean }> = ({
  onToggleLiveSim,
  isLiveSim = true,
}) => {
  return (
    <div className="bg-slate-900 text-white rounded-2xl p-5 shadow-lg border border-slate-800">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-indigo-500/20 text-indigo-400 rounded-lg">
            <Info className="w-5 h-5" />
          </div>
          <div>
            <h4 className="text-sm font-bold tracking-wide uppercase text-indigo-400">
              Data Source Transparency System
            </h4>
            <p className="text-xs text-slate-300 mt-0.5">
              Transit Flow never misrepresents timetable estimates as real-time tracking.
            </p>
          </div>
        </div>

        {onToggleLiveSim && (
          <button
            id="toggle-live-feed-btn"
            onClick={onToggleLiveSim}
            className={`cursor-pointer px-3.5 py-2 rounded-xl text-xs font-semibold transition-all flex items-center gap-2 border ${
              isLiveSim
                ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/40 hover:bg-emerald-500/30'
                : 'bg-blue-500/20 text-blue-300 border-blue-500/40 hover:bg-blue-500/30'
            }`}
          >
            <span className={`h-2 w-2 rounded-full ${isLiveSim ? 'bg-emerald-400 animate-ping' : 'bg-blue-400'}`}></span>
            <span>Feed Mode: <strong className="underline">{isLiveSim ? 'Live GPS Active' : 'Timetable-Only'}</strong></span>
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-4">
        <div className="bg-slate-800/80 rounded-xl p-3 border border-emerald-500/30">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs font-bold text-emerald-400 tracking-wider">🟢 LIVE</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Real-time data from vehicle GPS transponders and automatic vehicle location (AVL) systems.
          </p>
        </div>

        <div className="bg-slate-800/80 rounded-xl p-3 border border-blue-500/30">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-blue-400"></span>
            <span className="text-xs font-bold text-blue-400 tracking-wider">🔵 SCHEDULED</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Calculated from official published transit operator timetables when GPS is inactive.
          </p>
        </div>

        <div className="bg-slate-800/80 rounded-xl p-3 border border-amber-500/30">
          <div className="flex items-center gap-2 mb-1.5">
            <span className="h-2.5 w-2.5 rounded-full bg-amber-400"></span>
            <span className="text-xs font-bold text-amber-400 tracking-wider">🟡 ESTIMATED</span>
          </div>
          <p className="text-xs text-slate-300 leading-relaxed">
            Algorithmic interpolation based on traffic conditions and historical speed data.
          </p>
        </div>
      </div>
    </div>
  );
};
