/**
 * =========================================================================
 * CAMPUSROUTE 24-HOUR TIME & KOLKATA TIMEZONE ENGINE
 * 
 * Strict 24-hour time format everywhere: HH:MM (00:00 -> 23:59)
 * Zero AM/PM display or usage.
 * Full midnight-crossing arithmetic (23:40 -> 00:25 recognized as following day).
 * Proper date-time representation: YYYY-MM-DD HH:MM (Asia/Kolkata).
 * =========================================================================
 */

export const TRANSIT_TIMEZONE = 'Asia/Kolkata';

/**
 * Strict validation for 24-hour time: 00:00 - 23:59
 * Rejects values such as 24:00, 25:30, 12:75, -01:00, text, etc.
 */
export function validate24HourTime(timeStr: string): {
  isValid: boolean;
  error?: string;
  normalized?: string;
} {
  if (!timeStr || typeof timeStr !== 'string') {
    return { isValid: false, error: 'Departure time is required in 24-hour format (HH:MM).' };
  }

  const clean = timeStr.trim();

  // Match H:MM or HH:MM
  const match = clean.match(/^(\d{1,2}):(\d{2})$/);
  if (!match) {
    return {
      isValid: false,
      error: `Invalid format "${clean}". Time must be in 24-hour HH:MM format (e.g. 09:15, 18:30, 23:40).`,
    };
  }

  const hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);

  if (hours < 0 || hours > 23) {
    return {
      isValid: false,
      error: `Invalid hour "${match[1]}". Hours must be between 00 and 23 (rejecting 24:00, 25:30, etc.).`,
    };
  }

  if (minutes < 0 || minutes > 59) {
    return {
      isValid: false,
      error: `Invalid minute "${match[2]}". Minutes must be between 00 and 59 (rejecting 12:75, etc.).`,
    };
  }

  const padH = String(hours).padStart(2, '0');
  const padM = String(minutes).padStart(2, '0');
  return {
    isValid: true,
    normalized: `${padH}:${padM}`,
  };
}

/**
 * Returns true if the string is a valid 24-hour time: 00:00 - 23:59
 */
export function isValid24HourTime(timeStr: string): boolean {
  return validate24HourTime(timeStr).isValid;
}

/**
 * Normalizes ANY time string to strict 24-hour "HH:MM".
 * Converts legacy "08:20 AM" -> "08:20", "06:30 PM" -> "18:30", "1:45 PM" -> "13:45",
 * "12:15 AM" -> "00:15", "12:15 PM" -> "12:15", "9:15" -> "09:15".
 * Guaranteed to NEVER contain AM or PM.
 */
export function to24HourTime(timeStr: string): string {
  if (!timeStr) return '09:00';
  const clean = timeStr.trim();

  // Check if legacy AM/PM is present
  const upper = clean.toUpperCase();
  const hasPM = upper.includes('PM');
  const hasAM = upper.includes('AM');

  const match = upper.match(/(\d{1,2}):(\d{2})/);
  if (!match) return '09:00';

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);

  if (hasPM) {
    if (hours < 12) hours += 12;
  } else if (hasAM) {
    if (hours === 12) hours = 0;
  }

  const normH = Math.max(0, Math.min(23, hours));
  const normM = Math.max(0, Math.min(59, minutes));

  return `${String(normH).padStart(2, '0')}:${String(normM).padStart(2, '0')}`;
}

/**
 * Parse 24-hour time (or legacy format) into total minutes from 00:00 [0, 1439]
 */
export function parseTimeToMinutes(timeStr: string): number {
  if (!timeStr) return 9 * 60; // 09:00 default
  const clean = timeStr.trim().toUpperCase();

  const isPM = clean.includes('PM');
  const isAM = clean.includes('AM');

  const match = clean.match(/(\d{1,2}):(\d{2})/);
  if (!match) return 9 * 60;

  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);

  if (isPM && hours < 12) hours += 12;
  if (isAM && hours === 12) hours = 0;

  return (hours * 60 + minutes) % 1440;
}

/**
 * Formats total minutes into strict 24-hour "HH:MM".
 * Supports totalMinutes >= 1440 (e.g. crossing midnight).
 * 1420 -> "23:40"
 * 1465 -> "00:25"
 * NEVER returns AM or PM.
 */
export function formatMinutesTo24Hour(totalMinutes: number): string {
  const norm = ((totalMinutes % 1440) + 1440) % 1440;
  const hours = Math.floor(norm / 60);
  const mins = norm % 60;
  return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
}

/**
 * Formats time with "+1 day" indicator if totalMinutes >= 1440 (crosses midnight).
 * e.g. 1465 -> "00:25 (+1 day)"
 */
export function formatTimeWithDayIndicator(totalMinutes: number): string {
  const timeStr = formatMinutesTo24Hour(totalMinutes);
  const daysAdded = Math.floor(totalMinutes / 1440);
  if (daysAdded === 1) {
    return `${timeStr} (+1 day)`;
  } else if (daysAdded > 1) {
    return `${timeStr} (+${daysAdded} days)`;
  }
  return timeStr;
}

/**
 * Calculates current time in Asia/Kolkata in 24-hour format and YYYY-MM-DD
 */
export function getCurrentKolkataDateTime(date: Date = new Date()): {
  dateStr: string;     // "YYYY-MM-DD"
  time24: string;      // "HH:MM"
  dateTimeStr: string; // "YYYY-MM-DD HH:MM"
} {
  // Asia/Kolkata date formatter
  const dateParts = new Intl.DateTimeFormat('en-CA', {
    timeZone: TRANSIT_TIMEZONE,
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(date); // YYYY-MM-DD

  const timeParts = new Intl.DateTimeFormat('en-GB', {
    timeZone: TRANSIT_TIMEZONE,
    hour: '2-digit',
    minute: '2-digit',
    hour12: false,
  }).format(date); // HH:MM

  return {
    dateStr: dateParts,
    time24: timeParts,
    dateTimeStr: `${dateParts} ${timeParts}`,
  };
}

/**
 * Computes exact Asia/Kolkata date-time (YYYY-MM-DD HH:MM) given a base date
 * and total minutes from midnight (which may cross midnight into day + 1).
 * 
 * Example:
 * Base: "2026-09-21", minutes: 1420 (23:40) -> "2026-09-21 23:40"
 * Base: "2026-09-21", minutes: 1465 (00:25 next day) -> "2026-09-22 00:25"
 */
export function computeKolkataDateTime(
  baseDateStr: string = '2026-09-21',
  minutesFromBaseMidnight: number = 0
): {
  dateStr: string;
  time24: string;
  dateTimeStr: string;
  isNextDay: boolean;
  daysAdded: number;
} {
  const roundedTotal = Math.round(minutesFromBaseMidnight);
  const daysAdded = Math.floor(roundedTotal / 1440);
  const normalizedMins = ((roundedTotal % 1440) + 1440) % 1440;
  const hours = Math.floor(normalizedMins / 60);
  const mins = normalizedMins % 60;
  const time24 = `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;

  // Parse YYYY-MM-DD
  const parts = baseDateStr.split('-').map(Number);
  const year = parts[0] || 2026;
  const month = parts[1] || 9;
  const day = parts[2] || 21;

  // Add days using UTC date to avoid DST/browser timezone drift
  const targetDate = new Date(Date.UTC(year, month - 1, day + daysAdded));
  const newYear = targetDate.getUTCFullYear();
  const newMonth = String(targetDate.getUTCMonth() + 1).padStart(2, '0');
  const newDay = String(targetDate.getUTCDate()).padStart(2, '0');

  const dateStr = `${newYear}-${newMonth}-${newDay}`;
  const dateTimeStr = `${dateStr} ${time24}`;

  return {
    dateStr,
    time24,
    dateTimeStr,
    isNextDay: daysAdded > 0,
    daysAdded,
  };
}

/**
 * Format clock time from base hour, base minute, and added minutes in 24-hour format
 * e.g. (10, 17, 0) -> "10:17"
 * e.g. (23, 40, 45) -> "00:25"
 */
export function formatTimeFromOffset24(baseHour = 10, baseMin = 17, addMinutes = 0): string {
  const totalMinutes = ((baseHour * 60 + baseMin + addMinutes) % 1440 + 1440) % 1440;
  const hours = Math.floor(totalMinutes / 60);
  const mins = totalMinutes % 60;
  return `${String(hours).padStart(2, '0')}:${String(mins).padStart(2, '0')}`;
}
