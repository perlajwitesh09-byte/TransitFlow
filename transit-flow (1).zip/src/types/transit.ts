export type TransportType = 'bus' | 'train' | 'metro' | 'all';

export type DataSourceType = 'live' | 'scheduled' | 'estimated';

export type LocationType = 'area' | 'metro' | 'railway' | 'bus_hub' | 'college' | 'airport';

export type DetailedLocationType =
  | 'AREA'
  | 'BUS_STOP'
  | 'METRO_STATION'
  | 'RAILWAY_STATION'
  | 'COLLEGE'
  | 'UNIVERSITY'
  | 'LANDMARK'
  | 'AIRPORT'
  | 'JUNCTION';

export type HyderabadZone = 'Central' | 'North' | 'West' | 'South' | 'Old City' | 'East';

export interface TransitLocation {
  location_id: string;
  name: string;
  latitude: number;
  longitude: number;
  type: DetailedLocationType;
  zone: HyderabadZone;
  aliases: string[];
  nearby_stop_ids: string[];
}

export interface HyderabadLocation {
  id: string;
  name: string;
  type: LocationType;
  zone: HyderabadZone;
  latitude: number;
  longitude: number;
  nearbyTransport?: string;
  aliases?: string[];
}

export interface Stop {
  stop_id: string;
  stop_name: string;
  latitude: number;
  longitude: number;
  city: string;
  area: string;
  zone?: string;
  connected_modes: ('bus' | 'train' | 'metro')[];
}

export interface StopTiming {
  stop: string;
  arrival: string;
  departure: string;
}

export interface TGSRTCBusSchedule {
  operator: "TGSRTC";
  routeNumber: string;
  serviceNumber: string;
  busType: string;
  direction: string;
  origin: string;
  destination: string;
  stops: (string | StopTiming)[];
  departureTime: string;
  arrivalTime: string;
  duration: string;
  fare: string;
  fareVerified: boolean;
  operatingDays: string[];
  lastVerified: string;
  viaHighlights?: string[];
  isAirportPushpak?: boolean;
  sourceStatus?: 'TGSRTC Verified transport information' | 'Estimated timing' | 'Demo data – verify before travel';
}

export interface LegFareBreakdown {
  leg_index: number;
  mode: 'bus' | 'metro' | 'train' | 'walk';
  service_name: string;
  service_type: string;
  from_stop: string;
  to_stop: string;
  distance_km: number;
  fare: number;
  fare_status: 'verified' | 'estimated' | 'unavailable' | 'free';
  fare_citation?: string;
  fare_rule_id?: string;
}

export interface ServiceSegment {
  transport_type: 'bus' | 'train' | 'metro' | 'walk';
  line_number: string;
  line_name: string;
  from_stop: string;
  to_stop: string;
  duration_min: number;
  distance_km?: number;
  stops_count: number;
  intermediate_stops: string[];
  vehicle_status?: 'on-time' | 'delayed' | 'approaching';
  bus_type?: string;
  fare_inr?: number;
  fare_status?: 'verified' | 'estimated' | 'unavailable' | 'free';
  departure_time?: string;
  arrival_time?: string;
  departure_datetime?: string; // YYYY-MM-DD HH:MM (Asia/Kolkata)
  arrival_datetime?: string;   // YYYY-MM-DD HH:MM (Asia/Kolkata)
  next_day_arrival?: boolean;
  stage_timings?: StopTiming[];
  live_gps?: {
    latitude: number;
    longitude: number;
    speed_kmh: number;
    next_stop: string;
    updated_seconds_ago: number;
  };
}

export interface RouteOption {
  id: string;
  route_label: string; // e.g. "Route 1 — Direct Bus"
  summary_line: string; // e.g. "🚌 TGSRTC 47L"
  journey_time_min: number;
  distance_km: number;
  changes_count: number;
  waiting_time_min: number;
  expected_arrival_time: string; // formatted HH:MM (24-hour format) or "Estimated"
  data_source: DataSourceType;
  fare_inr: number;
  co2_saved_kg: number;
  segments: ServiceSegment[];
  all_stops: string[];
  departure_time: string; // formatted HH:MM (24-hour format)
  arrival_destination_time: string; // formatted HH:MM (24-hour format)
  departure_datetime?: string; // YYYY-MM-DD HH:MM (Asia/Kolkata)
  arrival_datetime?: string; // YYYY-MM-DD HH:MM (Asia/Kolkata)
  timezone?: string; // 'Asia/Kolkata'
  next_day_arrival?: boolean; // true if journey completes after midnight on the following day
  days_offset?: number; // 0 for same day, 1 for following day
  walking_distance_km: number;
  walking_time_min?: number;
  total_stops_count: number;
  route_score: number; // 0 to 100
  score_tag?: 'Cheapest' | 'Fastest' | 'Fewest Changes' | 'Least Walking' | 'Balanced' | string;
  notes?: string;
  // Specific dynamic fields:
  operator?: 'TGSRTC' | 'Hyderabad Metro' | 'SCR MMTS' | 'Multimodal' | string;
  route_number?: string;
  service_number?: string;
  bus_type?: string;
  direction?: string;
  fare_formatted?: string;
  fare_verified?: boolean;
  fare_breakdowns?: LegFareBreakdown[];
  fare_status_label?: string; // '✓ Verified fare data' | 'Estimated fare: ₹XX' | 'Fare unavailable'
  transfer_hubs?: string[];
  duration_text?: string;
  arrival_is_estimated?: boolean;
  via_highlights?: string[];
  stage_timings?: StopTiming[];
  is_airport_pushpak?: boolean;
  operating_days?: string[];
  last_verified?: string;
  data_source_label?: string;
  travel_date?: string;
  trip_id?: string;
  bus_id?: string;
  timetable_link_route_id?: string;
  stop_by_stop_timings?: TripStopTime[];
  trip_record?: TripRecord;
  interval_from_prev_mins?: number;
}

export interface TripStopTime {
  trip_id: string;
  stop_id: string;
  stop_name: string;
  stop_sequence: number;
  arrival_time: string;   // 24-hour HH:MM
  departure_time: string; // 24-hour HH:MM
  arrival_mins: number;
  departure_mins: number;
  distance_from_origin_km: number;
}

export interface TripRecord {
  trip_id: string;
  route_id: string;
  route_number: string;
  service_id: string;
  bus_id: string;
  direction: string;
  service_type: string;
  departure_time: string; // 24-hour HH:MM
  arrival_time: string;   // 24-hour HH:MM
  origin_departure_time?: string; // alias for departure_time
  destination_arrival_time?: string; // alias for arrival_time
  departure_mins: number; // minutes from 00:00
  arrival_mins: number;   // minutes from 00:00 (may exceed 1440 for next day)
  duration_mins: number;
  operating_days: string[]; // e.g. ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'] or ['Daily']
  is_verified_data: boolean;
  data_source_label: string; // 'TGSRTC Verified Official Data' or 'DEMO DATA — NOT A REAL-TIME OFFICIAL TIMETABLE'
  stop_times: TripStopTime[];
  via_highlights?: string[];
  interval_from_prev_trip_mins?: number;
  notes?: string;
}

export interface RouteTimetable {
  route_id: string;
  route_number: string;
  route_name?: string;
  operator: string;
  service_type: string;
  direction: string;
  origin: string;
  destination: string;
  is_verified_data: boolean;
  is_official_verified?: boolean; // alias for is_verified_data
  data_source_label: string;
  trips: TripRecord[];
}

export interface DatabaseValidationReport {
  passed: boolean;
  totalTrips: number;
  totalRoutes: number;
  total_routes_checked?: number;
  total_trips_checked?: number;
  trips_with_duplicate_departure?: number;
  trips_violating_min_interval?: number;
  checks: {
    checkName: string;
    description: string;
    passed: boolean;
    issues: string[];
  }[];
}

export interface FareRule {
  fare_id: string;
  operator?: string;
  route_id?: string;
  service_type: string; // 'City Ordinary' | 'Metro Express' | 'Metro Deluxe' | 'Metro Luxury AC' | 'Pushpak AC' | 'Hyderabad Metro' | 'MMTS Suburban'
  origin_zone?: string;
  destination_zone?: string;
  min_distance_km?: number;
  max_distance_km?: number;
  base_fare: number;
  per_km_rate?: number;
  currency: 'INR';
  effective_from: string;
  effective_until: string;
  source: string;
  last_updated: string;
  is_verified: boolean;
}

export interface NetworkNode {
  id: string;
  name: string;
  type: 'bus_stop' | 'metro_station' | 'railway_station' | 'interchange' | 'walking_point';
  latitude: number;
  longitude: number;
  zone: HyderabadZone;
  aliases: string[];
  is_transfer_hub?: boolean;
}

export interface NetworkEdge {
  from_stop: string;
  to_stop: string;
  route_id: string;
  trip_id: string;
  transport_type: 'bus' | 'metro' | 'train' | 'walk';
  service_type: string;
  departure_time: string;
  arrival_time: string;
  departure_mins: number;
  arrival_mins: number;
  duration_mins: number;
  distance_km: number;
  intermediate_stops: string[];
  fare_inr: number;
  fare_verified: boolean;
  operating_days?: string[];
}

export interface GTFSMetadata {
  data_source: string;
  data_version: string;
  import_date: string;
  effective_date: string;
  last_updated: string;
  stops_count: number;
  routes_count: number;
  trips_count: number;
  fares_count: number;
  is_demo_mode: boolean;
}

export interface SavedStudentPlace {
  id: string;
  category: 'Home' | 'College' | 'Hostel' | 'Gym' | 'Library' | 'Coaching' | 'Other';
  label: string;
  location_name: string;
  latitude: number;
  longitude: number;
}

export interface StopDeparture {
  service_id: string;
  service_number: string;
  transport_type: 'bus' | 'train' | 'metro';
  destination: string;
  scheduled_arrival: string; // e.g. "10:25" (24-hour format)
  live_arrival?: string; // e.g. "10:25" (24-hour format)
  waiting_minutes: number;
  data_source: DataSourceType;
  status: 'on-time' | 'delayed' | 'approaching' | 'cancelled';
  delay_minutes?: number;
  platform?: string;
  occupancy?: 'Low' | 'Moderate' | 'High';
  last_updated_secs: number;
  bus_id?: string;
  trip_id?: string;
  interval_from_prev_mins?: number;
}

export type SortCriteria =
  | 'recommended'
  | 'cheapest'
  | 'fastest'
  | 'fewest_changes'
  | 'least_walking'
  | 'earliest_arrival'
  | 'latest_departure';

export type PriorityMode = 'budget' | 'time' | 'balanced';

export interface JourneyPreferences {
  shortestTime: boolean;
  fewerChanges: boolean;
  lowestFare: boolean;
  lessWaiting: boolean;
  transportMode: TransportType;
  sortBy: SortCriteria;
  priorityMode: PriorityMode;
  maxBudget: number | null; // Max Fare in ₹ (e.g. 50)
  maxChanges: number | null; // Max Transfers count (e.g. 1)
  maxWalkingKm: number | null; // Max Walking in km (e.g. 1.0)
  maxTimeMin?: number | null; // Max Total Journey Time in mins (e.g. 90)
  busServiceType?: string | null; // Bus Service Type filter: e.g. 'All' | 'Ordinary' | 'Express' | 'Deluxe' | 'Pushpak'
  timeTargetType?: 'departure' | 'arrival'; // Departure time or Arrival time preference
  preferredDepartureTime: string; // e.g. "10:17" or "18:30" (24-hour format)
  travelDate?: string; // e.g. "2026-09-21"
}

export interface UserSearchLog {
  id: string;
  timestamp: string;
  source: string;
  destination: string;
  transport_type: TransportType;
  routes_found: number;
}

export interface SavedJourney {
  id: string;
  source: string;
  destination: string;
  custom_label: string;
  route: RouteOption;
  created_at: string;
}

export interface RecentJourneyPlan {
  id: string;
  source: string;
  destination: string;
  fare_inr: number;
  transport_type: TransportType;
  route_summary?: string;
  duration_min?: number;
  timestamp: string;
  frequency_per_month?: number;
}

export interface MonthlyBudgetConfig {
  monthly_budget: number;
  commuting_days_per_month: number;
  is_round_trip: boolean;
  included_saved_ids: string[];
  included_recent_ids: string[];
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  college?: string;
  preferences?: Partial<JourneyPreferences>;
}
